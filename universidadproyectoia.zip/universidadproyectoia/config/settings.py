from functools import lru_cache

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_env: str = Field(default="local", alias="APP_ENV")
    debug: bool = Field(default=True, alias="DEBUG")
    secret_key: str = Field(default="change-me", alias="SECRET_KEY")
    database_url: str = Field(default="sqlite:///./viaticos.db", alias="DATABASE_URL")
    log_level: str = Field(default="INFO", alias="LOG_LEVEL")
    default_timezone: str = Field(default="America/Bogota", alias="DEFAULT_TIMEZONE")
    enable_gemini: bool = Field(default=True, alias="ENABLE_GEMINI")
    gemini_api_key: str = Field(default="", alias="GEMINI_API_KEY")
    gemini_model: str = Field(default="gemini-3-flash-preview", alias="GEMINI_MODEL")
    gemini_mode: str = Field(default="mock", alias="GEMINI_MODE")
    documents_storage_path: str = Field(
        default="./generated_documents",
        alias="DOCUMENTS_STORAGE_PATH",
    )
    sharepoint_mode: str = Field(default="mock", alias="SHAREPOINT_MODE")
    sap_mode: str = Field(default="mock", alias="SAP_MODE")
    auth_mode: str = Field(default="mock", alias="AUTH_MODE")
    enable_corporate_placeholders: bool = Field(
        default=True,
        alias="ENABLE_CORPORATE_PLACEHOLDERS",
    )

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        populate_by_name=True,
    )

    @field_validator("debug", mode="before")
    @classmethod
    def parse_debug_value(cls, value: object) -> bool:
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            normalized = value.strip().lower()
            if normalized in {"1", "true", "yes", "on", "debug"}:
                return True
            if normalized in {"0", "false", "no", "off", "release", "prod", "production"}:
                return False
        return bool(value)

    @field_validator("app_env", "gemini_mode", "sharepoint_mode", "sap_mode", "auth_mode")
    @classmethod
    def normalize_mode_values(cls, value: str) -> str:
        normalized = value.strip().lower()
        if not normalized:
            raise ValueError("Mode values cannot be empty.")
        return normalized

    @field_validator("log_level", mode="before")
    @classmethod
    def normalize_log_level(cls, value: object) -> str:
        if isinstance(value, str) and value.strip():
            return value.strip().upper()
        return "INFO"

    @property
    def is_local(self) -> bool:
        return self.app_env.lower() == "local"

    @property
    def gemini_is_mock(self) -> bool:
        return self.gemini_mode.lower() == "mock"

    @property
    def feature_flags(self) -> dict[str, bool]:
        return {
            "enable_gemini": self.enable_gemini,
            "enable_corporate_placeholders": self.enable_corporate_placeholders,
        }


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
