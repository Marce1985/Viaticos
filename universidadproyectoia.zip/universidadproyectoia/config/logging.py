import logging
from contextvars import ContextVar

_correlation_id: ContextVar[str] = ContextVar("correlation_id", default="-")
_previous_factory = logging.getLogRecordFactory()


class CorrelationIdFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        record.correlation_id = _correlation_id.get()
        return True


def set_correlation_id(correlation_id: str) -> None:
    _correlation_id.set(correlation_id)


def _record_factory(*args, **kwargs):  # type: ignore[no-untyped-def]
    record = _previous_factory(*args, **kwargs)
    record.correlation_id = _correlation_id.get()
    return record


def configure_logging(debug: bool = False, level_name: str = "INFO") -> None:
    level = logging.DEBUG if debug else getattr(logging, level_name.upper(), logging.INFO)
    logging.setLogRecordFactory(_record_factory)
    logging.basicConfig(
        level=level,
        format="%(asctime)s | %(levelname)s | %(correlation_id)s | %(name)s | %(message)s",
    )
    root_logger = logging.getLogger()
    if not any(isinstance(filter_, CorrelationIdFilter) for filter_ in root_logger.filters):
        root_logger.addFilter(CorrelationIdFilter())
