# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: smoke.spec.ts >> la aplicacion carga y navega entre modulos principales
- Location: playwright\tests\smoke.spec.ts:4:5

# Error details

```
Error: page.goto: net::ERR_CONNECTION_REFUSED at http://127.0.0.1:8050/solicitud
Call log:
  - navigating to "http://127.0.0.1:8050/solicitud", waiting until "load"

```

# Test source

```ts
  1  | import { expect, Locator, Page } from "@playwright/test";
  2  | 
  3  | export class SolicitudPage {
  4  |   readonly page: Page;
  5  |   readonly employeeDropdown: Locator;
  6  |   readonly managerDropdown: Locator;
  7  |   readonly costCenterDropdown: Locator;
  8  |   readonly destinationInput: Locator;
  9  |   readonly countryInput: Locator;
  10 |   readonly purposeInput: Locator;
  11 |   readonly amountInput: Locator;
  12 |   readonly currencyInput: Locator;
  13 |   readonly exchangeRateInput: Locator;
  14 |   readonly saveDraftButton: Locator;
  15 |   readonly submitButton: Locator;
  16 |   readonly feedback: Locator;
  17 | 
  18 |   constructor(page: Page) {
  19 |     this.page = page;
  20 |     this.employeeDropdown = page.locator("#solicitud-employee-id");
  21 |     this.managerDropdown = page.locator("#solicitud-manager-id");
  22 |     this.costCenterDropdown = page.locator("#solicitud-cost-center-id");
  23 |     this.destinationInput = page.locator("#solicitud-destination");
  24 |     this.countryInput = page.locator("#solicitud-country");
  25 |     this.purposeInput = page.locator("#solicitud-purpose");
  26 |     this.amountInput = page.locator("#solicitud-estimated-amount");
  27 |     this.currencyInput = page.locator("#solicitud-currency");
  28 |     this.exchangeRateInput = page.locator("#solicitud-exchange-rate");
  29 |     this.saveDraftButton = page.locator("#solicitud-save-draft");
  30 |     this.submitButton = page.locator("#solicitud-submit-request");
  31 |     this.feedback = page.locator("#solicitud-feedback");
  32 |   }
  33 | 
  34 |   async goto(): Promise<void> {
> 35 |     await this.page.goto("/solicitud");
     |                     ^ Error: page.goto: net::ERR_CONNECTION_REFUSED at http://127.0.0.1:8050/solicitud
  36 |   }
  37 | 
  38 |   async selectDropdownOption(locator: Locator, label: string): Promise<void> {
  39 |     await locator.click();
  40 |     await this.page.getByText(label, { exact: false }).first().click();
  41 |   }
  42 | 
  43 |   async enableFlag(label: string): Promise<void> {
  44 |     await this.page.getByLabel(label, { exact: false }).check();
  45 |   }
  46 | 
  47 |   async fillCoreForm(data: {
  48 |     destination: string;
  49 |     country: string;
  50 |     purpose: string;
  51 |     estimatedAmount: string;
  52 |     currency: string;
  53 |     exchangeRate: string;
  54 |   }): Promise<void> {
  55 |     await this.destinationInput.fill(data.destination);
  56 |     await this.countryInput.fill(data.country);
  57 |     await this.purposeInput.fill(data.purpose);
  58 |     await this.amountInput.fill(data.estimatedAmount);
  59 |     await this.currencyInput.fill(data.currency);
  60 |     await this.exchangeRateInput.fill(data.exchangeRate);
  61 |   }
  62 | 
  63 |   async saveDraft(): Promise<void> {
  64 |     await this.saveDraftButton.click();
  65 |   }
  66 | 
  67 |   async submitRequest(): Promise<void> {
  68 |     await this.submitButton.click();
  69 |   }
  70 | 
  71 |   async expectFeedbackContains(text: string): Promise<void> {
  72 |     await expect(this.feedback).toBeVisible();
  73 |     await expect(this.feedback).toContainText(text);
  74 |   }
  75 | }
  76 | 
```