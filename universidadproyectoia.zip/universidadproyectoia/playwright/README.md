# Playwright Scaffold

Esta carpeta contiene una base inicial para automatizar la app con Playwright.

## Instalacion

```bash
npm install
npm run install:browsers
```

## Ejecucion

```bash
npm run test:e2e
```

La configuracion intenta levantar la app automaticamente con:

```bash
python run.py
```

## Incluye

- `playwright.config.ts`
- fixtures compartidas
- page objects por modulo
- `smoke.spec.ts`
- `solicitud.spec.ts`

## Siguiente paso recomendado

Extender con:

- `aprobaciones.spec.ts`
- `pagos.spec.ts`
- `legalizacion.spec.ts`
- `dashboard.spec.ts`
