import type { Page } from "@playwright/test";

const PLAYWRIGHT_DEMO = process.env.PLAYWRIGHT_DEMO === "1";

export async function showDemoStep(page: Page, message: string): Promise<void> {
  if (!PLAYWRIGHT_DEMO) {
    return;
  }

  try {
    await page.evaluate((text: string) => {
      const existing = document.getElementById("pw-demo-overlay");
      if (existing) {
        existing.remove();
      }

      const overlay = document.createElement("div");
      overlay.id = "pw-demo-overlay";
      overlay.innerHTML = `
        <div style="
          position: fixed;
          top: 24px;
          right: 24px;
          z-index: 999999;
          max-width: 420px;
          background: rgba(13, 27, 42, 0.94);
          color: #ffffff;
          border: 1px solid rgba(255,255,255,0.12);
          border-radius: 18px;
          box-shadow: 0 20px 60px rgba(0,0,0,0.28);
          padding: 16px 18px;
          font-family: 'Segoe UI', sans-serif;
        ">
          <div style="
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: #7dd3fc;
            margin-bottom: 6px;
            font-weight: 700;
          ">Playwright Demo</div>
          <div style="
            font-size: 16px;
            line-height: 1.45;
            font-weight: 600;
          ">${text}</div>
        </div>
      `;

      document.body.appendChild(overlay);
    }, message);

    await page.waitForTimeout(2600);
  } catch {
    return;
  }
}
