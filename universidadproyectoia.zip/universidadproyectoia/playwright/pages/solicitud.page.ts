import { expect, Locator, Page } from "@playwright/test";

export class SolicitudPage {
  readonly page: Page;
  readonly employeeDropdown: Locator;
  readonly managerDropdown: Locator;
  readonly costCenterDropdown: Locator;
  readonly destinationInput: Locator;
  readonly countryInput: Locator;
  readonly purposeInput: Locator;
  readonly amountInput: Locator;
  readonly currencyInput: Locator;
  readonly exchangeRateInput: Locator;
  readonly saveDraftButton: Locator;
  readonly submitButton: Locator;
  readonly feedback: Locator;

  constructor(page: Page) {
    this.page = page;
    this.employeeDropdown = page.locator("#solicitud-employee-id");
    this.managerDropdown = page.locator("#solicitud-manager-id");
    this.costCenterDropdown = page.locator("#solicitud-cost-center-id");
    this.destinationInput = page.locator("#solicitud-destination");
    this.countryInput = page.locator("#solicitud-country");
    this.purposeInput = page.locator("#solicitud-purpose");
    this.amountInput = page.locator("#solicitud-estimated-amount");
    this.currencyInput = page.locator("#solicitud-currency");
    this.exchangeRateInput = page.locator("#solicitud-exchange-rate");
    this.saveDraftButton = page.locator("#solicitud-save-draft");
    this.submitButton = page.locator("#solicitud-submit-request");
    this.feedback = page.locator("#solicitud-feedback");
  }

  async goto(): Promise<void> {
    await this.page.goto("/solicitud");
  }

  async selectDropdownOption(locator: Locator, label: string): Promise<void> {
    await locator.click();
    await this.page.getByText(label, { exact: false }).first().click();
  }

  async enableFlag(label: string): Promise<void> {
    await this.page.getByLabel(label, { exact: false }).check();
  }

  async fillCoreForm(data: {
    destination: string;
    country: string;
    purpose: string;
    estimatedAmount: string;
    currency: string;
    exchangeRate: string;
  }): Promise<void> {
    await this.destinationInput.fill(data.destination);
    await this.countryInput.fill(data.country);
    await this.purposeInput.fill(data.purpose);
    await this.amountInput.fill(data.estimatedAmount);
    await this.currencyInput.fill(data.currency);
    await this.exchangeRateInput.fill(data.exchangeRate);
  }

  async saveDraft(): Promise<void> {
    await this.saveDraftButton.click();
  }

  async submitRequest(): Promise<void> {
    await this.submitButton.click();
  }

  async expectFeedbackContains(text: string): Promise<void> {
    await expect(this.feedback).toBeVisible();
    await expect(this.feedback).toContainText(text);
  }
}
