import { expect, Locator, Page } from "@playwright/test";

export class LegalizacionPage {
  readonly page: Page;
  readonly refreshButton: Locator;
  readonly categoryInput: Locator;
  readonly vendorInput: Locator;
  readonly amountInput: Locator;
  readonly currencyInput: Locator;
  readonly descriptionInput: Locator;
  readonly addItemButton: Locator;
  readonly closeButton: Locator;
  readonly feedback: Locator;

  constructor(page: Page) {
    this.page = page;
    this.refreshButton = page.locator("#legalizacion-refresh");
    this.categoryInput = page.locator("#legalizacion-category");
    this.vendorInput = page.locator("#legalizacion-vendor");
    this.amountInput = page.locator("#legalizacion-amount");
    this.currencyInput = page.locator("#legalizacion-currency");
    this.descriptionInput = page.locator("#legalizacion-description");
    this.addItemButton = page.locator("#legalizacion-add-item");
    this.closeButton = page.locator("#legalizacion-close");
    this.feedback = page.locator("#legalizacion-feedback");
  }

  async goto(): Promise<void> {
    await this.page.goto("/legalizacion");
  }

  async refreshQueue(): Promise<void> {
    await this.refreshButton.click();
  }

  async openFirstRequest(): Promise<void> {
    await this.page.locator("[id*='legalizacion-row-button']").first().click();
  }

  async addExpense(data: { category: string; vendor: string; amount: string; currency: string; description: string }): Promise<void> {
    await this.categoryInput.fill(data.category);
    await this.vendorInput.fill(data.vendor);
    await this.amountInput.fill(data.amount);
    await this.currencyInput.fill(data.currency);
    await this.descriptionInput.fill(data.description);
    await this.addItemButton.click();
  }

  async closeLegalization(): Promise<void> {
    await this.closeButton.click();
  }

  async expectFeedbackContains(text: string): Promise<void> {
    await expect(this.feedback).toBeVisible();
    await expect(this.feedback).toContainText(text);
  }
}
