import { expect, Locator, Page } from "@playwright/test";

export class AprobacionesPage {
  readonly page: Page;
  readonly roleFilter: Locator;
  readonly detail: Locator;
  readonly comments: Locator;
  readonly approveButton: Locator;
  readonly feedback: Locator;

  constructor(page: Page) {
    this.page = page;
    this.roleFilter = page.locator("#aprobaciones-role-filter");
    this.detail = page.locator("#aprobaciones-detail");
    this.comments = page.locator("#aprobaciones-comments");
    this.approveButton = page.locator("#aprobaciones-approve");
    this.feedback = page.locator("#aprobaciones-action-feedback");
  }

  async goto(): Promise<void> {
    await this.page.goto("/aprobaciones");
  }

  async selectRole(label: string): Promise<void> {
    await this.roleFilter.click();
    await this.page.getByText(label, { exact: false }).first().click();
  }

  async openFirstRequest(): Promise<void> {
    await this.page.locator("[id*='approval-row-button']").first().click();
  }

  async approve(comment: string): Promise<void> {
    await this.comments.fill(comment);
    await this.approveButton.click();
  }

  async expectFeedbackContains(text: string): Promise<void> {
    await expect(this.feedback).toBeVisible();
    await expect(this.feedback).toContainText(text);
  }
}
