import { expect, Locator, Page } from "@playwright/test";

export class HomePage {
  readonly page: Page;
  readonly startRequestButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.startRequestButton = page.getByText("Crear nueva solicitud", { exact: true });
  }

  async goto(): Promise<void> {
    await this.page.goto("/");
  }

  async expectLoaded(): Promise<void> {
    await expect(this.page.getByText("Base empresarial para el Portal de Viaticos")).toBeVisible();
    await expect(this.startRequestButton).toBeVisible();
  }
}
