import { expect, Locator, Page } from "@playwright/test";

export class PagosPage {
  readonly page: Page;
  readonly refreshButton: Locator;
  readonly sentToInput: Locator;
  readonly referenceInput: Locator;
  readonly notifiedAmountInput: Locator;
  readonly paidAmountInput: Locator;
  readonly notifyButton: Locator;
  readonly confirmButton: Locator;
  readonly feedback: Locator;

  constructor(page: Page) {
    this.page = page;
    this.refreshButton = page.locator("#pagos-refresh");
    this.sentToInput = page.locator("#pagos-sent-to");
    this.referenceInput = page.locator("#pagos-reference-code");
    this.notifiedAmountInput = page.locator("#pagos-notified-amount");
    this.paidAmountInput = page.locator("#pagos-paid-amount");
    this.notifyButton = page.locator("#pagos-notify");
    this.confirmButton = page.locator("#pagos-confirm");
    this.feedback = page.locator("#pagos-feedback");
  }

  async goto(): Promise<void> {
    await this.page.goto("/pagos");
  }

  async refreshQueue(): Promise<void> {
    await this.refreshButton.click();
  }

  async openFirstRequest(): Promise<void> {
    await this.page.locator("[id*='payment-row-button']").first().click();
  }

  async notifyPayment(email: string, reference: string, amount: string): Promise<void> {
    await this.sentToInput.fill(email);
    await this.referenceInput.fill(reference);
    await this.notifiedAmountInput.fill(amount);
    await this.notifyButton.click();
  }

  async confirmPayment(amount: string): Promise<void> {
    await this.paidAmountInput.fill(amount);
    await this.confirmButton.click();
  }

  async expectFeedbackContains(text: string): Promise<void> {
    await expect(this.feedback).toBeVisible();
    await expect(this.feedback).toContainText(text);
  }
}
