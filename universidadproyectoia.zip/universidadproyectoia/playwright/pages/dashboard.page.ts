import { expect, Locator, Page } from "@playwright/test";

export class DashboardPage {
  readonly page: Page;
  readonly refreshButton: Locator;
  readonly kpis: Locator;
  readonly statusChart: Locator;

  constructor(page: Page) {
    this.page = page;
    this.refreshButton = page.locator("#dashboard-refresh");
    this.kpis = page.locator("#dashboard-kpis");
    this.statusChart = page.locator("#dashboard-status-chart");
  }

  async goto(): Promise<void> {
    await this.page.goto("/dashboard");
  }

  async refresh(): Promise<void> {
    await this.refreshButton.click();
  }

  async expectLoaded(): Promise<void> {
    await expect(this.kpis).toBeVisible();
    await expect(this.statusChart).toBeVisible();
  }
}
