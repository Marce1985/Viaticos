import { test } from "../fixtures/app";
import { showDemoStep } from "../utils/demo-narrator";
import { solicitudDemo } from "../utils/test-data";

test("se puede guardar un borrador y radicar una solicitud", async ({ solicitudPage }) => {
  await solicitudPage.goto();
  await showDemoStep(solicitudPage.page, "Abrimos Solicitud y comenzamos a diligenciar el formulario.");

  await showDemoStep(solicitudPage.page, "Seleccionamos solicitante, jefe y centro de costo.");
  await solicitudPage.selectDropdownOption(solicitudPage.employeeDropdown, "Carlos Mejia");
  await solicitudPage.selectDropdownOption(solicitudPage.managerDropdown, "Laura Ramirez");
  await solicitudPage.selectDropdownOption(solicitudPage.costCenterDropdown, "CC-IA");

  await showDemoStep(solicitudPage.page, "Activamos banderas que modifican la ruta de aprobacion.");
  await solicitudPage.enableFlag("Requiere tiquetes");
  await solicitudPage.enableFlag("Destino internacional");

  await showDemoStep(solicitudPage.page, "Completamos los datos del viaje y el presupuesto estimado.");
  await solicitudPage.fillCoreForm({
    destination: solicitudDemo.destination,
    country: solicitudDemo.country,
    purpose: solicitudDemo.purpose,
    estimatedAmount: solicitudDemo.estimatedAmount,
    currency: solicitudDemo.currency,
    exchangeRate: solicitudDemo.exchangeRate,
  });

  await showDemoStep(solicitudPage.page, "Guardamos primero la solicitud como borrador.");
  await solicitudPage.saveDraft();
  await solicitudPage.expectFeedbackContains("Borrador guardado");

  await showDemoStep(solicitudPage.page, "Radicamos la solicitud para enviarla al workflow de aprobacion.");
  await solicitudPage.submitRequest();
  await solicitudPage.expectFeedbackContains("Solicitud radicada");

  await showDemoStep(solicitudPage.page, "La creacion y radicacion de la solicitud fue exitosa.");
});
