import { test, expect } from "../fixtures/app";
import { showDemoStep } from "../utils/demo-narrator";

test("la aplicacion carga y navega entre modulos principales", async ({
  page,
  homePage,
  solicitudPage,
  aprobacionesPage,
  pagosPage,
  legalizacionPage,
  dashboardPage,
}) => {
  await showDemoStep(page, "Iniciando la demostracion: abrimos el portal principal.");
  await homePage.goto();
  await homePage.expectLoaded();

  await showDemoStep(page, "Entramos al modulo de Solicitud para validar la captura inicial.");
  await solicitudPage.goto();
  await expect(page.locator("#solicitud-save-draft")).toBeVisible();

  await showDemoStep(page, "Ahora revisamos la bandeja de Aprobaciones y su trazabilidad.");
  await aprobacionesPage.goto();
  await expect(page.locator("#aprobaciones-role-filter")).toBeVisible();

  await showDemoStep(page, "Pasamos al modulo de Pagos para ver la cola operativa.");
  await pagosPage.goto();
  await expect(page.locator("#pagos-refresh")).toBeVisible();

  await showDemoStep(page, "Abrimos Legalizacion para mostrar la conciliacion financiera.");
  await legalizacionPage.goto();
  await expect(page.locator("#legalizacion-refresh")).toBeVisible();

  await showDemoStep(page, "Cerramos en Dashboard con la vista ejecutiva y los indicadores.");
  await dashboardPage.goto();
  await dashboardPage.expectLoaded();

  await showDemoStep(page, "La navegacion principal de la app quedo validada correctamente.");
});
