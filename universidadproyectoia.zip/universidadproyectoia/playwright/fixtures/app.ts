import { test as base } from "@playwright/test";

import { AprobacionesPage } from "../pages/aprobaciones.page";
import { DashboardPage } from "../pages/dashboard.page";
import { HomePage } from "../pages/home.page";
import { LegalizacionPage } from "../pages/legalizacion.page";
import { PagosPage } from "../pages/pagos.page";
import { SolicitudPage } from "../pages/solicitud.page";

type AppFixtures = {
  homePage: HomePage;
  solicitudPage: SolicitudPage;
  aprobacionesPage: AprobacionesPage;
  pagosPage: PagosPage;
  legalizacionPage: LegalizacionPage;
  dashboardPage: DashboardPage;
};

export const test = base.extend<AppFixtures>({
  homePage: async ({ page }, use) => {
    await use(new HomePage(page));
  },
  solicitudPage: async ({ page }, use) => {
    await use(new SolicitudPage(page));
  },
  aprobacionesPage: async ({ page }, use) => {
    await use(new AprobacionesPage(page));
  },
  pagosPage: async ({ page }, use) => {
    await use(new PagosPage(page));
  },
  legalizacionPage: async ({ page }, use) => {
    await use(new LegalizacionPage(page));
  },
  dashboardPage: async ({ page }, use) => {
    await use(new DashboardPage(page));
  },
});

export { expect } from "@playwright/test";
