from sqlalchemy.orm import Session

from repositories.catalog_repository import CatalogRepository


class CatalogService:
    def __init__(self, session: Session) -> None:
        self.catalog_repository = CatalogRepository(session)

    def get_employee_options(self) -> list[dict[str, object]]:
        employees = self.catalog_repository.list_employees()
        return [{"label": f"{employee.full_name} ({employee.email})", "value": employee.id} for employee in employees]

    def get_cost_center_options(self) -> list[dict[str, object]]:
        cost_centers = self.catalog_repository.list_cost_centers()
        return [
            {
                "label": f"{cost_center.code} · {cost_center.name}",
                "value": cost_center.id,
            }
            for cost_center in cost_centers
        ]
