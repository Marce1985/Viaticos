from dataclasses import dataclass
from pathlib import Path

from jinja2 import Environment, FileSystemLoader, select_autoescape
from sqlalchemy.orm import Session

from domain.enums import DocumentType
from integrations.gemini_client import GeminiClient
from integrations.sharepoint_client import SharePointClient
from repositories.auditoria_repository import AuditoriaRepository
from repositories.document_repository import DocumentRepository
from repositories.solicitud_repository import SolicitudRepository
from schemas.document_ai_schema import (
    ApprovalSummary,
    DocumentClassification,
    InvitationData,
    NormalizedExpense,
)
from services.auditoria_service import AuditoriaService


@dataclass(slots=True)
class GeneratedDocument:
    document_type: DocumentType
    file_name: str
    storage_path: str
    content: str


class DocumentosServiceError(ValueError):
    """Raised when document generation cannot be completed."""


class DocumentosService:
    def __init__(
        self,
        gemini_client: GeminiClient | None = None,
        *,
        session: Session | None = None,
        sharepoint_client: SharePointClient | None = None,
        templates_dir: str | Path | None = None,
    ) -> None:
        self.gemini_client = gemini_client or GeminiClient()
        self.session = session
        self.sharepoint_client = sharepoint_client or SharePointClient()
        self.templates_dir = Path(templates_dir or "templates")
        self.template_environment = Environment(
            loader=FileSystemLoader(self.templates_dir),
            autoescape=select_autoescape(enabled_extensions=("html",)),
        )
        self.document_repository = DocumentRepository(session) if session else None
        self.solicitud_repository = SolicitudRepository(session) if session else None
        self.auditoria_service = AuditoriaService(AuditoriaRepository(session)) if session else None

    def extract_invitation_data(self, file_text: str) -> InvitationData:
        return self.gemini_client.extract_invitation_data(file_text)

    def classify_supporting_document(self, text: str) -> DocumentClassification:
        return self.gemini_client.classify_supporting_document(text)

    def summarize_approval_comments(self, comments: list[str]) -> ApprovalSummary:
        return self.gemini_client.summarize_approval_comments(comments)

    def normalize_expense_item(self, raw_text: str) -> NormalizedExpense:
        return self.gemini_client.normalize_expense_item(raw_text)

    def generate_commission_resolution(self, request_id: int) -> GeneratedDocument:
        return self._generate_document(
            request_id=request_id,
            document_type=DocumentType.RESOLUCION,
            template_name="resolucion_comision.html.j2",
            version=1,
        )

    def generate_base_letter(self, request_id: int) -> GeneratedDocument:
        return self._generate_document(
            request_id=request_id,
            document_type=DocumentType.CARTA_BASE,
            template_name="carta_base.html.j2",
            version=1,
        )

    def generate_checklist(self, request_id: int) -> GeneratedDocument:
        return self._generate_document(
            request_id=request_id,
            document_type=DocumentType.CHECKLIST,
            template_name="checklist.html.j2",
            version=1,
        )

    def generate_document_package(self, request_id: int) -> list[GeneratedDocument]:
        return [
            self.generate_commission_resolution(request_id),
            self.generate_base_letter(request_id),
            self.generate_checklist(request_id),
        ]

    def _generate_document(
        self,
        *,
        request_id: int,
        document_type: DocumentType,
        template_name: str,
        version: int,
    ) -> GeneratedDocument:
        if self.session is None or self.document_repository is None or self.solicitud_repository is None:
            raise DocumentosServiceError("A database session is required for document generation.")
        request = self.solicitud_repository.get_by_id(request_id)
        if request is None:
            raise DocumentosServiceError(f"Travel request {request_id} was not found.")

        template = self.template_environment.get_template(template_name)
        context = {
            "request": request,
            "document_title": document_type.value.replace("_", " ").title(),
            "version": version,
        }
        content = template.render(**context)
        file_name = self._build_file_name(
            request_code=request.request_code,
            document_type=document_type,
            version=version,
        )
        storage_path = self.sharepoint_client.save_document(
            request_code=request.request_code,
            file_name=file_name,
            content=content,
        )
        self.document_repository.create_document(
            request_id=request.id,
            document_type=document_type,
            file_name=file_name,
            storage_path=storage_path,
        )
        if self.auditoria_service:
            self.auditoria_service.log(
                event_type="DOCUMENT_GENERATED",
                request_id=request.id,
                actor_id=request.employee_id,
                details=f"Documento {document_type.value} generado: {file_name}",
            )
        self.session.commit()
        return GeneratedDocument(
            document_type=document_type,
            file_name=file_name,
            storage_path=storage_path,
            content=content,
        )

    def _build_file_name(
        self,
        *,
        request_code: str,
        document_type: DocumentType,
        version: int,
    ) -> str:
        suffix = document_type.value.lower()
        return f"{request_code}_{suffix}_v{version:02d}.html"
