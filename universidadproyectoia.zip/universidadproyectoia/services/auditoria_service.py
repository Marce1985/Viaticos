from repositories.auditoria_repository import AuditoriaRepository


class AuditoriaService:
    def __init__(self, auditoria_repository: AuditoriaRepository) -> None:
        self.auditoria_repository = auditoria_repository

    def log(
        self,
        *,
        event_type: str,
        request_id: int | None = None,
        actor_id: int | None = None,
        details: str | None = None,
    ) -> None:
        self.auditoria_repository.log_event(
            event_type=event_type,
            request_id=request_id,
            actor_id=actor_id,
            details=details,
        )
