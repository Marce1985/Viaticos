from collections import Counter, defaultdict
from datetime import UTC, datetime
from decimal import Decimal

import plotly.graph_objects as go
from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload

from database.models import ExpenseReportModel, PaymentOrderModel, TravelRequestModel
from domain.enums import TravelRequestStatus


class DashboardService:
    SLA_DAYS = 5

    def __init__(self, session: Session) -> None:
        self.session = session

    def get_dashboard_metrics(self) -> dict[str, object]:
        requests = list(self.session.scalars(select(TravelRequestModel).order_by(TravelRequestModel.created_at.desc())).all())
        payment_orders = list(self.session.scalars(select(PaymentOrderModel).order_by(PaymentOrderModel.created_at.desc())).all())
        expense_reports = list(self.session.scalars(select(ExpenseReportModel).options(joinedload(ExpenseReportModel.expense_items))).unique().all())

        status_counts = Counter(request.status.value for request in requests)
        stage_durations = self._average_days_by_stage(requests)
        overdue_requests = self._overdue_requests(requests)
        approved_amount = sum(
            (Decimal(order.approved_amount) for order in payment_orders),
            start=Decimal("0"),
        )
        pending_payments = sum(
            1
            for order in payment_orders
            if self._request_status(order.request_id)
            in {
                TravelRequestStatus.APROBADA_PARA_PAGO,
                TravelRequestStatus.PAGO_NOTIFICADO,
            }
        )
        legalization_issues = sum(
            1 for report in expense_reports if Decimal(report.balance_favor_employee) > 0 or Decimal(report.balance_reimbursement_company) > 0
        )

        return {
            "kpis": [
                {"label": "Solicitudes activas", "value": str(len(requests))},
                {"label": "Pagos pendientes", "value": str(pending_payments)},
                {"label": "Legalizaciones con diferencia", "value": str(legalization_issues)},
                {"label": "Monto aprobado", "value": f"COP {approved_amount:,.2f}"},
            ],
            "status_figure": self.build_status_figure(status_counts),
            "stage_figure": self.build_stage_figure(stage_durations),
            "payment_figure": self.build_payment_figure(payment_orders),
            "sla_figure": self.build_sla_figure(overdue_requests, len(requests)),
        }

    def build_status_figure(self, status_counts: Counter[str]) -> go.Figure:
        labels = list(status_counts.keys()) or ["Sin datos"]
        values = list(status_counts.values()) or [0]
        figure = go.Figure(
            data=[
                go.Bar(
                    x=labels,
                    y=values,
                    marker_color=["#1f6feb", "#0f8b8d", "#c48a1a", "#5a6b80"] * 4,
                )
            ]
        )
        figure.update_layout(
            title="Solicitudes por estado",
            margin=dict(l=20, r=20, t=50, b=20),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
        )
        return figure

    def build_stage_figure(self, stage_durations: dict[str, float]) -> go.Figure:
        labels = list(stage_durations.keys()) or ["Sin datos"]
        values = list(stage_durations.values()) or [0]
        figure = go.Figure(
            data=[
                go.Scatter(
                    x=labels,
                    y=values,
                    mode="lines+markers",
                    line=dict(color="#0f8b8d", width=3),
                    marker=dict(size=10, color="#1f6feb"),
                    fill="tozeroy",
                )
            ]
        )
        figure.update_layout(
            title="Tiempo promedio por etapa (dias)",
            margin=dict(l=20, r=20, t=50, b=20),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
        )
        return figure

    def build_payment_figure(self, payment_orders: list[PaymentOrderModel]) -> go.Figure:
        labels = [f"REQ {order.request_id}" for order in payment_orders] or ["Sin datos"]
        approved = [float(order.approved_amount) for order in payment_orders] or [0]
        paid = [float(order.paid_amount or 0) for order in payment_orders] or [0]
        figure = go.Figure()
        figure.add_bar(name="Aprobado", x=labels, y=approved, marker_color="#1f6feb")
        figure.add_bar(name="Girado", x=labels, y=paid, marker_color="#0f8b8d")
        figure.update_layout(
            barmode="group",
            title="Comparativo aprobado vs girado",
            margin=dict(l=20, r=20, t=50, b=20),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
        )
        return figure

    def build_sla_figure(self, overdue_requests: int, total_requests: int) -> go.Figure:
        on_time = max(total_requests - overdue_requests, 0)
        figure = go.Figure(
            data=[
                go.Pie(
                    labels=["En SLA", "Fuera de SLA"],
                    values=[on_time, overdue_requests],
                    hole=0.55,
                    marker=dict(colors=["#0f8b8d", "#c48a1a"]),
                )
            ]
        )
        figure.update_layout(
            title="Solicitudes vencidas por SLA",
            margin=dict(l=20, r=20, t=50, b=20),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
        )
        return figure

    def _average_days_by_stage(self, requests: list[TravelRequestModel]) -> dict[str, float]:
        now = datetime.now(UTC)
        grouped: dict[str, list[float]] = defaultdict(list)
        for request in requests:
            started_at = self._ensure_aware(request.created_at)
            updated_at = self._ensure_aware(request.updated_at) if request.updated_at else now
            duration = max((updated_at - started_at).total_seconds() / 86400, 0)
            grouped[request.status.value].append(round(duration, 2))
        return {status: round(sum(values) / len(values), 2) for status, values in grouped.items()}

    def _overdue_requests(self, requests: list[TravelRequestModel]) -> int:
        now = datetime.now(UTC)
        return sum(
            1
            for request in requests
            if (now - self._ensure_aware(request.created_at)).days > self.SLA_DAYS
            and request.status not in {TravelRequestStatus.CERRADA, TravelRequestStatus.LEGALIZADA}
        )

    def _request_status(self, request_id: int) -> TravelRequestStatus | None:
        request = self.session.get(TravelRequestModel, request_id)
        return request.status if request is not None else None

    def _ensure_aware(self, value: datetime) -> datetime:
        if value.tzinfo is None:
            return value.replace(tzinfo=UTC)
        return value.astimezone(UTC)
