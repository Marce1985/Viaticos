from decimal import ROUND_HALF_UP, Decimal

from sqlalchemy.orm import Session

from domain.enums import TravelRequestStatus
from domain.workflows import TravelRequestWorkflow, WorkflowTransitionError
from repositories.auditoria_repository import AuditoriaRepository
from repositories.legalizacion_repository import LegalizacionRepository
from repositories.pago_repository import PagoRepository
from repositories.solicitud_repository import SolicitudRepository
from schemas.legalizacion_schema import (
    ExpenseItemInput,
    ExpenseItemResponse,
    LegalizationCloseInput,
    LegalizationSummaryResponse,
)
from services.auditoria_service import AuditoriaService


def _round_money(value: Decimal) -> Decimal:
    return value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


class LegalizacionServiceError(ValueError):
    """Raised when the legalization flow cannot be completed."""


class LegalizacionService:
    LEGALIZATION_QUEUE_STATUSES = {
        TravelRequestStatus.PAGO_CONFIRMADO,
        TravelRequestStatus.EN_LEGALIZACION,
        TravelRequestStatus.LEGALIZADA,
    }

    def __init__(self, session: Session) -> None:
        self.session = session
        self.legalizacion_repository = LegalizacionRepository(session)
        self.pago_repository = PagoRepository(session)
        self.solicitud_repository = SolicitudRepository(session)
        self.auditoria_service = AuditoriaService(AuditoriaRepository(session))

    def add_expense_item(self, payload: ExpenseItemInput) -> LegalizationSummaryResponse:
        request = self.solicitud_repository.get_by_id(payload.request_id)
        if request is None:
            raise LegalizacionServiceError(f"Travel request {payload.request_id} was not found.")

        payment_order = self.pago_repository.get_by_request_id(payload.request_id)
        if payment_order is None or payment_order.paid_amount is None:
            raise LegalizacionServiceError("A confirmed payment is required before legalization.")

        workflow = TravelRequestWorkflow([])
        if request.status == TravelRequestStatus.PAGO_CONFIRMADO:
            try:
                self.solicitud_repository.update_status(
                    request.id,
                    workflow.start_legalization(request.status),
                )
                request = self.solicitud_repository.get_by_id(request.id)
                if request is None:
                    raise LegalizacionServiceError("Travel request could not be reloaded.")
            except WorkflowTransitionError as exc:
                raise LegalizacionServiceError(str(exc)) from exc

        report = self.legalizacion_repository.get_report_by_request_id(payload.request_id)
        advance_paid = _round_money(payment_order.paid_amount)
        approved_amount = _round_money(payment_order.approved_amount)
        if report is None:
            report = self.legalizacion_repository.create_expense_report(
                request_id=payload.request_id,
                approved_amount=approved_amount,
                advance_paid=advance_paid,
                supported_amount=Decimal("0"),
                balance_favor_employee=Decimal("0"),
                balance_reimbursement_company=advance_paid,
            )

        converted_amount = self._convert_to_request_currency(
            amount=payload.amount,
            item_currency=payload.currency,
            request_currency=request.currency,
            exchange_rate=payload.exchange_rate,
        )
        self.legalizacion_repository.add_expense_item(
            report_id=report.id,
            category=payload.category,
            amount=converted_amount,
            currency=request.currency,
            vendor=payload.vendor,
            expense_date=payload.expense_date,
            description=payload.description,
        )

        summary = self._recalculate_report(report.request_id)
        self.auditoria_service.log(
            event_type="LEGALIZATION_ITEM_ADDED",
            request_id=payload.request_id,
            actor_id=request.employee_id,
            details=(f"Gasto registrado: {payload.category} por {payload.currency} {payload.amount}."),
        )
        self.session.commit()
        return summary

    def close_legalization(self, payload: LegalizationCloseInput) -> LegalizationSummaryResponse:
        request = self.solicitud_repository.get_by_id(payload.request_id)
        if request is None:
            raise LegalizacionServiceError(f"Travel request {payload.request_id} was not found.")

        report = self.legalizacion_repository.get_report_by_request_id(payload.request_id)
        if report is None:
            raise LegalizacionServiceError("A legalization report is required before closing.")

        summary = self._recalculate_report(payload.request_id)
        workflow = TravelRequestWorkflow([])
        try:
            legalized_status = workflow.legalize(request.status)
        except WorkflowTransitionError as exc:
            raise LegalizacionServiceError(str(exc)) from exc

        updated_request = self.solicitud_repository.update_status(payload.request_id, legalized_status)
        if updated_request is None:
            raise LegalizacionServiceError("Travel request could not be updated during closure.")

        self.auditoria_service.log(
            event_type="LEGALIZATION_CLOSED",
            request_id=payload.request_id,
            actor_id=request.employee_id,
            details=(
                "Legalizacion cerrada. "
                f"Soportado: {summary.currency} {summary.supported_amount}. "
                f"Saldo empleado: {summary.balance_favor_employee}. "
                f"Reintegro compania: {summary.balance_reimbursement_company}."
            ),
        )
        self.session.commit()
        return summary.model_copy(update={"request_status": legalized_status})

    def get_legalization_detail(self, request_id: int) -> LegalizationSummaryResponse:
        request = self.solicitud_repository.get_by_id(request_id)
        if request is None:
            raise LegalizacionServiceError(f"Travel request {request_id} was not found.")
        report = self.legalizacion_repository.get_report_by_request_id(request_id)
        if report is None:
            payment_order = self.pago_repository.get_by_request_id(request_id)
            if payment_order is None or payment_order.paid_amount is None:
                raise LegalizacionServiceError("A confirmed payment is required before legalization.")
            return LegalizationSummaryResponse(
                request_id=request.id,
                request_status=request.status,
                approved_amount=_round_money(payment_order.approved_amount),
                advance_paid=_round_money(payment_order.paid_amount),
                supported_amount=Decimal("0.00"),
                balance_favor_employee=Decimal("0.00"),
                balance_reimbursement_company=_round_money(payment_order.paid_amount),
                currency=request.currency,
                items=[],
            )
        return self._summary_from_report(request.status, request.currency, report)

    def list_legalization_queue(self) -> list[dict[str, object]]:
        queue: list[dict[str, object]] = []
        for payment_order in self.pago_repository.list_payment_orders():
            request = self.solicitud_repository.get_by_id(payment_order.request_id)
            if request is None or request.status not in self.LEGALIZATION_QUEUE_STATUSES:
                continue
            report = self.legalizacion_repository.get_report_by_request_id(request.id)
            queue.append(
                {
                    "request_id": request.id,
                    "request_code": request.request_code,
                    "destination": request.destination,
                    "status": request.status.value,
                    "approved_amount": f"{request.currency} {payment_order.approved_amount}",
                    "supported_amount": (f"{request.currency} {report.supported_amount}" if report else "Pendiente"),
                }
            )
        return queue

    def _recalculate_report(self, request_id: int) -> LegalizationSummaryResponse:
        request = self.solicitud_repository.get_by_id(request_id)
        report = self.legalizacion_repository.get_report_by_request_id(request_id)
        if request is None or report is None:
            raise LegalizacionServiceError("Legalization report could not be recalculated.")

        supported_amount = _round_money(sum((Decimal(item.amount) for item in report.expense_items), start=Decimal("0")))
        advance_paid = _round_money(report.advance_paid)
        difference = supported_amount - advance_paid
        balance_favor_employee = _round_money(difference if difference > 0 else Decimal("0"))
        balance_reimbursement_company = _round_money(-difference if difference < 0 else Decimal("0"))

        updated_report = self.legalizacion_repository.update_report(
            report.id,
            supported_amount=supported_amount,
            balance_favor_employee=balance_favor_employee,
            balance_reimbursement_company=balance_reimbursement_company,
        )
        if updated_report is None:
            raise LegalizacionServiceError("Legalization report could not be updated.")
        refreshed_report = self.legalizacion_repository.get_report_by_id(report.id)
        if refreshed_report is None:
            raise LegalizacionServiceError("Legalization report could not be reloaded.")
        return self._summary_from_report(request.status, request.currency, refreshed_report)

    def _summary_from_report(
        self,
        request_status: TravelRequestStatus,
        currency: str,
        report: object,
    ) -> LegalizationSummaryResponse:
        return LegalizationSummaryResponse(
            request_id=report.request_id,
            request_status=request_status,
            approved_amount=_round_money(Decimal(report.approved_amount)),
            advance_paid=_round_money(Decimal(report.advance_paid)),
            supported_amount=_round_money(Decimal(report.supported_amount)),
            balance_favor_employee=_round_money(Decimal(report.balance_favor_employee)),
            balance_reimbursement_company=_round_money(Decimal(report.balance_reimbursement_company)),
            currency=currency,
            items=[ExpenseItemResponse.model_validate(item) for item in report.expense_items],
        )

    def _convert_to_request_currency(
        self,
        *,
        amount: Decimal,
        item_currency: str,
        request_currency: str,
        exchange_rate: Decimal | None,
    ) -> Decimal:
        if item_currency.upper() == request_currency.upper():
            return _round_money(amount)
        if exchange_rate is None:
            raise LegalizacionServiceError("Exchange rate is required when the expense currency differs from the request currency.")
        return _round_money(amount * exchange_rate)
