from sqlalchemy.orm import Session

from domain.enums import ApprovalDecision, ApprovalRole
from domain.workflows import ROLE_TO_STATUS, TravelRequestWorkflow
from repositories.aprobacion_repository import AprobacionRepository
from repositories.auditoria_repository import AuditoriaRepository
from repositories.solicitud_repository import SolicitudRepository
from schemas.aprobacion_schema import (
    ApprovalActionInput,
    ApprovalActionResponse,
    ApprovalEventResponse,
)
from services.auditoria_service import AuditoriaService


class AprobacionServiceError(ValueError):
    """Raised when an approval action cannot be completed."""


class AprobacionService:
    def __init__(self, session: Session) -> None:
        self.session = session
        self.solicitud_repository = SolicitudRepository(session)
        self.aprobacion_repository = AprobacionRepository(session)
        self.auditoria_service = AuditoriaService(AuditoriaRepository(session))

    def approve(self, action_input: ApprovalActionInput) -> ApprovalActionResponse:
        return self._apply_decision(action_input, ApprovalDecision.APROBAR)

    def reject(self, action_input: ApprovalActionInput) -> ApprovalActionResponse:
        return self._apply_decision(action_input, ApprovalDecision.RECHAZAR)

    def return_for_adjustments(self, action_input: ApprovalActionInput) -> ApprovalActionResponse:
        return self._apply_decision(action_input, ApprovalDecision.DEVOLVER)

    def get_role_options(self) -> list[dict[str, str]]:
        return [{"label": role.value.replace("_", " "), "value": role.value} for role in ROLE_TO_STATUS]

    def get_inbox(self, role: ApprovalRole) -> list[dict[str, object]]:
        requests = self.aprobacion_repository.list_inbox_by_role(role)
        return [
            {
                "request_id": request.id,
                "request_code": request.request_code,
                "destination": request.destination,
                "country": request.country,
                "employee_id": request.employee_id,
                "estimated_amount": f"{request.currency} {request.estimated_amount}",
                "status": request.status.value,
            }
            for request in requests
        ]

    def get_request_detail(self, request_id: int) -> dict[str, object]:
        request = self.solicitud_repository.get_by_id(request_id)
        if request is None:
            raise AprobacionServiceError(f"Travel request {request_id} was not found.")

        steps = self.aprobacion_repository.list_steps_for_request(request_id)
        events = self.aprobacion_repository.list_events_for_request(request_id)
        timeline = self.auditoria_service.auditoria_repository.list_timeline(request_id)

        return {
            "request_id": request.id,
            "request_code": request.request_code,
            "status": request.status.value,
            "destination": request.destination,
            "country": request.country,
            "travel_purpose": request.travel_purpose,
            "employee_id": request.employee_id,
            "manager_id": request.manager_id,
            "cost_center_id": request.cost_center_id,
            "estimated_amount": f"{request.currency} {request.estimated_amount}",
            "start_date": request.start_date.isoformat(),
            "end_date": request.end_date.isoformat(),
            "steps": [
                {
                    "role": step.role.value,
                    "status": step.status.value,
                    "sequence": step.sequence,
                    "is_completed": step.is_completed,
                    "comments": step.comments or "",
                }
                for step in steps
            ],
            "events": [
                {
                    "role": event.role.value,
                    "decision": event.decision.value,
                    "comments": event.comments or "",
                    "created_at": event.created_at.isoformat(),
                }
                for event in events
            ],
            "timeline": [
                {
                    "event_type": item.event_type,
                    "details": item.details or "",
                    "created_at": item.created_at.isoformat(),
                }
                for item in timeline
            ],
        }

    def _apply_decision(
        self,
        action_input: ApprovalActionInput,
        decision: ApprovalDecision,
    ) -> ApprovalActionResponse:
        request = self.solicitud_repository.get_by_id(action_input.request_id)
        if request is None:
            raise AprobacionServiceError(f"Travel request {action_input.request_id} was not found.")

        approval_steps = sorted(request.approval_steps, key=lambda step: step.sequence)
        approval_route = [step.role for step in approval_steps]
        workflow = TravelRequestWorkflow(approval_route)

        expected_status = ROLE_TO_STATUS[action_input.role]
        if request.status != expected_status:
            raise AprobacionServiceError(f"Role {action_input.role.value} cannot act on request in status {request.status.value}.")

        current_step = next(
            (step for step in approval_steps if step.role == action_input.role and step.status == request.status and not step.is_completed),
            None,
        )
        if current_step is None:
            raise AprobacionServiceError(f"No pending approval step was found for role {action_input.role.value}.")

        previous_status = request.status
        if decision == ApprovalDecision.APROBAR:
            new_status = workflow.approve(request.status)
        elif decision == ApprovalDecision.RECHAZAR:
            new_status = workflow.reject(request.status)
        else:
            new_status = workflow.return_for_adjustments(request.status)

        self.aprobacion_repository.mark_step_completed(
            current_step.id,
            acted_by_employee_id=action_input.actor_id,
            comments=action_input.comments,
        )
        event = self.aprobacion_repository.create_event(
            request_id=request.id,
            role=action_input.role,
            decision=decision,
            comments=action_input.comments,
        )
        updated_request = self.solicitud_repository.update_status(request.id, new_status)
        if updated_request is None:
            raise AprobacionServiceError(f"Travel request {request.id} could not be updated.")

        self.auditoria_service.log(
            event_type=f"APPROVAL_{decision.value}",
            request_id=request.id,
            actor_id=action_input.actor_id,
            details=(
                f"Rol {action_input.role.value} ejecuto accion {decision.value}. "
                f"Estado anterior: {previous_status.value}. Nuevo estado: {new_status.value}."
            ),
        )
        self.session.commit()
        return ApprovalActionResponse(
            request_id=request.id,
            previous_status=previous_status,
            new_status=new_status,
            decision=decision,
            event=ApprovalEventResponse.model_validate(event),
        )
