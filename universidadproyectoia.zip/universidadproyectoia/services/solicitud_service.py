from datetime import UTC, datetime
from uuid import uuid4

from sqlalchemy.orm import Session

from domain.entities import TravelRequest
from domain.rules import RoutingContext, determine_approval_route
from domain.workflows import ROLE_TO_STATUS, TravelRequestWorkflow
from repositories.aprobacion_repository import AprobacionRepository
from repositories.auditoria_repository import AuditoriaRepository
from repositories.solicitud_repository import SolicitudRepository
from schemas.solicitud_schema import SolicitudDraftInput, SolicitudResponse, SubmissionResponse
from services.auditoria_service import AuditoriaService


class SolicitudServiceError(ValueError):
    """Raised when a request operation cannot be completed."""


class SolicitudService:
    def __init__(
        self,
        session: Session,
        *,
        routing_context: RoutingContext | None = None,
    ) -> None:
        self.session = session
        self.routing_context = routing_context or RoutingContext()
        self.solicitud_repository = SolicitudRepository(session)
        self.aprobacion_repository = AprobacionRepository(session)
        self.auditoria_service = AuditoriaService(AuditoriaRepository(session))

    def save_draft(self, draft_input: SolicitudDraftInput) -> SolicitudResponse:
        return self.save_or_update_draft(draft_input)

    def save_or_update_draft(
        self,
        draft_input: SolicitudDraftInput,
        request_id: int | None = None,
    ) -> SolicitudResponse:
        request_code = draft_input.request_code or self._generate_request_code()
        payload = draft_input.model_dump(exclude={"request_code"})
        if request_id is None:
            request = self.solicitud_repository.create_request(
                **payload,
                request_code=request_code,
            )
            audit_event = "DRAFT_SAVED"
            audit_details = "Borrador guardado desde SolicitudService."
        else:
            request = self.solicitud_repository.update_request(
                request_id,
                **payload,
            )
            if request is None:
                raise SolicitudServiceError(f"Travel request {request_id} was not found.")
            audit_event = "DRAFT_UPDATED"
            audit_details = "Borrador actualizado desde SolicitudService."
        self.auditoria_service.log(
            event_type=audit_event,
            request_id=request.id,
            actor_id=request.employee_id,
            details=audit_details,
        )
        self.session.commit()
        self.session.refresh(request)
        return SolicitudResponse.model_validate(request)

    def submit_request(self, request_id: int) -> SubmissionResponse:
        request_model = self.solicitud_repository.get_by_id(request_id)
        if request_model is None:
            raise SolicitudServiceError(f"Travel request {request_id} was not found.")

        request_entity = self._to_entity(request_model)
        approval_route = determine_approval_route(request_entity, context=self.routing_context)
        workflow = TravelRequestWorkflow(approval_route)

        submitted_status = workflow.submit(request_model.status)
        current_status = workflow.start_approval_cycle(submitted_status)

        self.aprobacion_repository.delete_steps_for_request(request_model.id)
        for sequence, role in enumerate(approval_route, start=1):
            self.aprobacion_repository.create_step(
                request_id=request_model.id,
                role=role,
                sequence=sequence,
                status=ROLE_TO_STATUS[role],
            )

        updated_request = self.solicitud_repository.update_request(
            request_model.id,
            status=current_status,
            updated_at=datetime.now(UTC),
        )
        if updated_request is None:
            raise SolicitudServiceError(f"Travel request {request_id} could not be updated.")

        self.auditoria_service.log(
            event_type="REQUEST_SUBMITTED",
            request_id=updated_request.id,
            actor_id=updated_request.employee_id,
            details=("Solicitud radicada y enviada al flujo de aprobacion: " + ", ".join(role.value for role in approval_route)),
        )
        self.session.commit()
        refreshed_request = self.solicitud_repository.get_by_id(updated_request.id)
        if refreshed_request is None:
            raise SolicitudServiceError(f"Travel request {request_id} could not be reloaded.")
        return SubmissionResponse(
            request=SolicitudResponse.model_validate(refreshed_request),
            current_status=current_status,
            approval_route=approval_route,
        )

    def _generate_request_code(self) -> str:
        stamp = datetime.now(UTC).strftime("%Y%m%d")
        token = uuid4().hex[:6].upper()
        return f"SOL-{stamp}-{token}"

    def _to_entity(self, request_model: object) -> TravelRequest:
        return TravelRequest(
            request_id=request_model.id,
            request_code=request_model.request_code,
            employee_id=request_model.employee_id,
            manager_id=request_model.manager_id,
            cost_center_id=request_model.cost_center_id,
            destination=request_model.destination,
            country=request_model.country,
            start_date=request_model.start_date,
            end_date=request_model.end_date,
            travel_purpose=request_model.travel_purpose,
            requires_tickets=request_model.requires_tickets,
            requires_external_tools=request_model.requires_external_tools,
            requires_nda=request_model.requires_nda,
            destination_international=request_model.destination_international,
            estimated_amount=request_model.estimated_amount,
            currency=request_model.currency,
            exchange_rate_reference=request_model.exchange_rate_reference,
            status=request_model.status,
            created_at=request_model.created_at,
            updated_at=request_model.updated_at,
        )
