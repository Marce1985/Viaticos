from sqlalchemy.orm import Session

from domain.enums import TravelRequestStatus
from domain.workflows import TravelRequestWorkflow, WorkflowTransitionError
from repositories.auditoria_repository import AuditoriaRepository
from repositories.pago_repository import PagoRepository
from repositories.solicitud_repository import SolicitudRepository
from schemas.pago_schema import (
    PaymentActionResponse,
    PaymentConfirmationInput,
    PaymentNotificationInput,
    PaymentNotificationResponse,
    PaymentOrderCreateInput,
    PaymentOrderResponse,
)
from services.auditoria_service import AuditoriaService


class PagosServiceError(ValueError):
    """Raised when payment processing cannot be completed."""


class PagosService:
    PAYMENT_QUEUE_STATUSES = {
        TravelRequestStatus.APROBADA_PARA_PAGO,
        TravelRequestStatus.PAGO_NOTIFICADO,
        TravelRequestStatus.PAGO_CONFIRMADO,
    }

    def __init__(self, session: Session) -> None:
        self.session = session
        self.pago_repository = PagoRepository(session)
        self.solicitud_repository = SolicitudRepository(session)
        self.auditoria_service = AuditoriaService(AuditoriaRepository(session))

    def create_payment_order(self, payload: PaymentOrderCreateInput) -> PaymentActionResponse:
        request = self.solicitud_repository.get_by_id(payload.request_id)
        if request is None:
            raise PagosServiceError(f"Travel request {payload.request_id} was not found.")
        if request.status != TravelRequestStatus.APROBADA_PARA_PAGO:
            raise PagosServiceError("Payment order can only be created when the workflow is fully approved.")

        existing = self.pago_repository.get_by_request_id(payload.request_id)
        if existing is None:
            payment_order = self.pago_repository.create_payment_order(
                request_id=payload.request_id,
                approved_amount=payload.approved_amount,
                currency=payload.currency,
            )
        else:
            payment_order = self.pago_repository.update_payment_order(
                existing.id,
                approved_amount=payload.approved_amount,
                currency=payload.currency,
            )
            if payment_order is None:
                raise PagosServiceError("Payment order could not be updated.")

        self.auditoria_service.log(
            event_type="PAYMENT_ORDER_CREATED",
            request_id=request.id,
            actor_id=request.employee_id,
            details=(f"Orden de pago registrada por {payload.currency} {payload.approved_amount}."),
        )
        self.session.commit()
        return self._build_payment_action_response(payment_order, request.status)

    def notify_payment(self, payload: PaymentNotificationInput) -> PaymentActionResponse:
        request = self.solicitud_repository.get_by_id(payload.request_id)
        if request is None:
            raise PagosServiceError(f"Travel request {payload.request_id} was not found.")

        payment_order = self.pago_repository.get_by_request_id(payload.request_id)
        if payment_order is None:
            raise PagosServiceError("Payment order must exist before notification.")

        workflow = TravelRequestWorkflow([])
        try:
            new_status = workflow.notify_payment(request.status)
        except WorkflowTransitionError as exc:
            raise PagosServiceError(str(exc)) from exc

        updated_order = self.pago_repository.update_payment_order(
            payment_order.id,
            notified_amount=payload.notified_amount,
        )
        if updated_order is None:
            raise PagosServiceError("Payment order could not be updated for notification.")
        self.pago_repository.add_notification(
            payment_order_id=payment_order.id,
            sent_to=payload.sent_to,
            reference_code=payload.reference_code,
        )
        updated_request = self.solicitud_repository.update_status(request.id, new_status)
        if updated_request is None:
            raise PagosServiceError("Travel request could not be updated during notification.")

        self.auditoria_service.log(
            event_type="PAYMENT_NOTIFIED",
            request_id=request.id,
            actor_id=request.employee_id,
            details=(f"Pago notificado a {payload.sent_to} con referencia {payload.reference_code}."),
        )
        self.session.commit()
        refreshed_payment_order = self.pago_repository.get_by_id(payment_order.id)
        if refreshed_payment_order is None:
            raise PagosServiceError("Payment order could not be reloaded after notification.")
        return self._build_payment_action_response(refreshed_payment_order, new_status)

    def confirm_payment(self, payload: PaymentConfirmationInput) -> PaymentActionResponse:
        request = self.solicitud_repository.get_by_id(payload.request_id)
        if request is None:
            raise PagosServiceError(f"Travel request {payload.request_id} was not found.")

        payment_order = self.pago_repository.get_by_request_id(payload.request_id)
        if payment_order is None:
            raise PagosServiceError("Payment order must exist before confirmation.")

        workflow = TravelRequestWorkflow([])
        try:
            new_status = workflow.confirm_payment(request.status)
        except WorkflowTransitionError as exc:
            raise PagosServiceError(str(exc)) from exc

        updated_order = self.pago_repository.update_payment_order(
            payment_order.id,
            paid_amount=payload.paid_amount,
        )
        if updated_order is None:
            raise PagosServiceError("Payment order could not be updated during confirmation.")
        updated_request = self.solicitud_repository.update_status(request.id, new_status)
        if updated_request is None:
            raise PagosServiceError("Travel request could not be updated during payment confirmation.")

        self.auditoria_service.log(
            event_type="PAYMENT_CONFIRMED",
            request_id=request.id,
            actor_id=request.employee_id,
            details=f"Pago confirmado por valor {payment_order.currency} {payload.paid_amount}.",
        )
        self.session.commit()
        refreshed_payment_order = self.pago_repository.get_by_id(payment_order.id)
        if refreshed_payment_order is None:
            raise PagosServiceError("Payment order could not be reloaded after confirmation.")
        return self._build_payment_action_response(refreshed_payment_order, new_status)

    def list_payment_queue(self) -> list[dict[str, object]]:
        payment_orders = self.pago_repository.list_payment_orders()
        queue: list[dict[str, object]] = []
        for order in payment_orders:
            request = self.solicitud_repository.get_by_id(order.request_id)
            if request is None:
                continue
            if request.status not in self.PAYMENT_QUEUE_STATUSES:
                continue
            queue.append(
                {
                    "payment_order_id": order.id,
                    "request_id": order.request_id,
                    "request_code": request.request_code,
                    "destination": request.destination,
                    "status": request.status.value,
                    "approved_amount": f"{order.currency} {order.approved_amount}",
                    "notified_amount": (f"{order.currency} {order.notified_amount}" if order.notified_amount is not None else "Pendiente"),
                    "paid_amount": (f"{order.currency} {order.paid_amount}" if order.paid_amount is not None else "Pendiente"),
                }
            )
        return queue

    def _build_payment_action_response(
        self,
        payment_order: object,
        request_status: TravelRequestStatus,
    ) -> PaymentActionResponse:
        notifications = [PaymentNotificationResponse.model_validate(notification) for notification in getattr(payment_order, "notifications", [])]
        return PaymentActionResponse(
            payment_order=PaymentOrderResponse.model_validate(payment_order),
            request_status=request_status,
            notifications=notifications,
        )
