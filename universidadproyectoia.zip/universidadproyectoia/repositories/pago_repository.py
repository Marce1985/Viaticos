from sqlalchemy import select
from sqlalchemy.orm import joinedload

from database.models import PaymentNotificationModel, PaymentOrderModel
from repositories.base import BaseRepository


class PagoRepository(BaseRepository):
    def create_payment_order(
        self,
        *,
        request_id: int,
        approved_amount: object,
        currency: str,
        notified_amount: object | None = None,
        paid_amount: object | None = None,
    ) -> PaymentOrderModel:
        payment_order = PaymentOrderModel(
            request_id=request_id,
            approved_amount=approved_amount,
            currency=currency,
            notified_amount=notified_amount,
            paid_amount=paid_amount,
        )
        self.session.add(payment_order)
        self.session.flush()
        return payment_order

    def get_by_request_id(self, request_id: int) -> PaymentOrderModel | None:
        statement = select(PaymentOrderModel).options(joinedload(PaymentOrderModel.notifications)).where(PaymentOrderModel.request_id == request_id)
        return self.session.execute(statement).unique().scalar_one_or_none()

    def get_by_id(self, payment_order_id: int) -> PaymentOrderModel | None:
        statement = select(PaymentOrderModel).options(joinedload(PaymentOrderModel.notifications)).where(PaymentOrderModel.id == payment_order_id)
        return self.session.execute(statement).unique().scalar_one_or_none()

    def add_notification(
        self,
        *,
        payment_order_id: int,
        sent_to: str,
        reference_code: str,
    ) -> PaymentNotificationModel:
        notification = PaymentNotificationModel(
            payment_order_id=payment_order_id,
            sent_to=sent_to,
            reference_code=reference_code,
        )
        self.session.add(notification)
        self.session.flush()
        return notification

    def update_payment_order(
        self,
        payment_order_id: int,
        **changes: object,
    ) -> PaymentOrderModel | None:
        payment_order = self.session.get(PaymentOrderModel, payment_order_id)
        if payment_order is None:
            return None
        for field_name, value in changes.items():
            setattr(payment_order, field_name, value)
        self.session.flush()
        return payment_order

    def list_payment_orders(self) -> list[PaymentOrderModel]:
        return list(self.session.scalars(select(PaymentOrderModel).order_by(PaymentOrderModel.created_at.desc())).all())
