from sqlalchemy import select
from sqlalchemy.orm import joinedload

from database.models import ExpenseItemModel, ExpenseReportModel
from repositories.base import BaseRepository


class LegalizacionRepository(BaseRepository):
    def create_expense_report(
        self,
        *,
        request_id: int,
        approved_amount: object,
        advance_paid: object,
        supported_amount: object,
        balance_favor_employee: object,
        balance_reimbursement_company: object,
    ) -> ExpenseReportModel:
        report = ExpenseReportModel(
            request_id=request_id,
            approved_amount=approved_amount,
            advance_paid=advance_paid,
            supported_amount=supported_amount,
            balance_favor_employee=balance_favor_employee,
            balance_reimbursement_company=balance_reimbursement_company,
        )
        self.session.add(report)
        self.session.flush()
        return report

    def get_report_by_request_id(self, request_id: int) -> ExpenseReportModel | None:
        statement = (
            select(ExpenseReportModel).options(joinedload(ExpenseReportModel.expense_items)).where(ExpenseReportModel.request_id == request_id)
        )
        return self.session.execute(statement).unique().scalar_one_or_none()

    def get_report_by_id(self, report_id: int) -> ExpenseReportModel | None:
        statement = select(ExpenseReportModel).options(joinedload(ExpenseReportModel.expense_items)).where(ExpenseReportModel.id == report_id)
        return self.session.execute(statement).unique().scalar_one_or_none()

    def add_expense_item(
        self,
        *,
        report_id: int,
        category: str,
        amount: object,
        currency: str,
        vendor: str | None = None,
        expense_date: object | None = None,
        description: str | None = None,
    ) -> ExpenseItemModel:
        item = ExpenseItemModel(
            report_id=report_id,
            category=category,
            amount=amount,
            currency=currency,
            vendor=vendor,
            expense_date=expense_date,
            description=description,
        )
        self.session.add(item)
        self.session.flush()
        return item

    def update_report(self, report_id: int, **changes: object) -> ExpenseReportModel | None:
        report = self.session.get(ExpenseReportModel, report_id)
        if report is None:
            return None
        for field_name, value in changes.items():
            setattr(report, field_name, value)
        self.session.flush()
        return report

    def list_reports(self) -> list[ExpenseReportModel]:
        return list(self.session.scalars(select(ExpenseReportModel).order_by(ExpenseReportModel.created_at.desc())).all())
