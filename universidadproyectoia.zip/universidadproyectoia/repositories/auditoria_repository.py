from sqlalchemy import select

from database.models import AuditLogModel
from repositories.base import BaseRepository


class AuditoriaRepository(BaseRepository):
    def log_event(
        self,
        *,
        event_type: str,
        request_id: int | None = None,
        actor_id: int | None = None,
        details: str | None = None,
    ) -> AuditLogModel:
        entry = AuditLogModel(
            event_type=event_type,
            request_id=request_id,
            actor_id=actor_id,
            details=details,
        )
        self.session.add(entry)
        self.session.flush()
        return entry

    def list_timeline(self, request_id: int) -> list[AuditLogModel]:
        statement = (
            select(AuditLogModel).where(AuditLogModel.request_id == request_id).order_by(AuditLogModel.created_at.asc(), AuditLogModel.id.asc())
        )
        return list(self.session.scalars(statement).all())
