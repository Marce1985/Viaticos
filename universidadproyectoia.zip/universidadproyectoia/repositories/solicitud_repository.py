from datetime import UTC, datetime

from sqlalchemy import select
from sqlalchemy.orm import joinedload

from database.models import TravelRequestModel
from domain.enums import TravelRequestStatus
from repositories.base import BaseRepository


class SolicitudRepository(BaseRepository):
    def create_request(self, **request_data: object) -> TravelRequestModel:
        request = TravelRequestModel(**request_data)
        self.session.add(request)
        self.session.flush()
        return request

    def get_by_id(self, request_id: int) -> TravelRequestModel | None:
        statement = (
            select(TravelRequestModel)
            .options(
                joinedload(TravelRequestModel.approval_steps),
                joinedload(TravelRequestModel.approval_events),
                joinedload(TravelRequestModel.documents),
            )
            .where(TravelRequestModel.id == request_id)
        )
        return self.session.execute(statement).unique().scalar_one_or_none()

    def get_by_code(self, request_code: str) -> TravelRequestModel | None:
        statement = select(TravelRequestModel).where(TravelRequestModel.request_code == request_code)
        return self.session.scalar(statement)

    def list_by_status(self, status: TravelRequestStatus) -> list[TravelRequestModel]:
        statement = select(TravelRequestModel).where(TravelRequestModel.status == status).order_by(TravelRequestModel.created_at.desc())
        return list(self.session.scalars(statement).all())

    def update_status(self, request_id: int, status: TravelRequestStatus) -> TravelRequestModel | None:
        request = self.get_by_id(request_id)
        if request is None:
            return None
        request.status = status
        request.updated_at = datetime.now(UTC)
        self.session.flush()
        return request

    def update_request(self, request_id: int, **changes: object) -> TravelRequestModel | None:
        request = self.get_by_id(request_id)
        if request is None:
            return None
        for field_name, value in changes.items():
            setattr(request, field_name, value)
        request.updated_at = datetime.now(UTC)
        self.session.flush()
        return request
