from datetime import UTC, datetime

from sqlalchemy import Select, select
from sqlalchemy.orm import joinedload

from database.models import ApprovalEventModel, ApprovalStepModel, TravelRequestModel
from domain.enums import ApprovalDecision, ApprovalRole, TravelRequestStatus
from repositories.base import BaseRepository

ROLE_STATUS_MAP: dict[ApprovalRole, TravelRequestStatus] = {
    ApprovalRole.JEFE: TravelRequestStatus.EN_APROBACION_JEFE,
    ApprovalRole.GESTION_HUMANA: TravelRequestStatus.EN_VALIDACION_GH,
    ApprovalRole.PRESUPUESTO: TravelRequestStatus.EN_VALIDACION_PRESUPUESTO,
    ApprovalRole.COMPRAS: TravelRequestStatus.EN_VALIDACION_COMPRAS,
    ApprovalRole.SEGURIDAD_TI: TravelRequestStatus.EN_VALIDACION_SEGURIDAD_TI,
    ApprovalRole.JURIDICA: TravelRequestStatus.EN_VALIDACION_JURIDICA,
    ApprovalRole.APROBADOR_ADICIONAL: TravelRequestStatus.EN_VALIDACION_APROBADOR_ADICIONAL,
}


class AprobacionRepository(BaseRepository):
    def create_step(
        self,
        *,
        request_id: int,
        role: ApprovalRole,
        sequence: int,
        status: TravelRequestStatus | None = None,
    ) -> ApprovalStepModel:
        step = ApprovalStepModel(
            request_id=request_id,
            role=role,
            sequence=sequence,
            status=status or ROLE_STATUS_MAP[role],
        )
        self.session.add(step)
        self.session.flush()
        return step

    def list_steps_for_request(self, request_id: int) -> list[ApprovalStepModel]:
        statement = select(ApprovalStepModel).where(ApprovalStepModel.request_id == request_id).order_by(ApprovalStepModel.sequence.asc())
        return list(self.session.scalars(statement).all())

    def delete_steps_for_request(self, request_id: int) -> None:
        for step in self.list_steps_for_request(request_id):
            self.session.delete(step)
        self.session.flush()

    def list_inbox_by_role(self, role: ApprovalRole) -> list[TravelRequestModel]:
        status = ROLE_STATUS_MAP[role]
        statement: Select[tuple[TravelRequestModel]] = (
            select(TravelRequestModel)
            .options(joinedload(TravelRequestModel.approval_steps))
            .where(TravelRequestModel.status == status)
            .order_by(TravelRequestModel.updated_at.desc())
        )
        return list(self.session.execute(statement).unique().scalars().all())

    def create_event(
        self,
        *,
        request_id: int,
        role: ApprovalRole,
        decision: ApprovalDecision,
        comments: str | None = None,
    ) -> ApprovalEventModel:
        event = ApprovalEventModel(
            request_id=request_id,
            role=role,
            decision=decision,
            comments=comments,
        )
        self.session.add(event)
        self.session.flush()
        return event

    def list_events_for_request(self, request_id: int) -> list[ApprovalEventModel]:
        statement = select(ApprovalEventModel).where(ApprovalEventModel.request_id == request_id).order_by(ApprovalEventModel.created_at.asc())
        return list(self.session.scalars(statement).all())

    def mark_step_completed(
        self,
        step_id: int,
        *,
        acted_by_employee_id: int,
        comments: str | None = None,
    ) -> ApprovalStepModel | None:
        step = self.session.get(ApprovalStepModel, step_id)
        if step is None:
            return None
        step.is_completed = True
        step.acted_by_employee_id = acted_by_employee_id
        step.acted_at = datetime.now(UTC)
        step.comments = comments
        self.session.flush()
        return step
