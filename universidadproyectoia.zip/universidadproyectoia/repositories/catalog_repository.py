from sqlalchemy import select

from database.models import CostCenterModel, EmployeeModel
from repositories.base import BaseRepository


class CatalogRepository(BaseRepository):
    def create_employee(
        self,
        *,
        full_name: str,
        email: str,
        manager_id: int | None = None,
        cost_center_id: int | None = None,
    ) -> EmployeeModel:
        employee = EmployeeModel(
            full_name=full_name,
            email=email,
            manager_id=manager_id,
            cost_center_id=cost_center_id,
        )
        self.session.add(employee)
        self.session.flush()
        return employee

    def create_cost_center(self, *, code: str, name: str) -> CostCenterModel:
        cost_center = CostCenterModel(code=code, name=name)
        self.session.add(cost_center)
        self.session.flush()
        return cost_center

    def list_employees(self) -> list[EmployeeModel]:
        return list(self.session.scalars(select(EmployeeModel).order_by(EmployeeModel.full_name)).all())

    def list_cost_centers(self) -> list[CostCenterModel]:
        return list(self.session.scalars(select(CostCenterModel).order_by(CostCenterModel.code)).all())
