from sqlalchemy import select

from database.models import DocumentModel
from domain.enums import DocumentType
from repositories.base import BaseRepository


class DocumentRepository(BaseRepository):
    def create_document(
        self,
        *,
        request_id: int,
        document_type: DocumentType,
        file_name: str,
        storage_path: str,
    ) -> DocumentModel:
        document = DocumentModel(
            request_id=request_id,
            document_type=document_type,
            file_name=file_name,
            storage_path=storage_path,
        )
        self.session.add(document)
        self.session.flush()
        return document

    def list_for_request(self, request_id: int) -> list[DocumentModel]:
        statement = (
            select(DocumentModel).where(DocumentModel.request_id == request_id).order_by(DocumentModel.uploaded_at.asc(), DocumentModel.id.asc())
        )
        return list(self.session.scalars(statement).all())
