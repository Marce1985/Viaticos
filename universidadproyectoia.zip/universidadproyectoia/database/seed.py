from datetime import date
from decimal import Decimal

from sqlalchemy.orm import Session

from database.models import Base
from domain.enums import ApprovalDecision, ApprovalRole, TravelRequestStatus
from repositories.aprobacion_repository import AprobacionRepository
from repositories.auditoria_repository import AuditoriaRepository
from repositories.catalog_repository import CatalogRepository
from repositories.pago_repository import PagoRepository
from repositories.solicitud_repository import SolicitudRepository


def create_schema(session: Session) -> None:
    Base.metadata.create_all(session.get_bind())


def seed_local_data(session: Session) -> dict[str, int]:
    catalog_repository = CatalogRepository(session)
    solicitud_repository = SolicitudRepository(session)
    aprobacion_repository = AprobacionRepository(session)
    pago_repository = PagoRepository(session)
    auditoria_repository = AuditoriaRepository(session)

    data_science = catalog_repository.create_cost_center(code="CC-IA", name="Analitica e IA")
    operations = catalog_repository.create_cost_center(code="CC-OPS", name="Operaciones")

    manager = catalog_repository.create_employee(
        full_name="Laura Ramirez",
        email="laura.ramirez@example.com",
        cost_center_id=data_science.id,
    )
    traveler = catalog_repository.create_employee(
        full_name="Carlos Mejia",
        email="carlos.mejia@example.com",
        manager_id=manager.id,
        cost_center_id=data_science.id,
    )
    analyst = catalog_repository.create_employee(
        full_name="Valentina Torres",
        email="valentina.torres@example.com",
        manager_id=manager.id,
        cost_center_id=operations.id,
    )

    request = solicitud_repository.create_request(
        request_code="SOL-2026-0001",
        employee_id=traveler.id,
        manager_id=manager.id,
        cost_center_id=data_science.id,
        destination="Madrid",
        country="Espana",
        start_date=date(2026, 6, 10),
        end_date=date(2026, 6, 16),
        travel_purpose="Benchmarking de proveedores IA y seguridad",
        requires_tickets=True,
        requires_external_tools=True,
        requires_nda=False,
        destination_international=True,
        estimated_amount=Decimal("12800.00"),
        currency="EUR",
        exchange_rate_reference=Decimal("4325.50"),
        status=TravelRequestStatus.EN_VALIDACION_GH,
    )

    payable_request = solicitud_repository.create_request(
        request_code="SOL-2026-0002",
        employee_id=analyst.id,
        manager_id=manager.id,
        cost_center_id=operations.id,
        destination="Ciudad de Mexico",
        country="Mexico",
        start_date=date(2026, 8, 2),
        end_date=date(2026, 8, 7),
        travel_purpose="Benchmarking de operaciones IA para finanzas",
        requires_tickets=True,
        requires_external_tools=False,
        requires_nda=False,
        destination_international=False,
        estimated_amount=Decimal("7800.00"),
        currency="COP",
        exchange_rate_reference=None,
        status=TravelRequestStatus.APROBADA_PARA_PAGO,
    )

    aprobacion_repository.create_step(
        request_id=request.id,
        role=ApprovalRole.JEFE,
        sequence=1,
        status=TravelRequestStatus.EN_APROBACION_JEFE,
    )
    aprobacion_repository.create_step(
        request_id=request.id,
        role=ApprovalRole.GESTION_HUMANA,
        sequence=2,
        status=TravelRequestStatus.EN_VALIDACION_GH,
    )
    aprobacion_repository.create_step(
        request_id=request.id,
        role=ApprovalRole.PRESUPUESTO,
        sequence=3,
        status=TravelRequestStatus.EN_VALIDACION_PRESUPUESTO,
    )
    aprobacion_repository.create_event(
        request_id=request.id,
        role=ApprovalRole.JEFE,
        decision=ApprovalDecision.APROBAR,
        comments="Solicitud viable para la gira de benchmarking.",
    )

    payment = pago_repository.create_payment_order(
        request_id=payable_request.id,
        approved_amount=Decimal("7800.00"),
        currency="COP",
    )
    auditoria_repository.log_event(
        event_type="REQUEST_CREATED",
        request_id=request.id,
        actor_id=traveler.id,
        details="Solicitud demo creada desde seed local.",
    )
    auditoria_repository.log_event(
        event_type="MANAGER_APPROVED",
        request_id=request.id,
        actor_id=manager.id,
        details="Aprobacion inicial registrada en seed.",
    )
    auditoria_repository.log_event(
        event_type="PAYMENT_READY",
        request_id=payable_request.id,
        actor_id=analyst.id,
        details="Solicitud demo lista para ser procesada por pagos.",
    )

    session.commit()

    return {
        "cost_center_id": data_science.id,
        "manager_id": manager.id,
        "traveler_id": traveler.id,
        "analyst_id": analyst.id,
        "request_id": request.id,
        "payable_request_id": payable_request.id,
        "payment_order_id": payment.id,
    }
