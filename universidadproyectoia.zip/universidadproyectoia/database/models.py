from datetime import UTC, date, datetime
from decimal import Decimal

from sqlalchemy import Boolean, Date, DateTime, Enum, ForeignKey, Integer, Numeric, String, Text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

from domain.enums import ApprovalDecision, ApprovalRole, DocumentType, TravelRequestStatus


class Base(DeclarativeBase):
    pass


def utc_now() -> datetime:
    return datetime.now(UTC)


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=utc_now,
        onupdate=utc_now,
        nullable=False,
    )


class EmployeeModel(Base, TimestampMixin):
    __tablename__ = "employees"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    full_name: Mapped[str] = mapped_column(String(150), nullable=False)
    email: Mapped[str] = mapped_column(String(150), unique=True, nullable=False)
    manager_id: Mapped[int | None] = mapped_column(ForeignKey("employees.id"), nullable=True)
    cost_center_id: Mapped[int | None] = mapped_column(
        ForeignKey("cost_centers.id"),
        nullable=True,
    )

    manager: Mapped["EmployeeModel | None"] = relationship(remote_side=[id])


class CostCenterModel(Base, TimestampMixin):
    __tablename__ = "cost_centers"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    code: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(150), nullable=False)


class TravelRequestModel(Base, TimestampMixin):
    __tablename__ = "travel_requests"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    request_code: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)
    employee_id: Mapped[int] = mapped_column(ForeignKey("employees.id"), nullable=False)
    manager_id: Mapped[int | None] = mapped_column(ForeignKey("employees.id"), nullable=True)
    cost_center_id: Mapped[int | None] = mapped_column(ForeignKey("cost_centers.id"), nullable=True)
    destination: Mapped[str] = mapped_column(String(150), nullable=False)
    country: Mapped[str] = mapped_column(String(100), nullable=False)
    start_date: Mapped[date] = mapped_column(Date, nullable=False)
    end_date: Mapped[date] = mapped_column(Date, nullable=False)
    travel_purpose: Mapped[str] = mapped_column(Text, nullable=False)
    requires_tickets: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    requires_external_tools: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    requires_nda: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    destination_international: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    estimated_amount: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False)
    currency: Mapped[str] = mapped_column(String(10), nullable=False)
    exchange_rate_reference: Mapped[Decimal | None] = mapped_column(Numeric(14, 4), nullable=True)
    status: Mapped[TravelRequestStatus] = mapped_column(
        Enum(TravelRequestStatus),
        default=TravelRequestStatus.BORRADOR,
        nullable=False,
    )

    approval_steps: Mapped[list["ApprovalStepModel"]] = relationship(back_populates="travel_request")
    approval_events: Mapped[list["ApprovalEventModel"]] = relationship(back_populates="travel_request")
    documents: Mapped[list["DocumentModel"]] = relationship(back_populates="travel_request")
    payment_orders: Mapped[list["PaymentOrderModel"]] = relationship(back_populates="travel_request")
    expense_reports: Mapped[list["ExpenseReportModel"]] = relationship(back_populates="travel_request")


class ApprovalStepModel(Base):
    __tablename__ = "approval_steps"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    request_id: Mapped[int] = mapped_column(ForeignKey("travel_requests.id"), nullable=False)
    role: Mapped[ApprovalRole] = mapped_column(Enum(ApprovalRole), nullable=False)
    sequence: Mapped[int] = mapped_column(Integer, nullable=False)
    status: Mapped[TravelRequestStatus] = mapped_column(Enum(TravelRequestStatus), nullable=False)
    is_completed: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    acted_by_employee_id: Mapped[int | None] = mapped_column(ForeignKey("employees.id"), nullable=True)
    acted_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    comments: Mapped[str | None] = mapped_column(Text, nullable=True)

    travel_request: Mapped[TravelRequestModel] = relationship(back_populates="approval_steps")


class ApprovalEventModel(Base):
    __tablename__ = "approval_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    request_id: Mapped[int] = mapped_column(ForeignKey("travel_requests.id"), nullable=False)
    role: Mapped[ApprovalRole] = mapped_column(Enum(ApprovalRole), nullable=False)
    decision: Mapped[ApprovalDecision] = mapped_column(Enum(ApprovalDecision), nullable=False)
    comments: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, nullable=False)

    travel_request: Mapped[TravelRequestModel] = relationship(back_populates="approval_events")


class DocumentModel(Base):
    __tablename__ = "documents"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    request_id: Mapped[int] = mapped_column(ForeignKey("travel_requests.id"), nullable=False)
    document_type: Mapped[DocumentType] = mapped_column(Enum(DocumentType), nullable=False)
    file_name: Mapped[str] = mapped_column(String(200), nullable=False)
    storage_path: Mapped[str] = mapped_column(String(255), nullable=False)
    uploaded_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, nullable=False)

    travel_request: Mapped[TravelRequestModel] = relationship(back_populates="documents")


class PaymentOrderModel(Base):
    __tablename__ = "payment_orders"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    request_id: Mapped[int] = mapped_column(ForeignKey("travel_requests.id"), nullable=False)
    approved_amount: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False)
    notified_amount: Mapped[Decimal | None] = mapped_column(Numeric(14, 2), nullable=True)
    paid_amount: Mapped[Decimal | None] = mapped_column(Numeric(14, 2), nullable=True)
    currency: Mapped[str] = mapped_column(String(10), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, nullable=False)

    travel_request: Mapped[TravelRequestModel] = relationship(back_populates="payment_orders")
    notifications: Mapped[list["PaymentNotificationModel"]] = relationship(back_populates="payment_order")


class PaymentNotificationModel(Base):
    __tablename__ = "payment_notifications"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    payment_order_id: Mapped[int] = mapped_column(ForeignKey("payment_orders.id"), nullable=False)
    sent_to: Mapped[str] = mapped_column(String(150), nullable=False)
    sent_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, nullable=False)
    reference_code: Mapped[str] = mapped_column(String(100), nullable=False)

    payment_order: Mapped[PaymentOrderModel] = relationship(back_populates="notifications")


class ExpenseReportModel(Base):
    __tablename__ = "expense_reports"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    request_id: Mapped[int] = mapped_column(ForeignKey("travel_requests.id"), nullable=False)
    approved_amount: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False)
    advance_paid: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False)
    supported_amount: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False)
    balance_favor_employee: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False)
    balance_reimbursement_company: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, nullable=False)

    travel_request: Mapped[TravelRequestModel] = relationship(back_populates="expense_reports")
    expense_items: Mapped[list["ExpenseItemModel"]] = relationship(back_populates="expense_report")


class ExpenseItemModel(Base):
    __tablename__ = "expense_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    report_id: Mapped[int] = mapped_column(ForeignKey("expense_reports.id"), nullable=False)
    category: Mapped[str] = mapped_column(String(100), nullable=False)
    vendor: Mapped[str | None] = mapped_column(String(150), nullable=True)
    amount: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False)
    currency: Mapped[str] = mapped_column(String(10), nullable=False)
    expense_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)

    expense_report: Mapped[ExpenseReportModel] = relationship(back_populates="expense_items")


class AuditLogModel(Base):
    __tablename__ = "audit_log"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    request_id: Mapped[int | None] = mapped_column(ForeignKey("travel_requests.id"), nullable=True)
    event_type: Mapped[str] = mapped_column(String(100), nullable=False)
    actor_id: Mapped[int | None] = mapped_column(ForeignKey("employees.id"), nullable=True)
    details: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, nullable=False)
