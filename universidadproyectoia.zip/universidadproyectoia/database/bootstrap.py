from sqlalchemy import func, select

from database.models import CostCenterModel, EmployeeModel
from database.seed import seed_local_data
from database.session import SessionLocal, init_database


def bootstrap_local_data() -> None:
    init_database()
    with SessionLocal() as session:
        employee_count = session.scalar(select(func.count()).select_from(EmployeeModel)) or 0
        cost_center_count = session.scalar(select(func.count()).select_from(CostCenterModel)) or 0
        if employee_count == 0 and cost_center_count == 0:
            seed_local_data(session)
