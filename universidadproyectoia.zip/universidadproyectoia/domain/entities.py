from dataclasses import dataclass, field
from datetime import UTC, date, datetime
from decimal import Decimal

from domain.enums import ApprovalDecision, ApprovalRole, DocumentType, TravelRequestStatus


def utc_now() -> datetime:
    return datetime.now(UTC)


@dataclass(slots=True)
class Employee:
    employee_id: int
    full_name: str
    email: str
    manager_id: int | None = None
    cost_center_id: int | None = None


@dataclass(slots=True)
class CostCenter:
    cost_center_id: int
    code: str
    name: str


@dataclass(slots=True)
class TravelRequest:
    request_id: int | None
    request_code: str
    employee_id: int
    manager_id: int | None
    cost_center_id: int | None
    destination: str
    country: str
    start_date: date
    end_date: date
    travel_purpose: str
    requires_tickets: bool = False
    requires_external_tools: bool = False
    requires_nda: bool = False
    destination_international: bool = False
    estimated_amount: Decimal = Decimal("0")
    currency: str = "COP"
    exchange_rate_reference: Decimal | None = None
    status: TravelRequestStatus = TravelRequestStatus.BORRADOR
    created_at: datetime = field(default_factory=utc_now)
    updated_at: datetime = field(default_factory=utc_now)


@dataclass(slots=True)
class ApprovalStep:
    request_id: int
    role: ApprovalRole
    sequence: int
    status: TravelRequestStatus
    is_completed: bool = False
    acted_by_employee_id: int | None = None
    acted_at: datetime | None = None
    comments: str | None = None


@dataclass(slots=True)
class ApprovalEvent:
    request_id: int
    role: ApprovalRole
    decision: ApprovalDecision
    comments: str | None = None
    created_at: datetime = field(default_factory=utc_now)


@dataclass(slots=True)
class Document:
    request_id: int
    document_type: DocumentType
    file_name: str
    storage_path: str
    uploaded_at: datetime = field(default_factory=utc_now)


@dataclass(slots=True)
class PaymentOrder:
    request_id: int
    approved_amount: Decimal
    notified_amount: Decimal | None = None
    paid_amount: Decimal | None = None
    currency: str = "COP"
    created_at: datetime = field(default_factory=utc_now)


@dataclass(slots=True)
class ExpenseItem:
    request_id: int
    category: str
    amount: Decimal
    currency: str
    expense_date: date | None = None
    description: str | None = None


@dataclass(slots=True)
class ExpenseReport:
    request_id: int
    approved_amount: Decimal
    advance_paid: Decimal
    supported_amount: Decimal
    balance_favor_employee: Decimal = Decimal("0")
    balance_reimbursement_company: Decimal = Decimal("0")
