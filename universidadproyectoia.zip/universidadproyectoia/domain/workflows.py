from dataclasses import dataclass

from domain.enums import ApprovalRole, TravelRequestStatus
from domain.rules import DomainRuleViolation

ROLE_TO_STATUS: dict[ApprovalRole, TravelRequestStatus] = {
    ApprovalRole.JEFE: TravelRequestStatus.EN_APROBACION_JEFE,
    ApprovalRole.GESTION_HUMANA: TravelRequestStatus.EN_VALIDACION_GH,
    ApprovalRole.PRESUPUESTO: TravelRequestStatus.EN_VALIDACION_PRESUPUESTO,
    ApprovalRole.COMPRAS: TravelRequestStatus.EN_VALIDACION_COMPRAS,
    ApprovalRole.SEGURIDAD_TI: TravelRequestStatus.EN_VALIDACION_SEGURIDAD_TI,
    ApprovalRole.JURIDICA: TravelRequestStatus.EN_VALIDACION_JURIDICA,
    ApprovalRole.APROBADOR_ADICIONAL: TravelRequestStatus.EN_VALIDACION_APROBADOR_ADICIONAL,
}

APPROVAL_STATUSES = set(ROLE_TO_STATUS.values())


class WorkflowTransitionError(ValueError):
    """Raised when a state transition is not valid for the workflow."""


@dataclass(slots=True)
class TravelRequestWorkflow:
    approval_route: list[ApprovalRole]

    def submit(self, current_status: TravelRequestStatus) -> TravelRequestStatus:
        if current_status not in {
            TravelRequestStatus.BORRADOR,
            TravelRequestStatus.DEVUELTA_A_AJUSTES,
        }:
            raise WorkflowTransitionError(f"Cannot submit a request from status {current_status.value}.")
        return TravelRequestStatus.RADICADA

    def start_approval_cycle(self, current_status: TravelRequestStatus) -> TravelRequestStatus:
        if current_status != TravelRequestStatus.RADICADA:
            raise WorkflowTransitionError(f"Cannot start approval cycle from status {current_status.value}.")
        if not self.approval_route:
            return TravelRequestStatus.APROBADA_PARA_PAGO
        return ROLE_TO_STATUS[self.approval_route[0]]

    def approve(self, current_status: TravelRequestStatus) -> TravelRequestStatus:
        if current_status not in APPROVAL_STATUSES:
            raise WorkflowTransitionError(f"Cannot approve a request from status {current_status.value}.")
        current_role = self._role_from_status(current_status)
        current_index = self.approval_route.index(current_role)
        next_index = current_index + 1
        if next_index >= len(self.approval_route):
            return TravelRequestStatus.APROBADA_PARA_PAGO
        return ROLE_TO_STATUS[self.approval_route[next_index]]

    def reject(self, current_status: TravelRequestStatus) -> TravelRequestStatus:
        if current_status not in APPROVAL_STATUSES:
            raise WorkflowTransitionError(f"Cannot reject a request from status {current_status.value}.")
        return TravelRequestStatus.RECHAZADA

    def return_for_adjustments(self, current_status: TravelRequestStatus) -> TravelRequestStatus:
        if current_status not in APPROVAL_STATUSES:
            raise WorkflowTransitionError(f"Cannot return a request for adjustments from status {current_status.value}.")
        return TravelRequestStatus.DEVUELTA_A_AJUSTES

    def notify_payment(self, current_status: TravelRequestStatus) -> TravelRequestStatus:
        if current_status != TravelRequestStatus.APROBADA_PARA_PAGO:
            raise WorkflowTransitionError("Payment can only be notified after the request is fully approved.")
        return TravelRequestStatus.PAGO_NOTIFICADO

    def confirm_payment(self, current_status: TravelRequestStatus) -> TravelRequestStatus:
        if current_status != TravelRequestStatus.PAGO_NOTIFICADO:
            raise WorkflowTransitionError(f"Cannot confirm payment from status {current_status.value}.")
        return TravelRequestStatus.PAGO_CONFIRMADO

    def start_legalization(self, current_status: TravelRequestStatus) -> TravelRequestStatus:
        if current_status != TravelRequestStatus.PAGO_CONFIRMADO:
            raise WorkflowTransitionError(f"Cannot start legalization from status {current_status.value}.")
        return TravelRequestStatus.EN_LEGALIZACION

    def legalize(self, current_status: TravelRequestStatus) -> TravelRequestStatus:
        if current_status != TravelRequestStatus.EN_LEGALIZACION:
            raise WorkflowTransitionError(f"Cannot legalize from status {current_status.value}.")
        return TravelRequestStatus.LEGALIZADA

    def close(self, current_status: TravelRequestStatus) -> TravelRequestStatus:
        if current_status != TravelRequestStatus.LEGALIZADA:
            raise WorkflowTransitionError(f"Cannot close from status {current_status.value}.")
        return TravelRequestStatus.CERRADA

    def _role_from_status(self, status: TravelRequestStatus) -> ApprovalRole:
        for role, mapped_status in ROLE_TO_STATUS.items():
            if mapped_status == status:
                return role
        raise DomainRuleViolation(f"Status {status.value} is not associated with an approval role.")
