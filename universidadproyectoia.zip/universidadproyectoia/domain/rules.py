from dataclasses import dataclass
from decimal import Decimal

from domain.entities import TravelRequest
from domain.enums import ApprovalRole


class DomainRuleViolation(ValueError):
    """Raised when a travel request breaks a business rule."""


@dataclass(frozen=True, slots=True)
class RoutingContext:
    additional_approval_threshold: Decimal = Decimal("10000")


def validate_submission_requirements(request: TravelRequest) -> None:
    if request.cost_center_id is None:
        raise DomainRuleViolation("Cost center is required before submitting the request.")
    if request.manager_id is None:
        raise DomainRuleViolation("Manager is required before submitting the request.")
    if not request.destination.strip():
        raise DomainRuleViolation("Destination is required before submitting the request.")
    if request.end_date < request.start_date:
        raise DomainRuleViolation("End date cannot be earlier than start date.")
    if request.destination_international:
        if not request.currency.strip():
            raise DomainRuleViolation("Currency is required for international travel.")
        if request.exchange_rate_reference is None:
            raise DomainRuleViolation("Exchange rate reference is required for international travel.")
    if request.estimated_amount < Decimal("0"):
        raise DomainRuleViolation("Estimated amount cannot be negative.")


def determine_approval_route(
    request: TravelRequest,
    context: RoutingContext | None = None,
) -> list[ApprovalRole]:
    validate_submission_requirements(request)
    routing_context = context or RoutingContext()

    route: list[ApprovalRole] = [
        ApprovalRole.JEFE,
        ApprovalRole.GESTION_HUMANA,
        ApprovalRole.PRESUPUESTO,
    ]

    if request.requires_tickets:
        route.append(ApprovalRole.COMPRAS)
    if request.requires_external_tools:
        route.append(ApprovalRole.SEGURIDAD_TI)
    if request.requires_nda:
        route.append(ApprovalRole.JURIDICA)
    if request.estimated_amount >= routing_context.additional_approval_threshold:
        route.append(ApprovalRole.APROBADOR_ADICIONAL)

    return route
