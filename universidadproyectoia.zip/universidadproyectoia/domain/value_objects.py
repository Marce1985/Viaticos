from dataclasses import dataclass
from decimal import ROUND_HALF_UP, Decimal


@dataclass(frozen=True, slots=True)
class Money:
    amount: Decimal
    currency: str

    def __post_init__(self) -> None:
        normalized_amount = self.amount.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        normalized_currency = self.currency.strip().upper()
        if normalized_amount < Decimal("0"):
            raise ValueError("Money amount cannot be negative.")
        if not normalized_currency:
            raise ValueError("Currency is required.")
        object.__setattr__(self, "amount", normalized_amount)
        object.__setattr__(self, "currency", normalized_currency)
