from pathlib import Path

from config.settings import Settings, get_settings


class SharePointClient:
    def __init__(
        self,
        settings: Settings | None = None,
        *,
        base_path: str | Path | None = None,
    ) -> None:
        self.settings = settings or get_settings()
        self.mode = self.settings.sharepoint_mode
        self.base_path = Path(base_path or self.settings.documents_storage_path)

    def save_document(
        self,
        *,
        request_code: str,
        file_name: str,
        content: str,
    ) -> str:
        request_folder = self.base_path / request_code
        request_folder.mkdir(parents=True, exist_ok=True)
        target = request_folder / file_name
        target.write_text(content, encoding="utf-8")
        return str(target.resolve())
