import json
import time
from typing import Any, TypeVar

from pydantic import BaseModel, TypeAdapter

from config.settings import Settings, get_settings
from schemas.document_ai_schema import (
    ApprovalSummary,
    DocumentClassification,
    InvitationData,
    NormalizedExpense,
)

T = TypeVar("T", bound=BaseModel)


class GeminiClientError(RuntimeError):
    """Raised when the Gemini client cannot complete a request."""


class GeminiClient:
    def __init__(
        self,
        settings: Settings | None = None,
        *,
        transport: Any | None = None,
        max_retries: int = 2,
        retry_delay_seconds: float = 0.25,
    ) -> None:
        self.settings = settings or get_settings()
        self.transport = transport
        self.max_retries = max_retries
        self.retry_delay_seconds = retry_delay_seconds

    def generate_structured(
        self,
        *,
        prompt: str,
        response_model: type[T],
        system_instruction: str | None = None,
    ) -> T:
        if not self.settings.enable_gemini:
            raise GeminiClientError("Gemini integration is disabled by feature flag.")

        if self.settings.gemini_is_mock:
            return self._mock_response(prompt=prompt, response_model=response_model)

        client = self.transport or self._build_sdk_client()
        payload = self._generate_with_retry(
            client=client,
            prompt=prompt,
            response_model=response_model,
            system_instruction=system_instruction,
        )
        return self._validate_payload(payload=payload, response_model=response_model)

    def extract_invitation_data(self, file_text: str) -> InvitationData:
        return self.generate_structured(
            prompt=("Extrae de forma estructurada la informacion clave de la invitacion. " "No inventes datos faltantes.\n\nTexto:\n" f"{file_text}"),
            response_model=InvitationData,
            system_instruction=("Eres un asistente documental corporativo. Devuelve solo datos verificables."),
        )

    def classify_supporting_document(self, text: str) -> DocumentClassification:
        return self.generate_structured(
            prompt=("Clasifica el siguiente documento de soporte y agrega una nota breve " "sobre su pertinencia documental.\n\nTexto:\n" f"{text}"),
            response_model=DocumentClassification,
            system_instruction="Clasifica documentos de viaticos con salida estrictamente estructurada.",
        )

    def summarize_approval_comments(self, comments: list[str]) -> ApprovalSummary:
        merged_comments = "\n".join(f"- {comment}" for comment in comments if comment.strip())
        return self.generate_structured(
            prompt=(
                "Resume los comentarios de aprobacion, resalta riesgos y define acciones. "
                "No incluyas informacion que no aparezca en los comentarios.\n\nComentarios:\n"
                f"{merged_comments}"
            ),
            response_model=ApprovalSummary,
            system_instruction="Resume observaciones internas de aprobacion en formato JSON.",
        )

    def normalize_expense_item(self, raw_text: str) -> NormalizedExpense:
        return self.generate_structured(
            prompt=(
                "Normaliza el siguiente concepto de gasto. Extrae categoria, proveedor, "
                "monto, moneda y fecha si aparece.\n\nTexto:\n"
                f"{raw_text}"
            ),
            response_model=NormalizedExpense,
            system_instruction="Normaliza conceptos contables de viaticos con salida JSON valida.",
        )

    def _build_sdk_client(self) -> Any:
        if not self.settings.gemini_api_key:
            raise GeminiClientError("GEMINI_API_KEY is required when Gemini mock mode is disabled.")
        try:
            from google import genai
        except ImportError as exc:
            raise GeminiClientError("google-genai is not installed. Install dependencies before enabling Gemini.") from exc
        return genai.Client(api_key=self.settings.gemini_api_key)

    def _generate_with_retry(
        self,
        *,
        client: Any,
        prompt: str,
        response_model: type[T],
        system_instruction: str | None,
    ) -> dict[str, Any]:
        last_error: Exception | None = None
        for attempt in range(self.max_retries + 1):
            try:
                response = client.models.generate_content(
                    model=self.settings.gemini_model,
                    contents=prompt,
                    config={
                        "system_instruction": system_instruction,
                        "response_mime_type": "application/json",
                        "response_json_schema": response_model.model_json_schema(),
                    },
                )
                text = getattr(response, "text", None)
                if not text:
                    raise GeminiClientError("Gemini returned an empty response.")
                return json.loads(text)
            except Exception as exc:  # noqa: BLE001
                last_error = exc
                if attempt >= self.max_retries:
                    break
                time.sleep(self.retry_delay_seconds * (attempt + 1))
        raise GeminiClientError(f"Gemini request failed after retries: {last_error}") from last_error

    def _validate_payload(self, *, payload: dict[str, Any], response_model: type[T]) -> T:
        adapter = TypeAdapter(response_model)
        return adapter.validate_python(payload)

    def _mock_response(self, *, prompt: str, response_model: type[T]) -> T:
        prompt_lower = prompt.lower()
        payload: dict[str, Any]
        if response_model is InvitationData:
            payload = {
                "organization_name": "Open Benchmark Labs",
                "destination_city": "Madrid",
                "destination_country": "Espana",
                "start_date": "2026-07-10",
                "end_date": "2026-07-14",
                "contact_name": "Ana Lopez",
            }
        elif response_model is DocumentClassification:
            payload = {
                "document_type": "INVITACION" if "invit" in prompt_lower else "SOPORTE_GASTO",
                "confidence": 0.91,
                "notes": "Clasificacion generada en modo mock.",
            }
        elif response_model is ApprovalSummary:
            payload = {
                "summary": "Los comentarios validan el viaje con observaciones menores.",
                "key_risks": ["Pendiente validar presupuesto final"],
                "action_items": ["Confirmar soportes previos al pago"],
            }
        elif response_model is NormalizedExpense:
            payload = {
                "category": "Hospedaje" if "hotel" in prompt_lower else "Transporte",
                "vendor": "Proveedor Mock",
                "amount": 120.5,
                "currency": "USD",
                "expense_date": "2026-07-11",
            }
        else:
            raise GeminiClientError(f"Mock response not configured for {response_model.__name__}.")
        return self._validate_payload(payload=payload, response_model=response_model)
