from config.settings import Settings, get_settings


class NotificationClient:
    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or get_settings()

    def send_structured_message(
        self,
        *,
        target: str,
        subject: str,
        body: str,
    ) -> dict[str, str]:
        if not self.settings.enable_corporate_placeholders:
            raise RuntimeError("Corporate placeholder integrations are disabled by feature flag.")
        return {
            "status": "sent",
            "target": target,
            "subject": subject,
            "body_preview": body[:80],
        }
