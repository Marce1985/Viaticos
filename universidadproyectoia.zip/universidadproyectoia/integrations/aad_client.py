from config.settings import Settings, get_settings


class AadClient:
    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or get_settings()

    def get_current_user(self) -> dict[str, str]:
        if self.settings.auth_mode != "mock":
            raise NotImplementedError("Azure AD integration adapter is pending implementation.")
        return {
            "user_id": "mock-user",
            "display_name": "Usuario Demo",
            "email": "usuario.demo@example.com",
        }
