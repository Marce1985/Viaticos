from config.settings import Settings, get_settings


class SapClient:
    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or get_settings()

    def send_payment_order(self, payload: dict[str, object]) -> dict[str, object]:
        if self.settings.sap_mode != "mock":
            raise NotImplementedError("SAP ECC HCM adapter is pending implementation.")
        return {
            "status": "queued",
            "provider": "mock-sap",
            "payload_reference": payload.get("reference_code", "N/A"),
        }
