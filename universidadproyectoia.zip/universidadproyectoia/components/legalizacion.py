import dash_bootstrap_components as dbc
from dash import html


def build_legalization_queue(
    items: list[dict[str, object]],
    selected_request_id: int | None = None,
) -> html.Div:
    if not items:
        return html.Div(
            [
                html.Span("Sin legalizaciones pendientes", className="summary-label"),
                html.P(
                    "No hay solicitudes listas para legalizacion en la cola actual.",
                    className="page-copy mb-0",
                ),
            ],
            className="empty-state",
        )

    rows = []
    for item in items:
        is_selected = item["request_id"] == selected_request_id
        row_class = "inbox-row-selected" if is_selected else ""
        rows.append(
            html.Tr(
                [
                    html.Td(
                        dbc.Button(
                            item["request_code"],
                            id={
                                "type": "legalizacion-row-button",
                                "request_id": item["request_id"],
                            },
                            color="link",
                            class_name="request-link",
                        )
                    ),
                    html.Td(item["destination"]),
                    html.Td(item["status"]),
                    html.Td(item["approved_amount"]),
                    html.Td(item["supported_amount"]),
                ],
                className=row_class,
            )
        )

    return dbc.Table(
        [
            html.Thead(
                html.Tr(
                    [
                        html.Th("Solicitud"),
                        html.Th("Destino"),
                        html.Th("Estado"),
                        html.Th("Anticipo"),
                        html.Th("Soportado"),
                    ]
                )
            ),
            html.Tbody(rows),
        ],
        responsive=True,
        hover=True,
        class_name="inbox-table align-middle mb-0",
    )
