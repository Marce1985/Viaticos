import dash_bootstrap_components as dbc


def build_info_alert(message: str) -> dbc.Alert:
    return dbc.Alert(message, color="info", class_name="shadow-sm border-0")
