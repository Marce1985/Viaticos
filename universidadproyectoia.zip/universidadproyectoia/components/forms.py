from datetime import date

import dash_bootstrap_components as dbc
from dash import dcc, html


def build_solicitud_form(
    *,
    employee_options: list[dict[str, object]],
    cost_center_options: list[dict[str, object]],
) -> dbc.Card:
    today = date.today().isoformat()
    return dbc.Card(
        dbc.CardBody(
            [
                html.Div(
                    [
                        html.Span("Registro del viaje", className="section-kicker"),
                        html.H3("Nueva solicitud de viaticos", className="section-title"),
                        html.P(
                            "Completa la informacion del viaje. Puedes guardar como borrador "
                            "o radicar cuando la solicitud este lista para aprobacion.",
                            className="section-copy",
                        ),
                    ],
                    className="section-header",
                ),
                dbc.Row(
                    [
                        dbc.Col(
                            [
                                dbc.Label("Solicitante", html_for="solicitud-employee-id"),
                                dcc.Dropdown(
                                    id="solicitud-employee-id",
                                    options=employee_options,
                                    placeholder="Selecciona el colaborador solicitante",
                                    className="form-dropdown",
                                ),
                            ],
                            md=6,
                        ),
                        dbc.Col(
                            [
                                dbc.Label("Jefe inmediato", html_for="solicitud-manager-id"),
                                dcc.Dropdown(
                                    id="solicitud-manager-id",
                                    options=employee_options,
                                    placeholder="Selecciona el jefe aprobador",
                                    className="form-dropdown",
                                ),
                            ],
                            md=6,
                        ),
                    ],
                    class_name="g-4",
                ),
                dbc.Row(
                    [
                        dbc.Col(
                            [
                                dbc.Label("Centro de costo", html_for="solicitud-cost-center-id"),
                                dcc.Dropdown(
                                    id="solicitud-cost-center-id",
                                    options=cost_center_options,
                                    placeholder="Selecciona el centro de costo",
                                    className="form-dropdown",
                                ),
                            ],
                            md=6,
                        ),
                        dbc.Col(
                            [
                                dbc.Label("Destino", html_for="solicitud-destination"),
                                dbc.Input(
                                    id="solicitud-destination",
                                    type="text",
                                    placeholder="Ej. Madrid, Barcelona, Ciudad de Mexico",
                                ),
                            ],
                            md=6,
                        ),
                    ],
                    class_name="g-4 mt-1",
                ),
                dbc.Row(
                    [
                        dbc.Col(
                            [
                                dbc.Label("Pais", html_for="solicitud-country"),
                                dbc.Input(
                                    id="solicitud-country",
                                    type="text",
                                    placeholder="Ej. Espana",
                                ),
                            ],
                            md=4,
                        ),
                        dbc.Col(
                            [
                                dbc.Label("Fecha de inicio", html_for="solicitud-start-date"),
                                dcc.DatePickerSingle(
                                    id="solicitud-start-date",
                                    date=today,
                                    display_format="YYYY-MM-DD",
                                    className="date-picker",
                                ),
                            ],
                            md=4,
                        ),
                        dbc.Col(
                            [
                                dbc.Label("Fecha de fin", html_for="solicitud-end-date"),
                                dcc.DatePickerSingle(
                                    id="solicitud-end-date",
                                    date=today,
                                    display_format="YYYY-MM-DD",
                                    className="date-picker",
                                ),
                            ],
                            md=4,
                        ),
                    ],
                    class_name="g-4 mt-1",
                ),
                dbc.Row(
                    [
                        dbc.Col(
                            [
                                dbc.Label("Proposito del viaje", html_for="solicitud-purpose"),
                                dbc.Textarea(
                                    id="solicitud-purpose",
                                    placeholder=("Describe el objetivo del benchmarking, reuniones, " "proveedores y resultados esperados."),
                                    rows=5,
                                ),
                            ]
                        )
                    ],
                    class_name="g-4 mt-1",
                ),
                html.Hr(className="form-divider"),
                dbc.Row(
                    [
                        dbc.Col(
                            dbc.Checklist(
                                id="solicitud-flags",
                                options=[
                                    {"label": "Requiere tiquetes", "value": "tickets"},
                                    {
                                        "label": "Requiere herramientas externas",
                                        "value": "external_tools",
                                    },
                                    {"label": "Requiere NDA", "value": "nda"},
                                    {"label": "Destino internacional", "value": "international"},
                                ],
                                value=[],
                                inline=False,
                                class_name="request-checklist",
                            ),
                            lg=5,
                        ),
                        dbc.Col(
                            [
                                dbc.Row(
                                    [
                                        dbc.Col(
                                            [
                                                dbc.Label(
                                                    "Monto estimado",
                                                    html_for="solicitud-estimated-amount",
                                                ),
                                                dbc.Input(
                                                    id="solicitud-estimated-amount",
                                                    type="number",
                                                    min=0,
                                                    step=0.01,
                                                    placeholder="0.00",
                                                ),
                                            ],
                                            md=6,
                                        ),
                                        dbc.Col(
                                            [
                                                dbc.Label(
                                                    "Moneda",
                                                    html_for="solicitud-currency",
                                                ),
                                                dbc.Input(
                                                    id="solicitud-currency",
                                                    type="text",
                                                    value="COP",
                                                    placeholder="COP, USD, EUR",
                                                ),
                                            ],
                                            md=6,
                                        ),
                                    ],
                                    class_name="g-4",
                                ),
                                dbc.Row(
                                    [
                                        dbc.Col(
                                            html.Div(
                                                [
                                                    dbc.Label(
                                                        "Tasa referencial",
                                                        html_for="solicitud-exchange-rate",
                                                    ),
                                                    dbc.Input(
                                                        id="solicitud-exchange-rate",
                                                        type="number",
                                                        min=0,
                                                        step=0.0001,
                                                        placeholder="Solo para destinos internacionales",
                                                    ),
                                                ],
                                                id="solicitud-exchange-rate-wrapper",
                                            ),
                                            md=6,
                                        )
                                    ],
                                    class_name="g-4 mt-1",
                                ),
                            ],
                            lg=7,
                        ),
                    ],
                    class_name="g-4 align-items-start",
                ),
                dbc.Alert(
                    id="solicitud-feedback",
                    is_open=False,
                    class_name="mt-4 border-0 shadow-sm",
                ),
                dbc.Row(
                    [
                        dbc.Col(
                            html.Div(id="solicitud-route-preview", className="route-preview"),
                            lg=8,
                        ),
                        dbc.Col(
                            html.Div(
                                [
                                    dbc.Button(
                                        "Guardar borrador",
                                        id="solicitud-save-draft",
                                        color="secondary",
                                        class_name="w-100 mb-2",
                                    ),
                                    dbc.Button(
                                        "Radicar solicitud",
                                        id="solicitud-submit-request",
                                        color="primary",
                                        class_name="w-100",
                                    ),
                                ],
                                className="action-stack",
                            ),
                            lg=4,
                        ),
                    ],
                    class_name="g-4 mt-2",
                ),
                dcc.Store(id="solicitud-current-request-id"),
            ]
        ),
        class_name="form-card border-0",
    )
