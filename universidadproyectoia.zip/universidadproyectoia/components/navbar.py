import dash_bootstrap_components as dbc
from dash import html


def build_topbar() -> dbc.Navbar:
    return dbc.Navbar(
        dbc.Container(
            [
                html.Div(
                    [
                        html.Span("Portal de Viaticos", className="brand-kicker"),
                        html.H1("Benchmarking en IA", className="brand-title"),
                    ],
                    className="brand-block",
                ),
                html.Div(
                    [
                        html.Span("Entorno local", className="status-chip"),
                    ],
                    className="topbar-actions",
                ),
            ],
            fluid=True,
            className="g-0",
        ),
        color="white",
        dark=False,
        className="topbar-shell",
    )
