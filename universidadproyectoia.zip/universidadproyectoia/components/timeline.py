from dash import html


def build_timeline(entries: list[dict[str, str]]) -> html.Div:
    if not entries:
        return html.Div(
            [
                html.Span("Sin trazabilidad", className="summary-label"),
                html.P(
                    "Aun no hay eventos registrados para esta solicitud.",
                    className="page-copy mb-0",
                ),
            ],
            className="empty-state",
        )

    blocks = []
    for entry in entries:
        blocks.append(
            html.Div(
                [
                    html.Div(className="timeline-dot"),
                    html.Div(
                        [
                            html.Span(entry["label"], className="timeline-label"),
                            html.H4(entry["title"], className="timeline-title"),
                            html.P(entry["description"], className="timeline-copy"),
                        ],
                        className="timeline-content",
                    ),
                ],
                className="timeline-item",
            )
        )
    return html.Div(blocks, className="timeline-shell")
