import dash_bootstrap_components as dbc
from dash import html, page_registry


def _build_nav_links() -> list[dbc.NavLink]:
    ordered_pages = sorted(page_registry.values(), key=lambda item: item.get("order", 999))
    links: list[dbc.NavLink] = []
    for page in ordered_pages:
        links.append(
            dbc.NavLink(
                page["name"],
                href=page["relative_path"],
                active="exact",
                class_name="sidebar-link",
            )
        )
    return links


def build_sidebar() -> html.Div:
    return html.Div(
        [
            html.Div(
                [
                    html.Span("Workspace", className="sidebar-label"),
                    html.H2("Operacion de viajes", className="sidebar-title"),
                    html.P(
                        "Base inicial lista para evolucionar a flujo corporativo de solicitudes, " "aprobaciones y pagos.",
                        className="sidebar-copy",
                    ),
                ],
                className="sidebar-header",
            ),
            dbc.Nav(_build_nav_links(), vertical=True, pills=True, class_name="sidebar-nav"),
        ],
        className="sidebar-shell",
    )
