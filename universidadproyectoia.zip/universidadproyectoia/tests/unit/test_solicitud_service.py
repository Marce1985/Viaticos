from datetime import date
from decimal import Decimal

import pytest
from sqlalchemy.orm import Session

from database.seed import create_schema
from database.session import build_engine, build_session_factory
from domain.rules import DomainRuleViolation
from repositories.auditoria_repository import AuditoriaRepository
from schemas.solicitud_schema import SolicitudDraftInput
from services.solicitud_service import SolicitudService


@pytest.fixture()
def db_session(tmp_path: pytest.TempPathFactory) -> Session:
    database_path = tmp_path / "unit_solicitud_service.db"
    engine = build_engine(f"sqlite:///{database_path}")
    session_factory = build_session_factory(engine)
    with session_factory() as bootstrap_session:
        create_schema(bootstrap_session)
    session = session_factory()
    try:
        yield session
    finally:
        session.close()
        engine.dispose()


def build_draft_input(**overrides: object) -> SolicitudDraftInput:
    data = {
        "employee_id": 1,
        "manager_id": 2,
        "cost_center_id": 3,
        "destination": "Londres",
        "country": "Reino Unido",
        "start_date": date(2026, 8, 10),
        "end_date": date(2026, 8, 14),
        "travel_purpose": "Benchmarking de copilotos empresariales",
        "requires_tickets": True,
        "requires_external_tools": True,
        "requires_nda": True,
        "destination_international": True,
        "estimated_amount": Decimal("12500.00"),
        "currency": "GBP",
        "exchange_rate_reference": Decimal("5150.30"),
    }
    data.update(overrides)
    return SolicitudDraftInput(**data)


def test_save_draft_persists_request_and_audit_log(db_session: Session) -> None:
    service = SolicitudService(db_session)

    result = service.save_draft(build_draft_input())

    assert result.id > 0
    assert result.status.value == "BORRADOR"
    assert result.request_code.startswith("SOL-")

    audit_entries = AuditoriaRepository(db_session).list_timeline(result.id)
    assert len(audit_entries) == 1
    assert audit_entries[0].event_type == "DRAFT_SAVED"


def test_submit_request_creates_route_and_updates_status(db_session: Session) -> None:
    service = SolicitudService(db_session)
    draft = service.save_draft(build_draft_input())

    result = service.submit_request(draft.id)

    assert result.current_status.value == "EN_APROBACION_JEFE"
    assert result.approval_route == [role for role in result.approval_route]
    assert [role.value for role in result.approval_route] == [
        "JEFE",
        "GESTION_HUMANA",
        "PRESUPUESTO",
        "COMPRAS",
        "SEGURIDAD_TI",
        "JURIDICA",
        "APROBADOR_ADICIONAL",
    ]
    assert len(result.request.model_dump()) > 0


def test_submit_request_raises_when_mandatory_data_is_missing(db_session: Session) -> None:
    service = SolicitudService(db_session)
    draft = service.save_draft(build_draft_input(cost_center_id=None))

    with pytest.raises(DomainRuleViolation, match="Cost center"):
        service.submit_request(draft.id)
