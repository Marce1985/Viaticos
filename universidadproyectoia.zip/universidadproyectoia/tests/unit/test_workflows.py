import pytest

from domain.enums import ApprovalRole, TravelRequestStatus
from domain.workflows import TravelRequestWorkflow, WorkflowTransitionError


def test_workflow_advances_through_route_until_payment_approval() -> None:
    workflow = TravelRequestWorkflow(
        approval_route=[
            ApprovalRole.JEFE,
            ApprovalRole.GESTION_HUMANA,
            ApprovalRole.PRESUPUESTO,
            ApprovalRole.COMPRAS,
        ]
    )

    status = workflow.submit(TravelRequestStatus.BORRADOR)
    assert status == TravelRequestStatus.RADICADA

    status = workflow.start_approval_cycle(status)
    assert status == TravelRequestStatus.EN_APROBACION_JEFE

    status = workflow.approve(status)
    assert status == TravelRequestStatus.EN_VALIDACION_GH

    status = workflow.approve(status)
    assert status == TravelRequestStatus.EN_VALIDACION_PRESUPUESTO

    status = workflow.approve(status)
    assert status == TravelRequestStatus.EN_VALIDACION_COMPRAS

    status = workflow.approve(status)
    assert status == TravelRequestStatus.APROBADA_PARA_PAGO


def test_workflow_rejects_invalid_transition() -> None:
    workflow = TravelRequestWorkflow(approval_route=[ApprovalRole.JEFE])

    with pytest.raises(WorkflowTransitionError, match="Cannot approve"):
        workflow.approve(TravelRequestStatus.BORRADOR)


def test_workflow_can_return_for_adjustments_and_resubmit() -> None:
    workflow = TravelRequestWorkflow(approval_route=[ApprovalRole.JEFE, ApprovalRole.PRESUPUESTO])

    status = workflow.submit(TravelRequestStatus.BORRADOR)
    status = workflow.start_approval_cycle(status)

    returned_status = workflow.return_for_adjustments(status)
    assert returned_status == TravelRequestStatus.DEVUELTA_A_AJUSTES

    resubmitted_status = workflow.submit(returned_status)
    assert resubmitted_status == TravelRequestStatus.RADICADA
