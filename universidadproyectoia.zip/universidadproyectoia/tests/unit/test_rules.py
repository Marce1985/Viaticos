from datetime import date
from decimal import Decimal

import pytest

from domain.entities import TravelRequest
from domain.enums import ApprovalRole
from domain.rules import DomainRuleViolation, RoutingContext, determine_approval_route


def build_request(**overrides: object) -> TravelRequest:
    data = {
        "request_id": None,
        "request_code": "SOL-001",
        "employee_id": 7,
        "manager_id": 10,
        "cost_center_id": 20,
        "destination": "San Francisco",
        "country": "USA",
        "start_date": date(2026, 5, 10),
        "end_date": date(2026, 5, 16),
        "travel_purpose": "Benchmarking de proveedores IA",
        "requires_tickets": False,
        "requires_external_tools": False,
        "requires_nda": False,
        "destination_international": False,
        "estimated_amount": Decimal("4500"),
        "currency": "COP",
        "exchange_rate_reference": None,
    }
    data.update(overrides)
    return TravelRequest(**data)


def test_determine_approval_route_includes_conditional_steps() -> None:
    request = build_request(
        requires_tickets=True,
        requires_external_tools=True,
        requires_nda=True,
        estimated_amount=Decimal("15000"),
    )

    route = determine_approval_route(
        request,
        context=RoutingContext(additional_approval_threshold=Decimal("10000")),
    )

    assert route == [
        ApprovalRole.JEFE,
        ApprovalRole.GESTION_HUMANA,
        ApprovalRole.PRESUPUESTO,
        ApprovalRole.COMPRAS,
        ApprovalRole.SEGURIDAD_TI,
        ApprovalRole.JURIDICA,
        ApprovalRole.APROBADOR_ADICIONAL,
    ]


def test_determine_approval_route_validates_international_requirements() -> None:
    request = build_request(
        destination_international=True,
        currency="USD",
        exchange_rate_reference=None,
    )

    with pytest.raises(DomainRuleViolation, match="Exchange rate reference"):
        determine_approval_route(request)


def test_determine_approval_route_requires_cost_center_before_submission() -> None:
    request = build_request(cost_center_id=None)

    with pytest.raises(DomainRuleViolation, match="Cost center"):
        determine_approval_route(request)
