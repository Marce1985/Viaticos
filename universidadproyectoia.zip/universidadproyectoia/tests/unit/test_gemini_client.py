import json

import pytest

from config.settings import Settings
from integrations.gemini_client import GeminiClient, GeminiClientError
from schemas.document_ai_schema import ApprovalSummary, InvitationData


class _FakeResponse:
    def __init__(self, text: str) -> None:
        self.text = text


class _FakeModels:
    def __init__(self, responses: list[str | Exception]) -> None:
        self.responses = responses
        self.calls = 0

    def generate_content(self, **_: object) -> _FakeResponse:
        response = self.responses[self.calls]
        self.calls += 1
        if isinstance(response, Exception):
            raise response
        return _FakeResponse(response)


class _FakeTransport:
    def __init__(self, responses: list[str | Exception]) -> None:
        self.models = _FakeModels(responses)


def test_generate_structured_returns_mock_payload_when_mock_mode_enabled() -> None:
    settings = Settings.model_construct(
        app_env="local",
        debug=True,
        secret_key="x",
        database_url="sqlite:///./test.db",
        enable_gemini=True,
        gemini_api_key="",
        gemini_model="gemini-3-flash-preview",
        gemini_mode="mock",
        sharepoint_mode="mock",
        sap_mode="mock",
        auth_mode="mock",
    )
    client = GeminiClient(settings=settings)

    result = client.extract_invitation_data("Invitacion a benchmarking en Madrid.")

    assert isinstance(result, InvitationData)
    assert result.destination_city == "Madrid"


def test_generate_structured_retries_and_validates_sdk_payload() -> None:
    settings = Settings.model_construct(
        app_env="local",
        debug=True,
        secret_key="x",
        database_url="sqlite:///./test.db",
        enable_gemini=True,
        gemini_api_key="test-key",
        gemini_model="gemini-3-flash-preview",
        gemini_mode="live",
        sharepoint_mode="mock",
        sap_mode="mock",
        auth_mode="mock",
    )
    payload = json.dumps(
        {
            "summary": "Aprobacion general positiva.",
            "key_risks": ["Validar factura final"],
            "action_items": ["Solicitar factura legible"],
        }
    )
    transport = _FakeTransport([RuntimeError("429"), payload])
    client = GeminiClient(settings=settings, transport=transport, retry_delay_seconds=0)

    result = client.generate_structured(
        prompt="Resume comentarios",
        response_model=ApprovalSummary,
    )

    assert result.summary == "Aprobacion general positiva."
    assert transport.models.calls == 2


def test_generate_structured_raises_when_disabled() -> None:
    settings = Settings.model_construct(
        app_env="local",
        debug=True,
        secret_key="x",
        database_url="sqlite:///./test.db",
        enable_gemini=False,
        gemini_api_key="",
        gemini_model="gemini-3-flash-preview",
        gemini_mode="mock",
        sharepoint_mode="mock",
        sap_mode="mock",
        auth_mode="mock",
    )
    client = GeminiClient(settings=settings)

    with pytest.raises(GeminiClientError, match="disabled"):
        client.generate_structured(prompt="test", response_model=ApprovalSummary)
