from datetime import date
from decimal import Decimal

import pytest
from sqlalchemy.orm import Session

from database.seed import create_schema, seed_local_data
from database.session import build_engine, build_session_factory
from domain.enums import TravelRequestStatus
from schemas.legalizacion_schema import ExpenseItemInput, LegalizationCloseInput
from schemas.pago_schema import PaymentConfirmationInput, PaymentNotificationInput
from services.legalizacion_service import LegalizacionService, LegalizacionServiceError
from services.pagos_service import PagosService


@pytest.fixture()
def db_session(tmp_path: pytest.TempPathFactory) -> Session:
    database_path = tmp_path / "unit_legalizacion_service.db"
    engine = build_engine(f"sqlite:///{database_path}")
    session_factory = build_session_factory(engine)
    with session_factory() as bootstrap_session:
        create_schema(bootstrap_session)
    session = session_factory()
    try:
        yield session
    finally:
        session.close()
        engine.dispose()


def _prepare_confirmed_payment(session: Session) -> int:
    seed_ids = seed_local_data(session)
    pagos_service = PagosService(session)
    pagos_service.notify_payment(
        PaymentNotificationInput(
            request_id=seed_ids["payable_request_id"],
            sent_to="tesoreria@example.com",
            reference_code="REF-L-001",
            notified_amount=Decimal("7800.00"),
        )
    )
    pagos_service.confirm_payment(
        PaymentConfirmationInput(
            request_id=seed_ids["payable_request_id"],
            paid_amount=Decimal("7500.00"),
        )
    )
    return seed_ids["payable_request_id"]


def test_add_expense_item_updates_supported_amount_and_balances(db_session: Session) -> None:
    request_id = _prepare_confirmed_payment(db_session)
    service = LegalizacionService(db_session)

    summary = service.add_expense_item(
        ExpenseItemInput(
            request_id=request_id,
            category="Hospedaje",
            amount=Decimal("3000.00"),
            currency="COP",
            vendor="Hotel Centro",
            expense_date=date(2026, 8, 3),
            description="Tres noches de hospedaje",
        )
    )

    assert summary.request_status == TravelRequestStatus.EN_LEGALIZACION
    assert summary.supported_amount == Decimal("3000.00")
    assert summary.balance_reimbursement_company == Decimal("4500.00")
    assert len(summary.items) == 1


def test_add_expense_item_converts_currency_when_exchange_rate_is_provided(
    db_session: Session,
) -> None:
    request_id = _prepare_confirmed_payment(db_session)
    service = LegalizacionService(db_session)

    summary = service.add_expense_item(
        ExpenseItemInput(
            request_id=request_id,
            category="Transporte",
            amount=Decimal("50.00"),
            currency="USD",
            exchange_rate=Decimal("4000.00"),
            vendor="Taxi MX",
        )
    )

    assert summary.supported_amount == Decimal("200000.00")
    assert summary.balance_favor_employee == Decimal("192500.00")


def test_close_legalization_marks_request_as_legalized(db_session: Session) -> None:
    request_id = _prepare_confirmed_payment(db_session)
    service = LegalizacionService(db_session)
    service.add_expense_item(
        ExpenseItemInput(
            request_id=request_id,
            category="Alimentacion",
            amount=Decimal("6000.00"),
            currency="COP",
        )
    )

    summary = service.close_legalization(LegalizationCloseInput(request_id=request_id))

    assert summary.request_status == TravelRequestStatus.LEGALIZADA


def test_add_expense_item_requires_confirmed_payment(db_session: Session) -> None:
    seed_ids = seed_local_data(db_session)
    service = LegalizacionService(db_session)

    with pytest.raises(LegalizacionServiceError, match="confirmed payment"):
        service.add_expense_item(
            ExpenseItemInput(
                request_id=seed_ids["request_id"],
                category="Hospedaje",
                amount=Decimal("100.00"),
                currency="EUR",
            )
        )
