import logging

from config.logging import configure_logging, set_correlation_id
from config.settings import Settings
from integrations.aad_client import AadClient
from integrations.notification_client import NotificationClient
from integrations.sap_client import SapClient


def test_settings_normalize_modes_and_feature_flags() -> None:
    settings = Settings.model_construct(
        app_env="LOCAL",
        debug=True,
        secret_key="x",
        database_url="sqlite:///./test.db",
        log_level="debug",
        default_timezone="America/Bogota",
        enable_gemini=True,
        gemini_api_key="",
        gemini_model="gemini-3-flash-preview",
        gemini_mode="mock",
        documents_storage_path="./docs",
        sharepoint_mode="mock",
        sap_mode="mock",
        auth_mode="mock",
        enable_corporate_placeholders=True,
    )

    assert settings.feature_flags["enable_gemini"] is True
    assert settings.feature_flags["enable_corporate_placeholders"] is True


def test_logging_includes_correlation_id(caplog) -> None:
    configure_logging(debug=False, level_name="INFO")
    set_correlation_id("corr-123")

    logger = logging.getLogger("tests.logging")
    with caplog.at_level(logging.INFO):
        logger.info("structured message")

    assert any(record.correlation_id == "corr-123" for record in caplog.records)


def test_corporate_placeholder_clients_return_mock_payloads() -> None:
    settings = Settings.model_construct(
        app_env="local",
        debug=False,
        secret_key="x",
        database_url="sqlite:///./test.db",
        log_level="INFO",
        default_timezone="America/Bogota",
        enable_gemini=True,
        gemini_api_key="",
        gemini_model="gemini-3-flash-preview",
        gemini_mode="mock",
        documents_storage_path="./docs",
        sharepoint_mode="mock",
        sap_mode="mock",
        auth_mode="mock",
        enable_corporate_placeholders=True,
    )

    aad_user = AadClient(settings).get_current_user()
    sap_response = SapClient(settings).send_payment_order({"reference_code": "SAP-001"})
    notification_response = NotificationClient(settings).send_structured_message(
        target="tesoreria@example.com",
        subject="Pago",
        body="Orden enviada",
    )

    assert aad_user["email"] == "usuario.demo@example.com"
    assert sap_response["status"] == "queued"
    assert notification_response["status"] == "sent"
