from decimal import Decimal

import pytest
from sqlalchemy.orm import Session

from database.seed import create_schema, seed_local_data
from database.session import build_engine, build_session_factory
from domain.enums import TravelRequestStatus
from repositories.pago_repository import PagoRepository
from repositories.solicitud_repository import SolicitudRepository
from schemas.pago_schema import PaymentConfirmationInput, PaymentNotificationInput
from services.pagos_service import PagosService, PagosServiceError


@pytest.fixture()
def db_session(tmp_path: pytest.TempPathFactory) -> Session:
    database_path = tmp_path / "unit_pagos_service.db"
    engine = build_engine(f"sqlite:///{database_path}")
    session_factory = build_session_factory(engine)
    with session_factory() as bootstrap_session:
        create_schema(bootstrap_session)
    session = session_factory()
    try:
        yield session
    finally:
        session.close()
        engine.dispose()


def test_notify_payment_updates_order_and_request_status(db_session: Session) -> None:
    seed_ids = seed_local_data(db_session)
    service = PagosService(db_session)

    result = service.notify_payment(
        PaymentNotificationInput(
            request_id=seed_ids["payable_request_id"],
            sent_to="tesoreria@example.com",
            reference_code="REF-001",
            notified_amount=Decimal("7800.00"),
        )
    )

    request = SolicitudRepository(db_session).get_by_id(seed_ids["payable_request_id"])
    payment_order = PagoRepository(db_session).get_by_request_id(seed_ids["payable_request_id"])

    assert result.request_status == TravelRequestStatus.PAGO_NOTIFICADO
    assert request is not None
    assert request.status == TravelRequestStatus.PAGO_NOTIFICADO
    assert payment_order is not None
    assert payment_order.notified_amount == Decimal("7800.00")
    assert len(payment_order.notifications) == 1


def test_confirm_payment_moves_request_to_confirmed(db_session: Session) -> None:
    seed_ids = seed_local_data(db_session)
    service = PagosService(db_session)
    service.notify_payment(
        PaymentNotificationInput(
            request_id=seed_ids["payable_request_id"],
            sent_to="tesoreria@example.com",
            reference_code="REF-002",
            notified_amount=Decimal("7800.00"),
        )
    )

    result = service.confirm_payment(
        PaymentConfirmationInput(
            request_id=seed_ids["payable_request_id"],
            paid_amount=Decimal("7600.00"),
        )
    )

    request = SolicitudRepository(db_session).get_by_id(seed_ids["payable_request_id"])
    payment_order = PagoRepository(db_session).get_by_request_id(seed_ids["payable_request_id"])

    assert result.request_status == TravelRequestStatus.PAGO_CONFIRMADO
    assert request is not None
    assert request.status == TravelRequestStatus.PAGO_CONFIRMADO
    assert payment_order is not None
    assert payment_order.paid_amount == Decimal("7600.00")


def test_notify_payment_requires_existing_payment_order(db_session: Session) -> None:
    seed_ids = seed_local_data(db_session)
    service = PagosService(db_session)

    with pytest.raises(PagosServiceError, match="must exist before notification"):
        service.notify_payment(
            PaymentNotificationInput(
                request_id=seed_ids["request_id"],
                sent_to="tesoreria@example.com",
                reference_code="REF-003",
                notified_amount=Decimal("1000.00"),
            )
        )
