from datetime import date
from decimal import Decimal

import pytest
from sqlalchemy.orm import Session

from database.seed import create_schema
from database.session import build_engine, build_session_factory
from domain.enums import ApprovalDecision, ApprovalRole, TravelRequestStatus
from repositories.auditoria_repository import AuditoriaRepository
from repositories.solicitud_repository import SolicitudRepository
from schemas.aprobacion_schema import ApprovalActionInput
from schemas.solicitud_schema import SolicitudDraftInput
from services.aprobacion_service import AprobacionService
from services.solicitud_service import SolicitudService


@pytest.fixture()
def db_session(tmp_path: pytest.TempPathFactory) -> Session:
    database_path = tmp_path / "unit_aprobacion_service.db"
    engine = build_engine(f"sqlite:///{database_path}")
    session_factory = build_session_factory(engine)
    with session_factory() as bootstrap_session:
        create_schema(bootstrap_session)
    session = session_factory()
    try:
        yield session
    finally:
        session.close()
        engine.dispose()


def build_submitted_request(db_session: Session) -> int:
    solicitud_service = SolicitudService(db_session)
    draft = solicitud_service.save_draft(
        SolicitudDraftInput(
            employee_id=11,
            manager_id=12,
            cost_center_id=13,
            destination="Sao Paulo",
            country="Brasil",
            start_date=date(2026, 9, 1),
            end_date=date(2026, 9, 4),
            travel_purpose="Benchmarking de OCR y automatizacion financiera",
            requires_tickets=True,
            requires_external_tools=False,
            requires_nda=False,
            destination_international=True,
            estimated_amount=Decimal("8500.00"),
            currency="USD",
            exchange_rate_reference=Decimal("4022.10"),
        )
    )
    solicitud_service.submit_request(draft.id)
    return draft.id


def test_approve_moves_request_to_next_status_and_logs_event(db_session: Session) -> None:
    request_id = build_submitted_request(db_session)
    service = AprobacionService(db_session)

    result = service.approve(
        ApprovalActionInput(
            request_id=request_id,
            actor_id=12,
            role=ApprovalRole.JEFE,
            comments="Aprobado por jefe inmediato.",
        )
    )

    stored_request = SolicitudRepository(db_session).get_by_id(request_id)
    timeline = AuditoriaRepository(db_session).list_timeline(request_id)

    assert result.decision == ApprovalDecision.APROBAR
    assert result.new_status == TravelRequestStatus.EN_VALIDACION_GH
    assert stored_request is not None
    assert stored_request.status == TravelRequestStatus.EN_VALIDACION_GH
    assert timeline[-1].event_type == "APPROVAL_APROBAR"


def test_reject_marks_request_as_rejected(db_session: Session) -> None:
    request_id = build_submitted_request(db_session)
    service = AprobacionService(db_session)

    result = service.reject(
        ApprovalActionInput(
            request_id=request_id,
            actor_id=12,
            role=ApprovalRole.JEFE,
            comments="Se requiere replantear presupuesto.",
        )
    )

    stored_request = SolicitudRepository(db_session).get_by_id(request_id)

    assert result.decision == ApprovalDecision.RECHAZAR
    assert result.new_status == TravelRequestStatus.RECHAZADA
    assert stored_request is not None
    assert stored_request.status == TravelRequestStatus.RECHAZADA


def test_return_for_adjustments_updates_request_status(db_session: Session) -> None:
    request_id = build_submitted_request(db_session)
    service = AprobacionService(db_session)

    result = service.return_for_adjustments(
        ApprovalActionInput(
            request_id=request_id,
            actor_id=12,
            role=ApprovalRole.JEFE,
            comments="Ajustar justificacion del viaje.",
        )
    )

    stored_request = SolicitudRepository(db_session).get_by_id(request_id)

    assert result.decision == ApprovalDecision.DEVOLVER
    assert result.new_status == TravelRequestStatus.DEVUELTA_A_AJUSTES
    assert stored_request is not None
    assert stored_request.status == TravelRequestStatus.DEVUELTA_A_AJUSTES
