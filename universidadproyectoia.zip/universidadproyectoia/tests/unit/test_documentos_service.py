from config.settings import Settings
from integrations.gemini_client import GeminiClient
from services.documentos_service import DocumentosService


def _mock_settings() -> Settings:
    return Settings.model_construct(
        app_env="local",
        debug=True,
        secret_key="x",
        database_url="sqlite:///./test.db",
        enable_gemini=True,
        gemini_api_key="",
        gemini_model="gemini-3-flash-preview",
        gemini_mode="mock",
        sharepoint_mode="mock",
        sap_mode="mock",
        auth_mode="mock",
    )


def test_documentos_service_extracts_invitation_data_with_mock_client() -> None:
    service = DocumentosService(GeminiClient(settings=_mock_settings()))

    result = service.extract_invitation_data("Invitacion para benchmarking en Madrid del 10 al 14 de julio.")

    assert result.organization_name == "Open Benchmark Labs"
    assert result.destination_country == "Espana"


def test_documentos_service_classifies_and_normalizes_documents() -> None:
    service = DocumentosService(GeminiClient(settings=_mock_settings()))

    classification = service.classify_supporting_document("Carta de invitacion oficial.")
    normalized = service.normalize_expense_item("Hotel Gran Via USD 120.50 2026-07-11")

    assert classification.document_type == "INVITACION"
    assert normalized.currency == "USD"
    assert normalized.amount == 120.5
