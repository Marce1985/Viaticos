from pathlib import Path

import pytest
from sqlalchemy.orm import Session

from database.seed import create_schema, seed_local_data
from database.session import build_engine, build_session_factory
from integrations.sharepoint_client import SharePointClient
from repositories.document_repository import DocumentRepository
from services.documentos_service import DocumentosService


@pytest.fixture()
def db_session(tmp_path: pytest.TempPathFactory) -> tuple[Session, Path]:
    database_path = tmp_path / "integration_documents.db"
    storage_path = tmp_path / "generated_docs"
    engine = build_engine(f"sqlite:///{database_path}")
    session_factory = build_session_factory(engine)
    with session_factory() as bootstrap_session:
        create_schema(bootstrap_session)
    session = session_factory()
    try:
        yield session, storage_path
    finally:
        session.close()
        engine.dispose()


def test_document_generation_persists_files_and_metadata(
    db_session: tuple[Session, Path],
) -> None:
    session, storage_path = db_session
    seed_ids = seed_local_data(session)
    service = DocumentosService(
        session=session,
        sharepoint_client=SharePointClient(base_path=storage_path),
        templates_dir="templates",
    )

    generated = service.generate_document_package(seed_ids["request_id"])

    stored_documents = DocumentRepository(session).list_for_request(seed_ids["request_id"])

    assert len(generated) == 3
    assert len(stored_documents) == 3
    assert generated[0].file_name.startswith("SOL-2026-0001_resolucion")
    assert "Resolucion de comision" in generated[0].content
    assert Path(generated[0].storage_path).exists()
    assert "Carta base de desplazamiento" in Path(generated[1].storage_path).read_text(encoding="utf-8")
    assert stored_documents[-1].file_name.endswith("_checklist_v01.html")
