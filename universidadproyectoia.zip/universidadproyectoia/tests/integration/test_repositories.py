from datetime import date
from decimal import Decimal

import pytest
from sqlalchemy.orm import Session

from database.seed import create_schema, seed_local_data
from database.session import build_engine, build_session_factory
from domain.enums import ApprovalDecision, ApprovalRole, TravelRequestStatus
from repositories.aprobacion_repository import AprobacionRepository
from repositories.auditoria_repository import AuditoriaRepository
from repositories.catalog_repository import CatalogRepository
from repositories.solicitud_repository import SolicitudRepository


@pytest.fixture()
def db_session(tmp_path: pytest.TempPathFactory) -> Session:
    database_path = tmp_path / "integration_viaticos.db"
    engine = build_engine(f"sqlite:///{database_path}")
    create_schema_target = build_session_factory(engine)
    with create_schema_target() as schema_session:
        create_schema(schema_session)
    session = create_schema_target()
    try:
        yield session
    finally:
        session.close()
        engine.dispose()


def test_repositories_can_create_and_fetch_request(db_session: Session) -> None:
    catalog_repository = CatalogRepository(db_session)
    solicitud_repository = SolicitudRepository(db_session)

    cost_center = catalog_repository.create_cost_center(code="CC-001", name="Innovacion")
    manager = catalog_repository.create_employee(
        full_name="Ana Gomez",
        email="ana.gomez@example.com",
        cost_center_id=cost_center.id,
    )
    employee = catalog_repository.create_employee(
        full_name="Pedro Silva",
        email="pedro.silva@example.com",
        manager_id=manager.id,
        cost_center_id=cost_center.id,
    )
    request = solicitud_repository.create_request(
        request_code="SOL-INT-001",
        employee_id=employee.id,
        manager_id=manager.id,
        cost_center_id=cost_center.id,
        destination="Ciudad de Mexico",
        country="Mexico",
        start_date=date(2026, 7, 1),
        end_date=date(2026, 7, 5),
        travel_purpose="Benchmarking retail AI",
        estimated_amount=Decimal("5400.00"),
        currency="COP",
        status=TravelRequestStatus.RADICADA,
    )
    db_session.commit()

    stored_request = solicitud_repository.get_by_id(request.id)

    assert stored_request is not None
    assert stored_request.request_code == "SOL-INT-001"
    assert stored_request.destination == "Ciudad de Mexico"


def test_repositories_list_by_status_and_role_inbox(db_session: Session) -> None:
    seed_ids = seed_local_data(db_session)
    solicitud_repository = SolicitudRepository(db_session)
    aprobacion_repository = AprobacionRepository(db_session)

    pending_hh_requests = solicitud_repository.list_by_status(TravelRequestStatus.EN_VALIDACION_GH)
    gh_inbox = aprobacion_repository.list_inbox_by_role(ApprovalRole.GESTION_HUMANA)

    assert [request.id for request in pending_hh_requests] == [seed_ids["request_id"]]
    assert [request.id for request in gh_inbox] == [seed_ids["request_id"]]


def test_audit_timeline_is_persisted(db_session: Session) -> None:
    seed_ids = seed_local_data(db_session)
    aprobacion_repository = AprobacionRepository(db_session)
    auditoria_repository = AuditoriaRepository(db_session)

    aprobacion_repository.create_event(
        request_id=seed_ids["request_id"],
        role=ApprovalRole.GESTION_HUMANA,
        decision=ApprovalDecision.APROBAR,
        comments="Validacion de talento humano completada.",
    )
    auditoria_repository.log_event(
        event_type="GH_APPROVED",
        request_id=seed_ids["request_id"],
        actor_id=seed_ids["analyst_id"],
        details="Paso de gestion humana aprobado.",
    )
    db_session.commit()

    timeline = auditoria_repository.list_timeline(seed_ids["request_id"])
    events = aprobacion_repository.list_events_for_request(seed_ids["request_id"])

    assert len(timeline) == 3
    assert timeline[-1].event_type == "GH_APPROVED"
    assert len(events) == 2
    assert events[-1].comments == "Validacion de talento humano completada."
