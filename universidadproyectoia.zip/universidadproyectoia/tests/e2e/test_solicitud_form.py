from collections.abc import Iterable

from dash import page_registry
from dash.development.base_component import Component

from app import create_app


def _walk(component: Component | str | None) -> Iterable[Component]:
    if component is None or isinstance(component, str):
        return []
    items: list[Component] = [component]
    children = getattr(component, "children", None)
    if isinstance(children, list):
        for child in children:
            items.extend(_walk(child))
    else:
        items.extend(_walk(children))
    return items


def test_solicitud_page_contains_core_form_controls() -> None:
    create_app()
    solicitud_page = page_registry["pages.solicitud"]["layout"]
    if callable(solicitud_page):
        solicitud_page = solicitud_page()

    component_ids = {getattr(component, "id", None) for component in _walk(solicitud_page) if getattr(component, "id", None) is not None}

    assert "solicitud-employee-id" in component_ids
    assert "solicitud-manager-id" in component_ids
    assert "solicitud-cost-center-id" in component_ids
    assert "solicitud-save-draft" in component_ids
    assert "solicitud-submit-request" in component_ids
