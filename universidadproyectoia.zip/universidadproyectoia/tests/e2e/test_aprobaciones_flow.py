from dash import page_registry
from dash.development.base_component import Component

from app import create_app


def _walk(component: Component | str | None) -> list[Component]:
    if component is None or isinstance(component, str):
        return []
    nodes = [component]
    children = getattr(component, "children", None)
    if isinstance(children, list):
        for child in children:
            nodes.extend(_walk(child))
    else:
        nodes.extend(_walk(children))
    return nodes


def test_aprobaciones_page_contains_core_controls() -> None:
    create_app()
    layout = page_registry["pages.aprobaciones"]["layout"]
    if callable(layout):
        layout = layout()

    component_ids = {getattr(component, "id", None) for component in _walk(layout) if getattr(component, "id", None) is not None}

    assert "aprobaciones-role-filter" in component_ids
    assert "aprobaciones-inbox" in component_ids
    assert "aprobaciones-detail" in component_ids
    assert "aprobaciones-approve" in component_ids
    assert "aprobaciones-reject" in component_ids
    assert "aprobaciones-return" in component_ids
