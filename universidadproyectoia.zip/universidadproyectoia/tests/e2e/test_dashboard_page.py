from dash import page_registry
from dash.development.base_component import Component

from app import create_app


def _walk(component: Component | str | None) -> list[Component]:
    if component is None or isinstance(component, str):
        return []
    nodes = [component]
    children = getattr(component, "children", None)
    if isinstance(children, list):
        for child in children:
            nodes.extend(_walk(child))
    else:
        nodes.extend(_walk(children))
    return nodes


def test_dashboard_page_contains_core_controls() -> None:
    create_app()
    layout = page_registry["pages.dashboard"]["layout"]
    if callable(layout):
        layout = layout()

    component_ids = {getattr(component, "id", None) for component in _walk(layout) if getattr(component, "id", None) is not None}

    assert "dashboard-refresh" in component_ids
    assert "dashboard-kpis" in component_ids
    assert "dashboard-status-chart" in component_ids
    assert "dashboard-stage-chart" in component_ids
    assert "dashboard-payment-chart" in component_ids
    assert "dashboard-sla-chart" in component_ids
