from dash import page_registry

from app import create_app


def test_dash_app_boots_with_expected_pages() -> None:
    app = create_app()

    assert app.title == "Portal de Viaticos"
    assert app.layout is not None

    expected_routes = {"/", "/solicitud", "/aprobaciones", "/pagos", "/legalizacion", "/dashboard"}
    actual_routes = {page["path"] for page in page_registry.values()}

    assert expected_routes.issubset(actual_routes)
