from datetime import date, datetime
from decimal import Decimal

from pydantic import BaseModel, ConfigDict, Field

from domain.enums import ApprovalRole, TravelRequestStatus


class SolicitudDraftInput(BaseModel):
    request_code: str | None = None
    employee_id: int
    manager_id: int | None = None
    cost_center_id: int | None = None
    destination: str
    country: str
    start_date: date
    end_date: date
    travel_purpose: str
    requires_tickets: bool = False
    requires_external_tools: bool = False
    requires_nda: bool = False
    destination_international: bool = False
    estimated_amount: Decimal = Field(default=Decimal("0"))
    currency: str = "COP"
    exchange_rate_reference: Decimal | None = None


class SolicitudResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    request_code: str
    employee_id: int
    manager_id: int | None
    cost_center_id: int | None
    destination: str
    country: str
    start_date: date
    end_date: date
    travel_purpose: str
    requires_tickets: bool
    requires_external_tools: bool
    requires_nda: bool
    destination_international: bool
    estimated_amount: Decimal
    currency: str
    exchange_rate_reference: Decimal | None
    status: TravelRequestStatus
    created_at: datetime
    updated_at: datetime


class SubmissionResponse(BaseModel):
    request: SolicitudResponse
    current_status: TravelRequestStatus
    approval_route: list[ApprovalRole]
