from datetime import datetime

from pydantic import BaseModel, ConfigDict

from domain.enums import ApprovalDecision, ApprovalRole, TravelRequestStatus


class ApprovalActionInput(BaseModel):
    request_id: int
    actor_id: int
    role: ApprovalRole
    comments: str | None = None


class ApprovalEventResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    request_id: int
    role: ApprovalRole
    decision: ApprovalDecision
    comments: str | None
    created_at: datetime


class ApprovalActionResponse(BaseModel):
    request_id: int
    previous_status: TravelRequestStatus
    new_status: TravelRequestStatus
    decision: ApprovalDecision
    event: ApprovalEventResponse
