from datetime import date, datetime
from decimal import Decimal

from pydantic import BaseModel, ConfigDict, Field

from domain.enums import TravelRequestStatus


class ExpenseItemInput(BaseModel):
    request_id: int
    category: str
    amount: Decimal = Field(gt=0)
    currency: str
    exchange_rate: Decimal | None = Field(default=None, gt=0)
    vendor: str | None = None
    expense_date: date | None = None
    description: str | None = None


class LegalizationCloseInput(BaseModel):
    request_id: int


class ExpenseItemResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    category: str
    vendor: str | None
    amount: Decimal
    currency: str
    expense_date: date | None
    description: str | None


class LegalizationSummaryResponse(BaseModel):
    request_id: int
    request_status: TravelRequestStatus
    approved_amount: Decimal
    advance_paid: Decimal
    supported_amount: Decimal
    balance_favor_employee: Decimal
    balance_reimbursement_company: Decimal
    currency: str
    items: list[ExpenseItemResponse] = Field(default_factory=list)


class ExpenseReportResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    request_id: int
    approved_amount: Decimal
    advance_paid: Decimal
    supported_amount: Decimal
    balance_favor_employee: Decimal
    balance_reimbursement_company: Decimal
    created_at: datetime
