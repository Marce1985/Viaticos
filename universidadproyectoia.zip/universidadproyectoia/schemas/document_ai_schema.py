from datetime import date

from pydantic import BaseModel, Field


class InvitationData(BaseModel):
    organization_name: str
    destination_city: str
    destination_country: str
    start_date: date
    end_date: date
    contact_name: str | None = None


class DocumentClassification(BaseModel):
    document_type: str
    confidence: float = Field(ge=0, le=1)
    notes: str | None = None


class ApprovalSummary(BaseModel):
    summary: str
    key_risks: list[str] = Field(default_factory=list)
    action_items: list[str] = Field(default_factory=list)


class NormalizedExpense(BaseModel):
    category: str
    vendor: str | None = None
    amount: float
    currency: str
    expense_date: date | None = None
