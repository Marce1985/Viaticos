from datetime import datetime
from decimal import Decimal

from pydantic import BaseModel, ConfigDict, Field

from domain.enums import TravelRequestStatus


class PaymentOrderCreateInput(BaseModel):
    request_id: int
    approved_amount: Decimal = Field(gt=0)
    currency: str


class PaymentNotificationInput(BaseModel):
    request_id: int
    sent_to: str
    reference_code: str
    notified_amount: Decimal = Field(gt=0)


class PaymentConfirmationInput(BaseModel):
    request_id: int
    paid_amount: Decimal = Field(gt=0)


class PaymentNotificationResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    sent_to: str
    reference_code: str
    sent_at: datetime


class PaymentOrderResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    request_id: int
    approved_amount: Decimal
    notified_amount: Decimal | None
    paid_amount: Decimal | None
    currency: str
    created_at: datetime


class PaymentActionResponse(BaseModel):
    payment_order: PaymentOrderResponse
    request_status: TravelRequestStatus
    notifications: list[PaymentNotificationResponse] = Field(default_factory=list)
