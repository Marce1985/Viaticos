# Guia para Automatizar la App con Playwright

Este documento describe como automatizar pruebas end to end de la aplicacion usando Playwright.

## Objetivo

Construir una suite Playwright que permita validar los flujos principales de la app Dash desde la UI:

1. carga de la aplicacion
2. navegacion entre modulos
3. creacion y radicacion de solicitud
4. acciones de aprobacion
5. notificacion y confirmacion de pago
6. legalizacion de gastos
7. visualizacion del dashboard

## Alcance recomendado

Playwright debe cubrir flujos funcionales visibles para usuario. No debe reemplazar:

- unit tests del dominio
- integration tests de repositories
- pruebas de contratos Pydantic

Playwright debe validar:

- que la UI renderiza
- que los botones disparan cambios visibles
- que el flujo principal no se rompe

## Recomendacion de stack

Usar:

- `@playwright/test`
- Node.js `18+`

## Estructura sugerida

```text
playwright/
├── fixtures/
│   └── app.ts
├── pages/
│   ├── home.page.ts
│   ├── solicitud.page.ts
│   ├── aprobaciones.page.ts
│   ├── pagos.page.ts
│   ├── legalizacion.page.ts
│   └── dashboard.page.ts
├── tests/
│   ├── smoke.spec.ts
│   ├── solicitud.spec.ts
│   ├── aprobaciones.spec.ts
│   ├── pagos.spec.ts
│   ├── legalizacion.spec.ts
│   └── dashboard.spec.ts
├── utils/
│   └── test-data.ts
└── playwright.config.ts
```

## Precondiciones para correr Playwright

Antes de ejecutar tests:

1. activar entorno Python
2. instalar dependencias Python
3. configurar `.env`
4. levantar la app Dash

Comando sugerido:

```bash
python run.py
```

La suite Playwright debe asumir la app en:

```text
http://127.0.0.1:8050
```

## Configuracion sugerida de Playwright

Ejemplo conceptual para `playwright.config.ts`:

```ts
import { defineConfig } from "@playwright/test";

export default defineConfig({
  testDir: "./playwright/tests",
  use: {
    baseURL: "http://127.0.0.1:8050",
    headless: true,
    trace: "on-first-retry",
    screenshot: "only-on-failure",
    video: "retain-on-failure",
  },
  reporter: [["html"], ["list"]],
});
```

## Estrategia de selectores

Como la app esta en Dash, conviene usar selectores estables.

Preferir:

- ids de componentes Dash
- texto visible cuando sea muy estable
- `data-testid` si luego decides agregarlos

Evitar:

- selectores CSS frágiles
- jerarquias profundas de DOM

## Selectores ya disponibles en la app

### Solicitud

- `#solicitud-employee-id`
- `#solicitud-manager-id`
- `#solicitud-cost-center-id`
- `#solicitud-destination`
- `#solicitud-country`
- `#solicitud-start-date`
- `#solicitud-end-date`
- `#solicitud-purpose`
- `#solicitud-estimated-amount`
- `#solicitud-currency`
- `#solicitud-exchange-rate`
- `#solicitud-save-draft`
- `#solicitud-submit-request`
- `#solicitud-feedback`

### Aprobaciones

- `#aprobaciones-role-filter`
- `#aprobaciones-inbox`
- `#aprobaciones-detail`
- `#aprobaciones-comments`
- `#aprobaciones-approve`
- `#aprobaciones-reject`
- `#aprobaciones-return`
- `#aprobaciones-action-feedback`

### Pagos

- `#pagos-refresh`
- `#pagos-queue`
- `#pagos-detail`
- `#pagos-sent-to`
- `#pagos-reference-code`
- `#pagos-notified-amount`
- `#pagos-paid-amount`
- `#pagos-notify`
- `#pagos-confirm`
- `#pagos-feedback`

### Legalizacion

- `#legalizacion-refresh`
- `#legalizacion-queue`
- `#legalizacion-summary`
- `#legalizacion-category`
- `#legalizacion-vendor`
- `#legalizacion-amount`
- `#legalizacion-currency`
- `#legalizacion-rate`
- `#legalizacion-date`
- `#legalizacion-description`
- `#legalizacion-add-item`
- `#legalizacion-close`
- `#legalizacion-feedback`
- `#legalizacion-items`

### Dashboard

- `#dashboard-refresh`
- `#dashboard-kpis`
- `#dashboard-status-chart`
- `#dashboard-stage-chart`
- `#dashboard-payment-chart`
- `#dashboard-sla-chart`

## Casos de prueba recomendados

### 1. Smoke

Objetivo:

- verificar que la app carga y navega

Cobertura:

- abrir `/`
- comprobar menu lateral
- abrir `Solicitud`
- abrir `Aprobaciones`
- abrir `Pagos`
- abrir `Legalizacion`
- abrir `Dashboard`

### 2. Solicitud

Objetivo:

- validar guardado de borrador y radicacion

Flujo:

1. abrir `/solicitud`
2. llenar campos obligatorios
3. guardar borrador
4. verificar feedback
5. radicar solicitud
6. verificar feedback de radicacion

### 3. Aprobaciones

Objetivo:

- validar accion de aprobacion en bandeja

Flujo:

1. abrir `/aprobaciones`
2. seleccionar rol con bandeja
3. abrir solicitud
4. escribir comentario
5. aprobar
6. validar mensaje de exito

### 4. Pagos

Objetivo:

- validar notificacion y confirmacion

Flujo:

1. abrir `/pagos`
2. refrescar cola
3. seleccionar solicitud
4. llenar correo, referencia y valor notificado
5. notificar
6. validar feedback
7. llenar valor girado
8. confirmar giro
9. validar feedback

### 5. Legalizacion

Objetivo:

- validar registro de gasto y cierre

Flujo:

1. abrir `/legalizacion`
2. seleccionar solicitud
3. registrar gasto
4. verificar resumen actualizado
5. cerrar legalizacion
6. validar feedback

### 6. Dashboard

Objetivo:

- validar que la vista ejecutiva renderiza

Flujo:

1. abrir `/dashboard`
2. refrescar
3. validar presencia de KPIs
4. validar que existen los cuatro graficos

## Orden recomendado de ejecucion

Ejecutar en este orden:

1. `smoke.spec.ts`
2. `solicitud.spec.ts`
3. `aprobaciones.spec.ts`
4. `pagos.spec.ts`
5. `legalizacion.spec.ts`
6. `dashboard.spec.ts`

## Consideraciones por estado de datos

La app usa datos sembrados automaticamente si la base local esta vacia.

Para hacer Playwright repetible:

- usa una base temporal o limpia antes de cada suite
- o elimina `viaticos.db` antes del arranque
- o crea un script de reset de datos de prueba

Recomendacion:

- preparar una rutina `test-reset` que borre la base local y reinicie la app

## Recomendacion de page objects

Usar page objects para reducir fragilidad.

Ejemplo conceptual:

```ts
export class SolicitudPage {
  constructor(private page: Page) {}

  async goto() {
    await this.page.goto("/solicitud");
  }

  async guardarBorrador() {
    await this.page.locator("#solicitud-save-draft").click();
  }
}
```

## Recomendacion para CI

En CI:

1. crear entorno Python
2. instalar dependencias Python
3. copiar `.env.example`
4. levantar app Dash en background
5. instalar dependencias Node
6. instalar navegadores Playwright
7. correr tests Playwright

## Comandos sugeridos

### Inicializar Playwright

```bash
npm init playwright@latest
```

### Ejecutar tests

```bash
npx playwright test
```

### Abrir reporte

```bash
npx playwright show-report
```

## Mejoras futuras para facilitar Playwright

Si luego quieres hacer la suite mas robusta, conviene agregar:

- `data-testid` estables
- reset de base de datos para pruebas
- fixtures con usuarios y solicitudes conocidas
- modo de app especial para test
- script de arranque y apagado automatico

## Resultado esperado

Al implementar esta guia, Playwright deberia permitir:

- validar la estabilidad visual y funcional de la demo
- detectar regresiones en los flujos criticos
- automatizar una demostracion repetible del ciclo completo
