# Modo Demo de Playwright

Este documento explica como ejecutar la suite Playwright de forma visual para una demostracion con cliente.

## Objetivo

Mostrar en navegador:

- como la automatizacion recorre la app
- que modulo esta probando
- que accion esta ejecutando

## Que se habilita en modo demo

Cuando usas el comando de demo:

- el navegador se abre en modo visible
- Playwright corre con una sola secuencia
- las acciones van mucho mas lentas, a ritmo de demostracion humana
- aparece un panel flotante dentro de la pagina explicando cada paso

## Comando recomendado

Desde la raiz del proyecto:

```bash
npm run test:e2e:demo
```

## Orden correcto antes de ejecutar

1. Instalar dependencias Node:

```bash
npm install
```

2. Instalar navegadores:

```bash
npx playwright install
```

3. Ejecutar la demo:

```bash
npm run test:e2e:demo
```

## Como funciona

La configuracion de Playwright:

- levanta automaticamente la app con `python run.py`
- espera a que `http://127.0.0.1:8050` responda
- abre Chromium
- ejecuta los tests

## Mensajes visibles en pantalla

Los mensajes flotantes se inyectan desde:

- [playwright/utils/demo-narrator.ts](/c:/Users/JoseOrellana/OneDrive%20-%20K%20Lab%20Inc/Escritorio/universidadproyectoia/playwright/utils/demo-narrator.ts)

Actualmente narran:

- inicio de la demo
- apertura de modulos
- captura de solicitud
- guardado de borrador
- radicacion
- cierre de validacion

## Tests que ya sirven para demo

- [playwright/tests/smoke.spec.ts](/c:/Users/JoseOrellana/OneDrive%20-%20K%20Lab%20Inc/Escritorio/universidadproyectoia/playwright/tests/smoke.spec.ts)
- [playwright/tests/solicitud.spec.ts](/c:/Users/JoseOrellana/OneDrive%20-%20K%20Lab%20Inc/Escritorio/universidadproyectoia/playwright/tests/solicitud.spec.ts)

## Recomendacion para presentacion

Usa este orden:

1. corre `npm run test:e2e:demo`
2. deja que termine primero `smoke`
3. luego deja correr `solicitud`
4. explica que la automatizacion ya actua como un usuario real sobre la UI

## Siguiente mejora recomendada

Si quieres una demo mas completa, podemos agregar narracion tambien a:

- aprobaciones
- pagos
- legalizacion
- dashboard
