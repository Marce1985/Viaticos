# Guia de Demo UI

Esta guia sirve para recorrer la aplicacion de forma clara en una demo funcional o presentacion interna.

## Preparacion previa

1. Activa el entorno virtual.
2. Instala dependencias si hace falta.
3. Copia `.env.example` a `.env`.
4. Verifica que `GEMINI_MODE=mock`.
5. Ejecuta la app con:

```bash
python run.py
```

6. Abre `http://127.0.0.1:8050`.

## Contexto de la demo

La aplicacion cubre el ciclo completo de una solicitud de viaticos:

1. Solicitud
2. Aprobaciones
3. Generacion documental
4. Pagos
5. Legalizacion
6. Dashboard ejecutivo

La demo ya siembra datos locales al iniciar si la base esta vacia.

## Pantalla de Inicio

Objetivo:

- mostrar que la app ya esta estructurada por modulos
- evidenciar la navegacion profesional y la separacion por capas

Que mostrar:

- barra superior
- menu lateral
- tarjetas resumen
- acceso rapido a `Solicitud`

Mensaje sugerido:

`Esta es la vista de entrada del portal. Desde aqui se accede al flujo completo del tramite y al tablero ejecutivo.`

## Modulo de Solicitud

Ruta:

- `Solicitud`

Objetivo:

- mostrar captura del viaje
- guardar borrador
- radicar solicitud

Pasos sugeridos:

1. Selecciona solicitante.
2. Selecciona jefe inmediato.
3. Selecciona centro de costo.
4. Completa destino, pais, fechas y proposito.
5. Marca banderas como:
   - `Requiere tiquetes`
   - `Requiere herramientas externas`
   - `Requiere NDA`
   - `Destino internacional`
6. Ingresa monto, moneda y tasa.
7. Muestra la `ruta estimada de aprobacion`.
8. Haz clic en `Guardar borrador`.
9. Luego haz clic en `Radicar solicitud`.

Que resaltar:

- validaciones
- feedback visual
- cambios de ruta segun reglas
- callbacks delgados y servicios por debajo

Mensaje sugerido:

`La solicitud puede guardarse como borrador o radicarse. La ruta de aprobacion se calcula en funcion de reglas de negocio y no de logica embebida en la UI.`

## Modulo de Aprobaciones

Ruta:

- `Aprobaciones`

Objetivo:

- mostrar bandeja por rol
- ver trazabilidad
- ejecutar aprobar, rechazar o devolver

Pasos sugeridos:

1. En el filtro por rol, selecciona el rol disponible con bandeja.
2. Abre una solicitud desde la tabla.
3. Muestra:
   - detalle
   - pasos del workflow
   - timeline
4. Ingresa un comentario.
5. Ejecuta una accion:
   - `Aprobar`
   - `Rechazar`
   - `Devolver`

Que resaltar:

- la bandeja cambia por rol
- el timeline se alimenta desde auditoria
- las acciones modifican estado real del tramite

Mensaje sugerido:

`Cada accion queda trazada y el estado del tramite evoluciona con base en la maquina de estados del dominio.`

## Modulo de Pagos

Ruta:

- `Pagos`

Objetivo:

- mostrar que solo entran solicitudes en estados validos para pago
- registrar notificacion estructurada
- confirmar giro

Pasos sugeridos:

1. Haz clic en `Actualizar cola`.
2. Selecciona una solicitud de la cola.
3. Completa:
   - destino de notificacion
   - referencia
   - valor notificado
4. Haz clic en `Notificar pago`.
5. Luego completa `Valor girado`.
6. Haz clic en `Confirmar giro`.

Que resaltar:

- no se permite pagar sin workflow completo
- se registran aprobado, notificado y girado
- queda trazabilidad para legalizacion posterior

Mensaje sugerido:

`La cola de pagos solo considera tramites que realmente estan en fase de pago. Esto evita errores operativos y asegura trazabilidad.`

## Modulo de Legalizacion

Ruta:

- `Legalizacion`

Objetivo:

- registrar gastos
- convertir moneda si aplica
- conciliar anticipo vs soportado
- cerrar legalizacion

Pasos sugeridos:

1. Abre una solicitud desde la cola.
2. Revisa el resumen financiero inicial.
3. Agrega uno o varios gastos:
   - categoria
   - proveedor
   - monto
   - moneda
   - tasa si aplica
   - fecha
   - descripcion
4. Muestra como cambia:
   - soportado
   - saldo a favor del empleado
   - reintegro a la compania
5. Haz clic en `Cerrar legalizacion`.

Que resaltar:

- calculos monetarios
- inicio automatico de legalizacion al primer gasto si corresponde
- cierre controlado del proceso

Mensaje sugerido:

`La legalizacion deja claro si hace falta reintegrar dinero o reconocer saldo al empleado.`

## Generacion documental

Ruta sugerida de explicacion:

- comentar desde el flujo y luego mostrar archivos en disco

Objetivo:

- evidenciar que el tramite genera documentos estructurados

Que mostrar:

- resolucion
- carta base
- checklist
- archivos generados en `generated_documents/`

Mensaje sugerido:

`La capa documental usa plantillas y registra metadata del documento, quedando lista para moverse luego a SharePoint real.`

## Gemini

Objetivo:

- mostrar que la IA es apoyo documental, no decisor financiero

Que explicar:

- extrae datos de invitaciones
- clasifica documentos
- resume comentarios
- normaliza gastos
- trabaja con modo `mock` para demo

Mensaje sugerido:

`Gemini se usa solo como asistente controlado, con salida validada por esquema y feature flag.`

## Dashboard Ejecutivo

Ruta:

- `Dashboard`

Objetivo:

- cerrar la demo mostrando valor de negocio

Que mostrar:

- solicitudes por estado
- tiempo promedio por etapa
- comparativo aprobado vs girado
- solicitudes vencidas por SLA
- KPIs superiores

Mensaje sugerido:

`El dashboard resume el estado operativo del proceso y permite detectar cuellos de botella, pagos pendientes y diferencias de legalizacion.`

## Cierre sugerido de la demo

Mensaje breve:

`La solucion ya cubre el ciclo de vida completo del tramite en modo demo empresarial, con arquitectura lista para integraciones corporativas y pruebas automatizadas.`

## Tips para la presentacion

- Ten la app ya abierta antes de empezar.
- Si quieres una demo mas limpia, elimina `viaticos.db` y vuelve a iniciar para regenerar seed.
- Mantente en modo `mock` para Gemini durante presentaciones.
- Recorre siempre el flujo en este orden:
  1. Solicitud
  2. Aprobaciones
  3. Pagos
  4. Legalizacion
  5. Dashboard
