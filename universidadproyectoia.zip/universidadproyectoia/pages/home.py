import dash
import dash_bootstrap_components as dbc
from dash import html

dash.register_page(__name__, path="/", name="Inicio", order=0)


def _metric_card(title: str, value: str, accent: str) -> dbc.Card:
    return dbc.Card(
        dbc.CardBody(
            [
                html.Span(title, className="metric-label"),
                html.H3(value, className="metric-value"),
                html.Div(className=f"metric-accent metric-accent-{accent}"),
            ]
        ),
        class_name="metric-card border-0",
    )


layout = dbc.Container(
    [
        dbc.Row(
            [
                dbc.Col(
                    dbc.Card(
                        dbc.CardBody(
                            [
                                html.Span("Modulo 0", className="hero-kicker"),
                                html.H2(
                                    "Base empresarial para el Portal de Viaticos",
                                    className="hero-title",
                                ),
                                html.P(
                                    "La aplicacion ya corre con arquitectura multipagina, "
                                    "configuracion desacoplada y una capa visual Bootstrap "
                                    "lista para crecer por modulos.",
                                    className="hero-copy",
                                ),
                                dbc.Button(
                                    "Crear nueva solicitud",
                                    href="/solicitud",
                                    color="primary",
                                    class_name="hero-button",
                                ),
                            ]
                        ),
                        class_name="hero-card border-0",
                    ),
                    lg=8,
                ),
                dbc.Col(
                    dbc.Card(
                        dbc.CardBody(
                            [
                                html.Span("Estado actual", className="summary-label"),
                                html.H3("Proyecto inicializado", className="summary-title"),
                                html.P(
                                    "La estructura ya separa UI, callbacks, servicios y " "persistencia para los siguientes modulos.",
                                    className="summary-copy",
                                ),
                            ]
                        ),
                        class_name="summary-card border-0 h-100",
                    ),
                    lg=4,
                ),
            ],
            class_name="g-4 mb-4",
        ),
        dbc.Row(
            [
                dbc.Col(_metric_card("Paginas base", "5", "blue"), md=4),
                dbc.Col(_metric_card("Capas preparadas", "8", "teal"), md=4),
                dbc.Col(_metric_card("Pruebas smoke", "1", "gold"), md=4),
            ],
            class_name="g-4",
        ),
    ],
    fluid=True,
)
