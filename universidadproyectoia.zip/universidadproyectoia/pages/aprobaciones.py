import dash
import dash_bootstrap_components as dbc
from dash import dcc, html

from database.session import SessionLocal
from services.aprobacion_service import AprobacionService

dash.register_page(__name__, path="/aprobaciones", name="Aprobaciones", order=2)


with SessionLocal() as session:
    ROLE_OPTIONS = AprobacionService(session).get_role_options()


layout = dbc.Container(
    [
        html.Div(
            [
                html.Span("Modulo 5", className="page-kicker"),
                html.H2("Bandeja de aprobaciones", className="page-title"),
                html.P(
                    "Gestiona solicitudes por rol, revisa su trazabilidad y ejecuta decisiones " "de aprobacion con soporte auditable.",
                    className="page-copy",
                ),
            ],
            className="page-header",
        ),
        dbc.Row(
            [
                dbc.Col(
                    dbc.Card(
                        dbc.CardBody(
                            [
                                html.Div(
                                    [
                                        html.Span("Bandeja por rol", className="summary-label"),
                                        dcc.Dropdown(
                                            id="aprobaciones-role-filter",
                                            options=ROLE_OPTIONS,
                                            value="JEFE",
                                            clearable=False,
                                            className="form-dropdown mt-2",
                                        ),
                                    ]
                                ),
                                html.Div(id="aprobaciones-inbox", className="mt-4"),
                            ]
                        ),
                        class_name="form-card border-0 h-100",
                    ),
                    lg=5,
                ),
                dbc.Col(
                    dbc.Card(
                        dbc.CardBody(
                            [
                                html.Div(id="aprobaciones-detail"),
                                html.Hr(className="form-divider"),
                                html.Span("Pasos del workflow", className="summary-label"),
                                html.Div(id="aprobaciones-step-summary", className="mt-3"),
                                html.Hr(className="form-divider"),
                                dbc.Label("Comentarios de la decision", html_for="aprobaciones-comments"),
                                dbc.Textarea(
                                    id="aprobaciones-comments",
                                    rows=4,
                                    placeholder="Agrega contexto para la auditoria o para devolver la solicitud.",
                                ),
                                dbc.Alert(
                                    id="aprobaciones-action-feedback",
                                    is_open=False,
                                    class_name="mt-3 border-0 shadow-sm",
                                ),
                                dbc.Row(
                                    [
                                        dbc.Col(
                                            dbc.Button(
                                                "Aprobar",
                                                id="aprobaciones-approve",
                                                color="success",
                                                class_name="w-100",
                                            ),
                                            md=4,
                                        ),
                                        dbc.Col(
                                            dbc.Button(
                                                "Rechazar",
                                                id="aprobaciones-reject",
                                                color="danger",
                                                class_name="w-100",
                                            ),
                                            md=4,
                                        ),
                                        dbc.Col(
                                            dbc.Button(
                                                "Devolver",
                                                id="aprobaciones-return",
                                                color="secondary",
                                                class_name="w-100",
                                            ),
                                            md=4,
                                        ),
                                    ],
                                    class_name="g-3 mt-1",
                                ),
                            ]
                        ),
                        class_name="form-card border-0 h-100",
                    ),
                    lg=4,
                ),
                dbc.Col(
                    dbc.Card(
                        dbc.CardBody(
                            [
                                html.Span("Timeline auditable", className="summary-label"),
                                html.Div(id="aprobaciones-timeline", className="mt-3"),
                            ]
                        ),
                        class_name="form-card border-0 h-100",
                    ),
                    lg=3,
                ),
            ],
            class_name="g-4",
        ),
        dcc.Store(id="aprobaciones-selected-request"),
    ],
    fluid=True,
)
