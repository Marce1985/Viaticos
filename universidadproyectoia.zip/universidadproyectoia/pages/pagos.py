import dash
import dash_bootstrap_components as dbc
from dash import dcc, html

dash.register_page(__name__, path="/pagos", name="Pagos", order=3)


layout = dbc.Container(
    [
        html.Div(
            [
                html.Span("Modulo 8", className="page-kicker"),
                html.H2("Cola de pagos", className="page-title"),
                html.P(
                    "Gestiona la orden de pago, la notificacion a tesoreria y la " "confirmacion de giro con trazabilidad estructurada.",
                    className="page-copy",
                ),
            ],
            className="page-header",
        ),
        dbc.Row(
            [
                dbc.Col(
                    dbc.Card(
                        dbc.CardBody(
                            [
                                html.Div(
                                    [
                                        html.Span("Cola operativa", className="summary-label"),
                                        dbc.Button(
                                            "Actualizar cola",
                                            id="pagos-refresh",
                                            color="secondary",
                                            size="sm",
                                            class_name="mt-2",
                                        ),
                                    ]
                                ),
                                html.Div(id="pagos-queue", className="mt-4"),
                            ]
                        ),
                        class_name="form-card border-0 h-100",
                    ),
                    lg=7,
                ),
                dbc.Col(
                    dbc.Card(
                        dbc.CardBody(
                            [
                                html.Div(id="pagos-detail"),
                                html.Hr(className="form-divider"),
                                dbc.Label("Destino de notificacion", html_for="pagos-sent-to"),
                                dbc.Input(
                                    id="pagos-sent-to",
                                    type="email",
                                    placeholder="tesoreria@example.com",
                                ),
                                dbc.Row(
                                    [
                                        dbc.Col(
                                            [
                                                dbc.Label(
                                                    "Referencia",
                                                    html_for="pagos-reference-code",
                                                    class_name="mt-3",
                                                ),
                                                dbc.Input(
                                                    id="pagos-reference-code",
                                                    type="text",
                                                    placeholder="REF-PAGO-2026",
                                                ),
                                            ],
                                            md=6,
                                        ),
                                        dbc.Col(
                                            [
                                                dbc.Label(
                                                    "Valor notificado",
                                                    html_for="pagos-notified-amount",
                                                    class_name="mt-3",
                                                ),
                                                dbc.Input(
                                                    id="pagos-notified-amount",
                                                    type="number",
                                                    min=0,
                                                    step=0.01,
                                                    placeholder="0.00",
                                                ),
                                            ],
                                            md=6,
                                        ),
                                    ],
                                    class_name="g-3",
                                ),
                                dbc.Label(
                                    "Valor girado",
                                    html_for="pagos-paid-amount",
                                    class_name="mt-3",
                                ),
                                dbc.Input(
                                    id="pagos-paid-amount",
                                    type="number",
                                    min=0,
                                    step=0.01,
                                    placeholder="0.00",
                                ),
                                dbc.Alert(
                                    id="pagos-feedback",
                                    is_open=False,
                                    class_name="mt-3 border-0 shadow-sm",
                                ),
                                dbc.Row(
                                    [
                                        dbc.Col(
                                            dbc.Button(
                                                "Notificar pago",
                                                id="pagos-notify",
                                                color="primary",
                                                class_name="w-100",
                                            ),
                                            md=6,
                                        ),
                                        dbc.Col(
                                            dbc.Button(
                                                "Confirmar giro",
                                                id="pagos-confirm",
                                                color="success",
                                                class_name="w-100",
                                            ),
                                            md=6,
                                        ),
                                    ],
                                    class_name="g-3 mt-1",
                                ),
                            ]
                        ),
                        class_name="form-card border-0 h-100",
                    ),
                    lg=5,
                ),
            ],
            class_name="g-4",
        ),
        dcc.Store(id="pagos-selected-request"),
    ],
    fluid=True,
)
