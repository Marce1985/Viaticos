import dash
import dash_bootstrap_components as dbc
from dash import dcc, html

dash.register_page(__name__, path="/dashboard", name="Dashboard", order=5)


layout = dbc.Container(
    [
        html.Div(
            [
                html.Span("Vision ejecutiva", className="page-kicker"),
                html.H2("Dashboard operativo", className="page-title"),
                html.P(
                    "Visualiza el estado del proceso, tiempos promedio, pagos y alertas " "de legalizacion desde una sola vista ejecutiva.",
                    className="page-copy",
                ),
            ],
            className="page-header",
        ),
        dbc.Row(
            [
                dbc.Col(
                    dbc.Button(
                        "Actualizar dashboard",
                        id="dashboard-refresh",
                        color="secondary",
                        size="sm",
                    ),
                    width="auto",
                )
            ],
            class_name="mb-3",
        ),
        dbc.Row(id="dashboard-kpis", class_name="g-4 mb-4"),
        dbc.Row(
            [
                dbc.Col(
                    dbc.Card(
                        dbc.CardBody(dcc.Graph(id="dashboard-status-chart", config={"displayModeBar": False})),
                        class_name="form-card border-0 h-100",
                    ),
                    lg=6,
                ),
                dbc.Col(
                    dbc.Card(
                        dbc.CardBody(dcc.Graph(id="dashboard-stage-chart", config={"displayModeBar": False})),
                        class_name="form-card border-0 h-100",
                    ),
                    lg=6,
                ),
            ],
            class_name="g-4 mb-4",
        ),
        dbc.Row(
            [
                dbc.Col(
                    dbc.Card(
                        dbc.CardBody(dcc.Graph(id="dashboard-payment-chart", config={"displayModeBar": False})),
                        class_name="form-card border-0 h-100",
                    ),
                    lg=7,
                ),
                dbc.Col(
                    dbc.Card(
                        dbc.CardBody(dcc.Graph(id="dashboard-sla-chart", config={"displayModeBar": False})),
                        class_name="form-card border-0 h-100",
                    ),
                    lg=5,
                ),
            ],
            class_name="g-4",
        ),
    ],
    fluid=True,
)
