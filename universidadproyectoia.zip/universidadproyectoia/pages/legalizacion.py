import dash
import dash_bootstrap_components as dbc
from dash import dcc, html

dash.register_page(__name__, path="/legalizacion", name="Legalizacion", order=4)


layout = dbc.Container(
    [
        html.Div(
            [
                html.Span("Modulo 9", className="page-kicker"),
                html.H2("Legalizacion del viaje", className="page-title"),
                html.P(
                    "Registra gastos por item, concilia contra el anticipo girado y " "cierra la legalizacion con un resumen financiero claro.",
                    className="page-copy",
                ),
            ],
            className="page-header",
        ),
        dbc.Row(
            [
                dbc.Col(
                    dbc.Card(
                        dbc.CardBody(
                            [
                                html.Span("Cola de legalizacion", className="summary-label"),
                                dbc.Button(
                                    "Actualizar cola",
                                    id="legalizacion-refresh",
                                    color="secondary",
                                    size="sm",
                                    class_name="mt-2",
                                ),
                                html.Div(id="legalizacion-queue", className="mt-4"),
                            ]
                        ),
                        class_name="form-card border-0 h-100",
                    ),
                    lg=6,
                ),
                dbc.Col(
                    dbc.Card(
                        dbc.CardBody(
                            [
                                html.Div(id="legalizacion-summary"),
                                html.Hr(className="form-divider"),
                                dbc.Row(
                                    [
                                        dbc.Col(
                                            [
                                                dbc.Label("Categoria", html_for="legalizacion-category"),
                                                dbc.Input(
                                                    id="legalizacion-category",
                                                    type="text",
                                                    placeholder="Hospedaje",
                                                ),
                                            ],
                                            md=6,
                                        ),
                                        dbc.Col(
                                            [
                                                dbc.Label("Proveedor", html_for="legalizacion-vendor"),
                                                dbc.Input(
                                                    id="legalizacion-vendor",
                                                    type="text",
                                                    placeholder="Hotel o comercio",
                                                ),
                                            ],
                                            md=6,
                                        ),
                                    ],
                                    class_name="g-3",
                                ),
                                dbc.Row(
                                    [
                                        dbc.Col(
                                            [
                                                dbc.Label(
                                                    "Monto",
                                                    html_for="legalizacion-amount",
                                                    class_name="mt-3",
                                                ),
                                                dbc.Input(
                                                    id="legalizacion-amount",
                                                    type="number",
                                                    min=0,
                                                    step=0.01,
                                                    placeholder="0.00",
                                                ),
                                            ],
                                            md=4,
                                        ),
                                        dbc.Col(
                                            [
                                                dbc.Label(
                                                    "Moneda",
                                                    html_for="legalizacion-currency",
                                                    class_name="mt-3",
                                                ),
                                                dbc.Input(
                                                    id="legalizacion-currency",
                                                    type="text",
                                                    value="COP",
                                                ),
                                            ],
                                            md=4,
                                        ),
                                        dbc.Col(
                                            [
                                                dbc.Label(
                                                    "Tasa",
                                                    html_for="legalizacion-rate",
                                                    class_name="mt-3",
                                                ),
                                                dbc.Input(
                                                    id="legalizacion-rate",
                                                    type="number",
                                                    min=0,
                                                    step=0.0001,
                                                    placeholder="Opcional",
                                                ),
                                            ],
                                            md=4,
                                        ),
                                    ],
                                    class_name="g-3",
                                ),
                                dbc.Row(
                                    [
                                        dbc.Col(
                                            [
                                                dbc.Label(
                                                    "Fecha del gasto",
                                                    html_for="legalizacion-date",
                                                    class_name="mt-3",
                                                ),
                                                dcc.DatePickerSingle(
                                                    id="legalizacion-date",
                                                    display_format="YYYY-MM-DD",
                                                ),
                                            ],
                                            md=6,
                                        ),
                                        dbc.Col(
                                            [
                                                dbc.Label(
                                                    "Descripcion",
                                                    html_for="legalizacion-description",
                                                    class_name="mt-3",
                                                ),
                                                dbc.Input(
                                                    id="legalizacion-description",
                                                    type="text",
                                                    placeholder="Detalle breve del soporte",
                                                ),
                                            ],
                                            md=6,
                                        ),
                                    ],
                                    class_name="g-3",
                                ),
                                dbc.Alert(
                                    id="legalizacion-feedback",
                                    is_open=False,
                                    class_name="mt-3 border-0 shadow-sm",
                                ),
                                dbc.Row(
                                    [
                                        dbc.Col(
                                            dbc.Button(
                                                "Agregar gasto",
                                                id="legalizacion-add-item",
                                                color="primary",
                                                class_name="w-100",
                                            ),
                                            md=6,
                                        ),
                                        dbc.Col(
                                            dbc.Button(
                                                "Cerrar legalizacion",
                                                id="legalizacion-close",
                                                color="success",
                                                class_name="w-100",
                                            ),
                                            md=6,
                                        ),
                                    ],
                                    class_name="g-3 mt-1",
                                ),
                            ]
                        ),
                        class_name="form-card border-0 h-100",
                    ),
                    lg=6,
                ),
            ],
            class_name="g-4",
        ),
        dbc.Row(
            [
                dbc.Col(
                    dbc.Card(
                        dbc.CardBody(
                            [
                                html.Span("Items registrados", className="summary-label"),
                                html.Div(id="legalizacion-items", className="mt-3"),
                            ]
                        ),
                        class_name="form-card border-0",
                    )
                )
            ],
            class_name="g-4 mt-1",
        ),
        dcc.Store(id="legalizacion-selected-request"),
    ],
    fluid=True,
)
