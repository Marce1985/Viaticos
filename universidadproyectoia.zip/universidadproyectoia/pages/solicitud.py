import dash
import dash_bootstrap_components as dbc
from dash import html

from components.forms import build_solicitud_form
from database.session import SessionLocal
from services.catalog_service import CatalogService

dash.register_page(__name__, path="/solicitud", name="Solicitud", order=1)


with SessionLocal() as session:
    catalog_service = CatalogService(session)
    EMPLOYEE_OPTIONS = catalog_service.get_employee_options()
    COST_CENTER_OPTIONS = catalog_service.get_cost_center_options()


layout = dbc.Container(
    [
        html.Div(
            [
                html.Span("Modulo 4", className="page-kicker"),
                html.H2("Formulario de solicitud", className="page-title"),
                html.P(
                    "Experiencia inicial para capturar solicitudes de viaticos con "
                    "validaciones, vista previa de ruta y acciones de borrador o radicacion.",
                    className="page-copy",
                ),
            ],
            className="page-header",
        ),
        dbc.Row(
            [
                dbc.Col(
                    build_solicitud_form(
                        employee_options=EMPLOYEE_OPTIONS,
                        cost_center_options=COST_CENTER_OPTIONS,
                    ),
                    lg=8,
                ),
                dbc.Col(
                    dbc.Card(
                        dbc.CardBody(
                            [
                                html.Span("Guia rapida", className="summary-label"),
                                html.H3("Checklist operativo", className="summary-title"),
                                html.Ul(
                                    [
                                        html.Li("Define solicitante, jefe y centro de costo."),
                                        html.Li("Marca requisitos especiales para activar rutas " "de Compras, Seguridad TI o Juridica."),
                                        html.Li("Si el viaje es internacional, registra moneda y tasa."),
                                        html.Li("Puedes guardar como borrador antes de radicar."),
                                    ],
                                    className="side-list",
                                ),
                            ]
                        ),
                        class_name="summary-card border-0 h-100",
                    ),
                    lg=4,
                ),
            ],
            class_name="g-4",
        ),
    ],
    fluid=True,
)
