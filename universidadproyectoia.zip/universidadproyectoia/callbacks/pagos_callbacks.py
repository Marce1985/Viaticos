from decimal import Decimal, InvalidOperation

from dash import ALL, Input, Output, State, callback, html, no_update

from components.payment import build_payment_queue
from database.session import SessionLocal
from schemas.pago_schema import PaymentConfirmationInput, PaymentNotificationInput
from services.pagos_service import PagosService, PagosServiceError


def _to_decimal(value: float | int | str | None) -> Decimal:
    if value in (None, ""):
        return Decimal("0")
    try:
        return Decimal(str(value))
    except InvalidOperation as exc:
        raise PagosServiceError("El valor monetario ingresado para pagos no es valido.") from exc


def _build_payment_detail(item: dict[str, object] | None) -> html.Div:
    if item is None:
        return html.Div(
            [
                html.Span("Selecciona una orden", className="summary-label"),
                html.P(
                    "Elige una solicitud de la cola para notificar o confirmar el pago.",
                    className="page-copy mb-0",
                ),
            ],
            className="empty-state",
        )
    return html.Div(
        [
            html.Span("Detalle de pago", className="summary-label"),
            html.H3(item["request_code"], className="summary-title"),
            html.Ul(
                [
                    html.Li(f"Destino: {item['destination']}"),
                    html.Li(f"Estado actual: {item['status']}"),
                    html.Li(f"Valor aprobado: {item['approved_amount']}"),
                    html.Li(f"Valor notificado: {item['notified_amount']}"),
                    html.Li(f"Valor girado: {item['paid_amount']}"),
                ],
                className="side-list mt-3",
            ),
        ]
    )


@callback(
    Output("pagos-queue", "children"),
    Output("pagos-selected-request", "data"),
    Input("pagos-refresh", "n_clicks"),
)
def load_payment_queue(_: int | None) -> tuple[html.Div, int | None]:
    with SessionLocal() as session:
        service = PagosService(session)
        queue = service.list_payment_queue()
        selected_request_id = queue[0]["request_id"] if queue else None
        return build_payment_queue(queue, selected_request_id), selected_request_id


@callback(
    Output("pagos-selected-request", "data", allow_duplicate=True),
    Input({"type": "payment-row-button", "request_id": ALL}, "n_clicks"),
    prevent_initial_call=True,
)
def select_payment_request(row_clicks: list[int | None]) -> int | None:
    from dash import ctx

    if not ctx.triggered_id or not isinstance(ctx.triggered_id, dict):
        return no_update
    return ctx.triggered_id["request_id"]


@callback(
    Output("pagos-queue", "children", allow_duplicate=True),
    Output("pagos-detail", "children"),
    Input("pagos-selected-request", "data"),
    prevent_initial_call=True,
)
def load_payment_detail(request_id: int | None) -> tuple[html.Div, html.Div]:
    with SessionLocal() as session:
        service = PagosService(session)
        queue = service.list_payment_queue()
        queue_component = build_payment_queue(queue, request_id)
        selected = next((item for item in queue if item["request_id"] == request_id), None)
        return queue_component, _build_payment_detail(selected)


@callback(
    Output("pagos-feedback", "children"),
    Output("pagos-feedback", "color"),
    Output("pagos-feedback", "is_open"),
    Output("pagos-selected-request", "data", allow_duplicate=True),
    Input("pagos-notify", "n_clicks"),
    Input("pagos-confirm", "n_clicks"),
    State("pagos-selected-request", "data"),
    State("pagos-sent-to", "value"),
    State("pagos-reference-code", "value"),
    State("pagos-notified-amount", "value"),
    State("pagos-paid-amount", "value"),
    prevent_initial_call=True,
)
def execute_payment_action(
    notify_clicks: int | None,
    confirm_clicks: int | None,
    request_id: int | None,
    sent_to: str | None,
    reference_code: str | None,
    notified_amount: float | int | str | None,
    paid_amount: float | int | str | None,
) -> tuple[object, str, bool, int | None]:
    from dash import ctx

    if request_id is None:
        return "Selecciona una orden de pago antes de ejecutar una accion.", "warning", True, None

    with SessionLocal() as session:
        service = PagosService(session)
        try:
            if ctx.triggered_id == "pagos-notify":
                result = service.notify_payment(
                    PaymentNotificationInput(
                        request_id=request_id,
                        sent_to=(sent_to or "").strip() or "tesoreria@example.com",
                        reference_code=(reference_code or "").strip() or "REF-DEMO",
                        notified_amount=_to_decimal(notified_amount),
                    )
                )
                message = (
                    f"Pago notificado. Nuevo estado: {result.request_status.value}. " f"Notificaciones registradas: {len(result.notifications)}."
                )
            else:
                result = service.confirm_payment(
                    PaymentConfirmationInput(
                        request_id=request_id,
                        paid_amount=_to_decimal(paid_amount),
                    )
                )
                message = f"Pago confirmado. Nuevo estado: {result.request_status.value}."
        except PagosServiceError as exc:
            session.rollback()
            return str(exc), "danger", True, request_id

    return html.Div([html.Strong("Accion registrada. "), message]), "success", True, request_id
