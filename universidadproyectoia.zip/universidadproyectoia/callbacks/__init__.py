def register_callbacks() -> None:
    from callbacks import (
        aprobaciones_callbacks,  # noqa: F401
        dashboard_callbacks,  # noqa: F401
        legalizacion_callbacks,  # noqa: F401
        pagos_callbacks,  # noqa: F401
        solicitud_callbacks,  # noqa: F401
    )
