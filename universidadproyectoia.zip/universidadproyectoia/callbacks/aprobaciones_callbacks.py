import dash_bootstrap_components as dbc
from dash import ALL, Input, Output, State, callback, html, no_update

from components.tables import build_approval_inbox
from components.timeline import build_timeline
from database.session import SessionLocal
from domain.enums import ApprovalRole
from schemas.aprobacion_schema import ApprovalActionInput
from services.aprobacion_service import AprobacionService, AprobacionServiceError


def _role_from_value(value: str | None) -> ApprovalRole:
    return ApprovalRole(value or ApprovalRole.JEFE.value)


def _build_detail(detail: dict[str, object] | None) -> html.Div:
    if detail is None:
        return html.Div(
            [
                html.Span("Selecciona una solicitud", className="summary-label"),
                html.P(
                    "Elige un elemento de la bandeja para revisar su detalle y tomar una accion.",
                    className="page-copy mb-0",
                ),
            ],
            className="empty-state",
        )

    flags = [
        f"Solicitud: {detail['request_code']}",
        f"Estado: {detail['status']}",
        f"Destino: {detail['destination']}, {detail['country']}",
        f"Vigencia: {detail['start_date']} al {detail['end_date']}",
        f"Monto estimado: {detail['estimated_amount']}",
        f"Solicitante ID: {detail['employee_id']}",
        f"Jefe ID: {detail['manager_id']}",
        f"Centro de costo ID: {detail['cost_center_id']}",
    ]

    return html.Div(
        [
            html.Span("Detalle de solicitud", className="summary-label"),
            html.H3(detail["request_code"], className="summary-title"),
            html.P(detail["travel_purpose"], className="page-copy"),
            html.Ul([html.Li(item) for item in flags], className="side-list mt-3"),
        ]
    )


def _build_step_summary(steps: list[dict[str, object]]) -> html.Div:
    if not steps:
        return html.Div(className="empty-state")
    return html.Div(
        [
            html.Div(
                [
                    html.Span(step["role"], className="timeline-label"),
                    dbc.Badge(
                        "Completado" if step["is_completed"] else "Pendiente",
                        color="success" if step["is_completed"] else "warning",
                    ),
                    html.P(step["status"], className="timeline-copy"),
                ],
                className="step-pill",
            )
            for step in steps
        ],
        className="step-grid",
    )


def _timeline_entries(detail: dict[str, object]) -> list[dict[str, str]]:
    entries: list[dict[str, str]] = []
    for item in detail["timeline"]:
        entries.append(
            {
                "label": item["created_at"],
                "title": item["event_type"],
                "description": item["details"] or "Sin detalle adicional.",
            }
        )
    for event in detail["events"]:
        entries.append(
            {
                "label": event["created_at"],
                "title": f"{event['role']} · {event['decision']}",
                "description": event["comments"] or "Sin comentarios.",
            }
        )
    return sorted(entries, key=lambda item: item["label"])


@callback(
    Output("aprobaciones-inbox", "children"),
    Output("aprobaciones-selected-request", "data"),
    Input("aprobaciones-role-filter", "value"),
)
def load_inbox(role_value: str | None) -> tuple[html.Div, int | None]:
    with SessionLocal() as session:
        service = AprobacionService(session)
        role = _role_from_value(role_value)
        inbox = service.get_inbox(role)
        selected_request_id = inbox[0]["request_id"] if inbox else None
        return (
            build_approval_inbox(items=inbox, selected_request_id=selected_request_id),
            selected_request_id,
        )


@callback(
    Output("aprobaciones-selected-request", "data", allow_duplicate=True),
    Input({"type": "approval-row-button", "request_id": ALL}, "n_clicks"),
    State({"type": "approval-row-button", "request_id": ALL}, "id"),
    prevent_initial_call=True,
)
def select_request(row_clicks: list[int | None], ids: list[dict[str, int]]) -> int | None:
    from dash import ctx

    if not ctx.triggered_id or not isinstance(ctx.triggered_id, dict):
        return no_update
    return ctx.triggered_id["request_id"]


@callback(
    Output("aprobaciones-inbox", "children", allow_duplicate=True),
    Output("aprobaciones-detail", "children"),
    Output("aprobaciones-step-summary", "children"),
    Output("aprobaciones-timeline", "children"),
    Input("aprobaciones-selected-request", "data"),
    State("aprobaciones-role-filter", "value"),
    prevent_initial_call=True,
)
def load_detail(request_id: int | None, role_value: str | None) -> tuple[html.Div, html.Div, html.Div, html.Div]:
    with SessionLocal() as session:
        service = AprobacionService(session)
        role = _role_from_value(role_value)
        inbox = service.get_inbox(role)
        inbox_component = build_approval_inbox(items=inbox, selected_request_id=request_id)

        if request_id is None:
            empty = html.Div(className="empty-state")
            return inbox_component, _build_detail(None), empty, empty

        detail = service.get_request_detail(request_id)
        return (
            inbox_component,
            _build_detail(detail),
            _build_step_summary(detail["steps"]),
            build_timeline(_timeline_entries(detail)),
        )


@callback(
    Output("aprobaciones-action-feedback", "children"),
    Output("aprobaciones-action-feedback", "color"),
    Output("aprobaciones-action-feedback", "is_open"),
    Output("aprobaciones-selected-request", "data", allow_duplicate=True),
    Input("aprobaciones-approve", "n_clicks"),
    Input("aprobaciones-reject", "n_clicks"),
    Input("aprobaciones-return", "n_clicks"),
    State("aprobaciones-selected-request", "data"),
    State("aprobaciones-role-filter", "value"),
    State("aprobaciones-comments", "value"),
    prevent_initial_call=True,
)
def execute_action(
    approve_clicks: int | None,
    reject_clicks: int | None,
    return_clicks: int | None,
    request_id: int | None,
    role_value: str | None,
    comments: str | None,
) -> tuple[object, str, bool, int | None]:
    from dash import ctx

    if request_id is None:
        return "Selecciona una solicitud antes de ejecutar una accion.", "warning", True, None

    role = _role_from_value(role_value)
    with SessionLocal() as session:
        service = AprobacionService(session)
        action_input = ApprovalActionInput(
            request_id=request_id,
            actor_id=1,
            role=role,
            comments=comments,
        )
        try:
            if ctx.triggered_id == "aprobaciones-approve":
                result = service.approve(action_input)
            elif ctx.triggered_id == "aprobaciones-reject":
                result = service.reject(action_input)
            else:
                result = service.return_for_adjustments(action_input)
        except AprobacionServiceError as exc:
            session.rollback()
            return str(exc), "danger", True, request_id

    return (
        html.Div(
            [
                html.Strong("Accion registrada. "),
                f"Decision {result.decision.value} aplicada. Nuevo estado: {result.new_status.value}.",
            ]
        ),
        "success",
        True,
        request_id,
    )
