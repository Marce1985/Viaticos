from datetime import date
from decimal import Decimal, InvalidOperation

from dash import ALL, Input, Output, State, callback, html, no_update

from components.legalizacion import build_legalization_queue
from database.session import SessionLocal
from schemas.legalizacion_schema import ExpenseItemInput, LegalizationCloseInput
from services.legalizacion_service import LegalizacionService, LegalizacionServiceError


def _to_decimal(value: float | int | str | None) -> Decimal | None:
    if value in (None, ""):
        return None
    try:
        return Decimal(str(value))
    except InvalidOperation as exc:
        raise LegalizacionServiceError("El valor monetario ingresado no es valido.") from exc


def _build_summary(summary: dict[str, object] | None) -> html.Div:
    if summary is None:
        return html.Div(
            [
                html.Span("Selecciona una solicitud", className="summary-label"),
                html.P(
                    "Escoge un tramite de la cola para registrar gastos y cerrar la legalizacion.",
                    className="page-copy mb-0",
                ),
            ],
            className="empty-state",
        )

    return html.Div(
        [
            html.Span("Resumen financiero", className="summary-label"),
            html.H3(summary["request_code"], className="summary-title"),
            html.Ul(
                [
                    html.Li(f"Estado: {summary['status']}"),
                    html.Li(f"Aprobado: {summary['approved_amount']}"),
                    html.Li(f"Anticipo: {summary['advance_paid']}"),
                    html.Li(f"Soportado: {summary['supported_amount']}"),
                    html.Li(f"Saldo a favor empleado: {summary['balance_favor_employee']}"),
                    html.Li(f"Reintegro a compania: {summary['balance_reimbursement_company']}"),
                ],
                className="side-list mt-3",
            ),
        ]
    )


def _build_items(items: list[dict[str, object]]) -> html.Div:
    if not items:
        return html.Div(
            [
                html.Span("Sin gastos cargados", className="summary-label"),
                html.P(
                    "Aun no hay items registrados para esta legalizacion.",
                    className="page-copy mb-0",
                ),
            ],
            className="empty-state",
        )
    return html.Div(
        [
            html.Div(
                [
                    html.Span(item["category"], className="timeline-label"),
                    html.H4(
                        f"{item['currency']} {item['amount']}" + (f" · {item['vendor']}" if item["vendor"] else ""),
                        className="timeline-title",
                    ),
                    html.P(
                        item["description"] or "Sin descripcion adicional.",
                        className="timeline-copy",
                    ),
                ],
                className="step-pill",
            )
            for item in items
        ],
        className="step-grid",
    )


@callback(
    Output("legalizacion-queue", "children"),
    Output("legalizacion-selected-request", "data"),
    Input("legalizacion-refresh", "n_clicks"),
)
def load_queue(_: int | None) -> tuple[html.Div, int | None]:
    with SessionLocal() as session:
        service = LegalizacionService(session)
        queue = service.list_legalization_queue()
        selected_request_id = queue[0]["request_id"] if queue else None
        return build_legalization_queue(queue, selected_request_id), selected_request_id


@callback(
    Output("legalizacion-selected-request", "data", allow_duplicate=True),
    Input({"type": "legalizacion-row-button", "request_id": ALL}, "n_clicks"),
    prevent_initial_call=True,
)
def select_request(row_clicks: list[int | None]) -> int | None:
    from dash import ctx

    if not ctx.triggered_id or not isinstance(ctx.triggered_id, dict):
        return no_update
    return ctx.triggered_id["request_id"]


@callback(
    Output("legalizacion-queue", "children", allow_duplicate=True),
    Output("legalizacion-summary", "children"),
    Output("legalizacion-items", "children"),
    Input("legalizacion-selected-request", "data"),
    prevent_initial_call=True,
)
def load_detail(request_id: int | None) -> tuple[html.Div, html.Div, html.Div]:
    with SessionLocal() as session:
        service = LegalizacionService(session)
        queue = service.list_legalization_queue()
        queue_component = build_legalization_queue(queue, request_id)
        if request_id is None:
            empty = html.Div(className="empty-state")
            return queue_component, _build_summary(None), empty
        summary = service.get_legalization_detail(request_id)
        formatted_summary = {
            "request_code": next(
                (item["request_code"] for item in queue if item["request_id"] == request_id),
                f"REQ-{request_id}",
            ),
            "status": summary.request_status.value,
            "approved_amount": f"{summary.currency} {summary.approved_amount}",
            "advance_paid": f"{summary.currency} {summary.advance_paid}",
            "supported_amount": f"{summary.currency} {summary.supported_amount}",
            "balance_favor_employee": f"{summary.currency} {summary.balance_favor_employee}",
            "balance_reimbursement_company": f"{summary.currency} {summary.balance_reimbursement_company}",
        }
        items = [item.model_dump() for item in summary.items]
        return queue_component, _build_summary(formatted_summary), _build_items(items)


@callback(
    Output("legalizacion-feedback", "children"),
    Output("legalizacion-feedback", "color"),
    Output("legalizacion-feedback", "is_open"),
    Output("legalizacion-selected-request", "data", allow_duplicate=True),
    Input("legalizacion-add-item", "n_clicks"),
    Input("legalizacion-close", "n_clicks"),
    State("legalizacion-selected-request", "data"),
    State("legalizacion-category", "value"),
    State("legalizacion-amount", "value"),
    State("legalizacion-currency", "value"),
    State("legalizacion-rate", "value"),
    State("legalizacion-vendor", "value"),
    State("legalizacion-date", "date"),
    State("legalizacion-description", "value"),
    prevent_initial_call=True,
)
def execute_action(
    add_clicks: int | None,
    close_clicks: int | None,
    request_id: int | None,
    category: str | None,
    amount: float | int | str | None,
    currency: str | None,
    exchange_rate: float | int | str | None,
    vendor: str | None,
    expense_date: str | None,
    description: str | None,
) -> tuple[object, str, bool, int | None]:
    from dash import ctx

    if request_id is None:
        return "Selecciona una solicitud antes de ejecutar una accion.", "warning", True, None

    with SessionLocal() as session:
        service = LegalizacionService(session)
        try:
            if ctx.triggered_id == "legalizacion-add-item":
                summary = service.add_expense_item(
                    ExpenseItemInput(
                        request_id=request_id,
                        category=(category or "").strip() or "Gasto",
                        amount=_to_decimal(amount) or Decimal("0"),
                        currency=(currency or "COP").strip().upper(),
                        exchange_rate=_to_decimal(exchange_rate),
                        vendor=(vendor or "").strip() or None,
                        expense_date=date.fromisoformat(expense_date) if expense_date else None,
                        description=(description or "").strip() or None,
                    )
                )
                message = f"Gasto agregado. Soportado acumulado: {summary.currency} {summary.supported_amount}."
            else:
                summary = service.close_legalization(LegalizationCloseInput(request_id=request_id))
                message = (
                    f"Legalizacion cerrada. Estado final: {summary.request_status.value}. "
                    f"Saldo empleado: {summary.currency} {summary.balance_favor_employee}."
                )
        except LegalizacionServiceError as exc:
            session.rollback()
            return str(exc), "danger", True, request_id

    return html.Div([html.Strong("Accion registrada. "), message]), "success", True, request_id
