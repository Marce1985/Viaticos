from datetime import date
from decimal import Decimal, InvalidOperation

import dash_bootstrap_components as dbc
from dash import Input, Output, State, callback, html, no_update
from sqlalchemy.exc import IntegrityError

from database.session import SessionLocal
from domain.rules import DomainRuleViolation, RoutingContext, determine_approval_route
from schemas.solicitud_schema import SolicitudDraftInput
from services.solicitud_service import SolicitudService, SolicitudServiceError


def _parse_request_payload(
    employee_id: int | None,
    manager_id: int | None,
    cost_center_id: int | None,
    destination: str | None,
    country: str | None,
    start_date: str | None,
    end_date: str | None,
    purpose: str | None,
    flags: list[str] | None,
    estimated_amount: float | int | str | None,
    currency: str | None,
    exchange_rate: float | int | str | None,
) -> SolicitudDraftInput:
    selected_flags = set(flags or [])
    return SolicitudDraftInput(
        employee_id=employee_id or 0,
        manager_id=manager_id,
        cost_center_id=cost_center_id,
        destination=(destination or "").strip(),
        country=(country or "").strip(),
        start_date=date.fromisoformat(start_date) if start_date else date.today(),
        end_date=date.fromisoformat(end_date) if end_date else date.today(),
        travel_purpose=(purpose or "").strip(),
        requires_tickets="tickets" in selected_flags,
        requires_external_tools="external_tools" in selected_flags,
        requires_nda="nda" in selected_flags,
        destination_international="international" in selected_flags,
        estimated_amount=_to_decimal(estimated_amount),
        currency=(currency or "COP").strip().upper(),
        exchange_rate_reference=(_to_decimal(exchange_rate) if exchange_rate not in (None, "") else None),
    )


def _to_decimal(value: float | int | str | None) -> Decimal:
    if value in (None, ""):
        return Decimal("0")
    try:
        return Decimal(str(value))
    except InvalidOperation as exc:
        raise DomainRuleViolation("El valor monetario ingresado no es valido.") from exc


def _build_route_preview(flags: list[str] | None, estimated_amount: float | int | str | None) -> html.Div:
    selected_flags = set(flags or [])
    demo_request = SolicitudDraftInput(
        employee_id=1,
        manager_id=1,
        cost_center_id=1,
        destination="Demo",
        country="Demo",
        start_date=date.today(),
        end_date=date.today(),
        travel_purpose="Vista previa",
        requires_tickets="tickets" in selected_flags,
        requires_external_tools="external_tools" in selected_flags,
        requires_nda="nda" in selected_flags,
        destination_international="international" in selected_flags,
        estimated_amount=_to_decimal(estimated_amount),
        currency="USD" if "international" in selected_flags else "COP",
        exchange_rate_reference=Decimal("4000") if "international" in selected_flags else None,
    )
    route = determine_approval_route(
        demo_request,
        context=RoutingContext(),
    )
    return html.Div(
        [
            html.Span("Ruta estimada de aprobacion", className="summary-label"),
            html.Div(
                [dbc.Badge(role.value.replace("_", " "), color="light", text_color="dark") for role in route],
                className="route-badges",
            ),
        ]
    )


@callback(
    Output("solicitud-exchange-rate-wrapper", "style"),
    Output("solicitud-currency", "value"),
    Input("solicitud-flags", "value"),
    State("solicitud-currency", "value"),
)
def toggle_international_fields(flags: list[str], current_currency: str | None) -> tuple[dict[str, str], str]:
    if "international" in (flags or []):
        return {"display": "block"}, (current_currency or "USD")
    return {"display": "none"}, "COP"


@callback(
    Output("solicitud-route-preview", "children"),
    Input("solicitud-flags", "value"),
    Input("solicitud-estimated-amount", "value"),
)
def preview_route(flags: list[str], estimated_amount: float | int | str | None) -> html.Div:
    return _build_route_preview(flags, estimated_amount)


@callback(
    Output("solicitud-feedback", "children"),
    Output("solicitud-feedback", "color"),
    Output("solicitud-feedback", "is_open"),
    Output("solicitud-current-request-id", "data"),
    Input("solicitud-save-draft", "n_clicks"),
    Input("solicitud-submit-request", "n_clicks"),
    State("solicitud-current-request-id", "data"),
    State("solicitud-employee-id", "value"),
    State("solicitud-manager-id", "value"),
    State("solicitud-cost-center-id", "value"),
    State("solicitud-destination", "value"),
    State("solicitud-country", "value"),
    State("solicitud-start-date", "date"),
    State("solicitud-end-date", "date"),
    State("solicitud-purpose", "value"),
    State("solicitud-flags", "value"),
    State("solicitud-estimated-amount", "value"),
    State("solicitud-currency", "value"),
    State("solicitud-exchange-rate", "value"),
    prevent_initial_call=True,
)
def persist_request(
    save_clicks: int | None,
    submit_clicks: int | None,
    current_request_id: int | None,
    employee_id: int | None,
    manager_id: int | None,
    cost_center_id: int | None,
    destination: str | None,
    country: str | None,
    start_date: str | None,
    end_date: str | None,
    purpose: str | None,
    flags: list[str] | None,
    estimated_amount: float | int | str | None,
    currency: str | None,
    exchange_rate: float | int | str | None,
) -> tuple[object, str, bool, int | None]:
    from dash import ctx

    if not ctx.triggered_id:
        return no_update, no_update, no_update, current_request_id

    try:
        payload = _parse_request_payload(
            employee_id,
            manager_id,
            cost_center_id,
            destination,
            country,
            start_date,
            end_date,
            purpose,
            flags,
            estimated_amount,
            currency,
            exchange_rate,
        )
    except (ValueError, DomainRuleViolation) as exc:
        return str(exc), "danger", True, current_request_id

    with SessionLocal() as session:
        service = SolicitudService(session)
        try:
            if ctx.triggered_id == "solicitud-save-draft":
                result = service.save_or_update_draft(payload, request_id=current_request_id)
                return (
                    html.Div(
                        [
                            html.Strong("Borrador guardado. "),
                            f"Codigo {result.request_code} creado en estado {result.status.value}.",
                        ]
                    ),
                    "success",
                    True,
                    result.id,
                )

            request_id = current_request_id
            draft = service.save_or_update_draft(payload, request_id=request_id)
            request_id = draft.id
            submission = service.submit_request(request_id)
            route_text = ", ".join(role.value for role in submission.approval_route)
            return (
                html.Div(
                    [
                        html.Strong("Solicitud radicada. "),
                        (f"Codigo {submission.request.request_code} enviado a " f"{submission.current_status.value}. Ruta: {route_text}."),
                    ]
                ),
                "primary",
                True,
                submission.request.id,
            )
        except (DomainRuleViolation, SolicitudServiceError, IntegrityError) as exc:
            session.rollback()
            return str(exc), "danger", True, current_request_id
