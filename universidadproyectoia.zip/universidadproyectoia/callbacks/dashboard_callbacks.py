from dash import Input, Output, callback, html

from database.session import SessionLocal
from services.dashboard_service import DashboardService


def _build_kpi_cards(kpis: list[dict[str, str]]) -> list[html.Div]:
    cards: list[html.Div] = []
    for index, item in enumerate(kpis):
        accent = ["blue", "teal", "gold", "blue"][index % 4]
        cards.append(
            html.Div(
                [
                    html.Span(item["label"], className="metric-label"),
                    html.H3(item["value"], className="metric-value"),
                    html.Div(className=f"metric-accent metric-accent-{accent}"),
                ],
                className="metric-card border-0 p-4",
            )
        )
    return cards


@callback(
    Output("dashboard-kpis", "children"),
    Output("dashboard-status-chart", "figure"),
    Output("dashboard-stage-chart", "figure"),
    Output("dashboard-payment-chart", "figure"),
    Output("dashboard-sla-chart", "figure"),
    Input("dashboard-refresh", "n_clicks"),
)
def load_dashboard(_: int | None):
    with SessionLocal() as session:
        service = DashboardService(session)
        metrics = service.get_dashboard_metrics()
    return (
        _build_kpi_cards(metrics["kpis"]),
        metrics["status_figure"],
        metrics["stage_figure"],
        metrics["payment_figure"],
        metrics["sla_figure"],
    )
